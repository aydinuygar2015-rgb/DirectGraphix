cbuffer SamplerInfo : register(b0)
{
    float2 _13_OutSize : packoffset(c0);
    float2 _13_InSize : packoffset(c0.z);
};

cbuffer BlurConfig : register(b1)
{
    float2 _25_BlurDir : packoffset(c0);
    float _25_Radius : packoffset(c0.z);
};

Texture2D<float4> InSampler : register(t2);
SamplerState _InSampler_sampler : register(s2);

static float2 texCoord;
static float4 fragColor;

struct SPIRV_Cross_Input
{
    float2 texCoord : TEXCOORD0;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

void frag_main()
{
    float2 oneTexel = 1.0f.xx / _13_InSize;
    float2 sampleStep = oneTexel * _25_BlurDir;
    float4 blurred = 0.0f.xxxx;
    float radius = 2.0f;
    float _42 = (-radius) + 0.5f;
    for (float a = _42; a <= radius; a += 2.0f)
    {
        blurred += InSampler.Sample(_InSampler_sampler, texCoord + (sampleStep * a));
    }
    blurred += (InSampler.Sample(_InSampler_sampler, texCoord + (sampleStep * radius)) / 2.0f.xxxx);
    fragColor = float4((blurred / (radius + 0.5f).xxxx).xyz, blurred.w);
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    texCoord = stage_input.texCoord;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
