cbuffer SamplerInfo : register(b1)
{
    float2 _13_OutSize : packoffset(c0);
    float2 _13_InSize : packoffset(c0.z);
};

Texture2D<float4> InSampler : register(t0);
SamplerState _InSampler_sampler : register(s0);

static float2 texCoord;
static float4 fragColor;

struct SPIRV_Cross_Input
{
    float2 texCoord : TEXCOORD0;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

void frag_main()
{
    float2 oneTexel = 1.0f.xx / _13_InSize;
    float4 center = InSampler.Sample(_InSampler_sampler, texCoord);
    float4 left = InSampler.Sample(_InSampler_sampler, texCoord - float2(oneTexel.x, 0.0f));
    float4 right = InSampler.Sample(_InSampler_sampler, texCoord + float2(oneTexel.x, 0.0f));
    float4 up = InSampler.Sample(_InSampler_sampler, texCoord - float2(0.0f, oneTexel.y));
    float4 down = InSampler.Sample(_InSampler_sampler, texCoord + float2(0.0f, oneTexel.y));
    float leftDiff = abs(center.w - left.w);
    float rightDiff = abs(center.w - right.w);
    float upDiff = abs(center.w - up.w);
    float downDiff = abs(center.w - down.w);
    float total = clamp(((leftDiff + rightDiff) + upDiff) + downDiff, 0.0f, 1.0f);
    float3 outColor = ((((center.xyz * center.w) + (left.xyz * left.w)) + (right.xyz * right.w)) + (up.xyz * up.w)) + (down.xyz * down.w);
    fragColor = float4(outColor * 0.20000000298023223876953125f, total);
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    texCoord = stage_input.texCoord;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
