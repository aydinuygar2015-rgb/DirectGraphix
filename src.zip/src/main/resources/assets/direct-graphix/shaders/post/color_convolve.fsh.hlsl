cbuffer SamplerInfo : register(b1)
{
    float2 _13_OutSize : packoffset(c0);
    float2 _13_InSize : packoffset(c0.z);
};

cbuffer ColorConfig : register(b2)
{
    float3 _40_RedMatrix : packoffset(c0);
    float3 _40_GreenMatrix : packoffset(c1);
    float3 _40_BlueMatrix : packoffset(c2);
};

Texture2D<float4> InSampler : register(t0);
SamplerState _InSampler_sampler : register(s0);

static float2 texCoord;
static float4 fragColor;

struct SPIRV_Cross_Input
{
    float2 texCoord : TEXCOORD0;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

void frag_main()
{
    float2 oneTexel = 1.0f.xx / _13_InSize;
    float4 InTexel = InSampler.Sample(_InSampler_sampler, texCoord);
    float RedValue = dot(InTexel.xyz, _40_RedMatrix);
    float GreenValue = dot(InTexel.xyz, _40_GreenMatrix);
    float BlueValue = dot(InTexel.xyz, _40_BlueMatrix);
    float3 OutColor = float3(RedValue, GreenValue, BlueValue);
    float Luma = dot(OutColor, float3(0.300000011920928955078125f, 0.589999973773956298828125f, 0.10999999940395355224609375f));
    float3 Chroma = OutColor - Luma.xxx;
    OutColor = (Chroma * 1.7999999523162841796875f) + Luma.xxx;
    fragColor = float4(OutColor, 1.0f);
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    texCoord = stage_input.texCoord;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
