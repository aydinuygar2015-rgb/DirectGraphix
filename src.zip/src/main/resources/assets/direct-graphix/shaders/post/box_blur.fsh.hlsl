cbuffer SamplerInfo : register(b2)
{
    float2 _13_OutSize : packoffset(c0);
    float2 _13_InSize : packoffset(c0.z);
};

cbuffer BlurConfig : register(b3)
{
    float2 _25_BlurDir : packoffset(c0);
    float _25_Radius : packoffset(c0.z);
};

cbuffer Globals : register(b0)
{
    int3 _54_CameraBlockPos : packoffset(c0);
    float _54_GlintAlpha : packoffset(c0.w);
    float3 _54_CameraOffset : packoffset(c1);
    float _54_GameTime : packoffset(c1.w);
    float2 _54_ScreenSize : packoffset(c2);
    int _54_MenuBlurRadius : packoffset(c2.z);
    int _54_UseRgss : packoffset(c2.w);
};

Texture2D<float4> InSampler : register(t1);
SamplerState _InSampler_sampler : register(s1);

static float2 texCoord;
static float4 fragColor;

struct SPIRV_Cross_Input
{
    float2 texCoord : TEXCOORD0;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

void frag_main()
{
    float2 oneTexel = 1.0f.xx / _13_InSize;
    float2 sampleStep = oneTexel * _25_BlurDir;
    float4 blurred = 0.0f.xxxx;
    float _43;
    if (_25_Radius >= 0.5f)
    {
        _43 = round(_25_Radius);
    }
    else
    {
        _43 = float(_54_MenuBlurRadius);
    }
    float actualRadius = _43;
    float _64 = (-actualRadius) + 0.5f;
    for (float a = _64; a <= actualRadius; a += 2.0f)
    {
        blurred += InSampler.Sample(_InSampler_sampler, texCoord + (sampleStep * a));
    }
    blurred += (InSampler.Sample(_InSampler_sampler, texCoord + (sampleStep * actualRadius)) / 2.0f.xxxx);
    fragColor = blurred / (actualRadius + 0.5f).xxxx;
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    texCoord = stage_input.texCoord;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
