cbuffer SamplerInfo : register(b1)
{
    float2 _12_OutSize : packoffset(c0);
    float2 _12_InSize : packoffset(c0.z);
};

cbuffer InvertConfig : register(b2)
{
    float _44_InverseAmount : packoffset(c0);
};

Texture2D<float4> InSampler : register(t0);
SamplerState _InSampler_sampler : register(s0);

static float2 texCoord;
static float4 fragColor;

struct SPIRV_Cross_Input
{
    float2 texCoord : TEXCOORD0;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

void frag_main()
{
    float2 sizeRatio = _12_OutSize / _12_InSize;
    float4 diffuseColor = InSampler.Sample(_InSampler_sampler, texCoord);
    float4 invertColor = 1.0f.xxxx - diffuseColor;
    float4 outColor = lerp(diffuseColor, invertColor, _44_InverseAmount.xxxx);
    fragColor = float4(outColor.xyz, 1.0f);
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    texCoord = stage_input.texCoord;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
