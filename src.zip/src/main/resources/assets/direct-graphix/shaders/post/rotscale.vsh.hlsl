cbuffer RotScaleConfig : register(b0)
{
    float2 _57_InScale : packoffset(c0);
    float2 _57_InOffset : packoffset(c0.z);
    float _57_InRotation : packoffset(c1);
};

cbuffer SamplerInfo : register(b0)
{
    float2 _104_OutSize : packoffset(c0);
    float2 _104_InSize : packoffset(c0.z);
};


static float4 gl_Position;
static int gl_VertexIndex;
static float2 texCoord;
static float2 scaledCoord;

struct SPIRV_Cross_Input
{
    uint gl_VertexIndex : SV_VertexID;
};

struct SPIRV_Cross_Output
{
    float2 texCoord : TEXCOORD0;
    float2 scaledCoord : TEXCOORD1;
    float4 gl_Position : SV_Position;
};

void vert_main()
{
    float2 uv = float2(float((gl_VertexIndex << 1) & 2), float(gl_VertexIndex & 2));
    float4 pos = float4((uv * 2.0f.xx) + (-1.0f).xx, 0.0f, 1.0f);
    gl_Position = pos;
    texCoord = uv;
    float Deg2Rad = 0.01745329238474369049072265625f;
    float InRadians = _57_InRotation * Deg2Rad;
    float Cosine = cos(InRadians);
    float Sine = sin(InRadians);
    float RotU = (texCoord.x * Cosine) - (texCoord.y * Sine);
    float RotV = (texCoord.y * Cosine) + (texCoord.x * Sine);
    scaledCoord = (float2(RotU, RotV) * _57_InScale) + _57_InOffset;
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    gl_VertexIndex = int(stage_input.gl_VertexIndex);
    vert_main();
    SPIRV_Cross_Output stage_output;
    stage_output.gl_Position = gl_Position;
    stage_output.texCoord = texCoord;
    stage_output.scaledCoord = scaledCoord;
    return stage_output;
}
