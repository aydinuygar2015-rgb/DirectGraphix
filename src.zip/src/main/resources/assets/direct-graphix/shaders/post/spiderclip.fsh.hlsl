cbuffer SpiderConfig : register(b2)
{
    float4 _35_Scissor : packoffset(c0);
    float4 _35_Vignette : packoffset(c1);
};

cbuffer SamplerInfo : register(b0)
{
    float2 _179_OutSize : packoffset(c0);
    float2 _179_InSize : packoffset(c0.z);
};

Texture2D<float4> InSampler : register(t0);
SamplerState _InSampler_sampler : register(s0);
Texture2D<float4> BlurSampler : register(t1);
SamplerState _BlurSampler_sampler : register(s1);

static float2 scaledCoord;
static float2 texCoord;
static float4 fragColor;

struct SPIRV_Cross_Input
{
    float2 texCoord : TEXCOORD0;
    float2 scaledCoord : TEXCOORD1;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

void frag_main()
{
    float4 ScaledTexel = InSampler.Sample(_InSampler_sampler, scaledCoord);
    float4 BlurTexel = BlurSampler.Sample(_BlurSampler_sampler, texCoord);
    float4 OutTexel = ScaledTexel;
    if (scaledCoord.x < _35_Scissor.x)
    {
        OutTexel = BlurTexel;
    }
    if (scaledCoord.y < _35_Scissor.y)
    {
        OutTexel = BlurTexel;
    }
    if (scaledCoord.x > _35_Scissor.z)
    {
        OutTexel = BlurTexel;
    }
    if (scaledCoord.y > _35_Scissor.w)
    {
        OutTexel = BlurTexel;
    }
    if (scaledCoord.x < _35_Vignette.x)
    {
        OutTexel = lerp(BlurTexel, OutTexel, ((_35_Scissor.x - scaledCoord.x) / (_35_Scissor.x - _35_Vignette.x)).xxxx);
    }
    if (scaledCoord.y < _35_Vignette.y)
    {
        OutTexel = lerp(BlurTexel, OutTexel, ((_35_Scissor.y - scaledCoord.y) / (_35_Scissor.y - _35_Vignette.y)).xxxx);
    }
    if (scaledCoord.x > _35_Vignette.z)
    {
        OutTexel = lerp(BlurTexel, OutTexel, ((_35_Scissor.z - scaledCoord.x) / (_35_Scissor.z - _35_Vignette.z)).xxxx);
    }
    if (scaledCoord.y > _35_Vignette.w)
    {
        OutTexel = lerp(BlurTexel, OutTexel, ((_35_Scissor.w - scaledCoord.y) / (_35_Scissor.w - _35_Vignette.w)).xxxx);
    }
    fragColor = float4(OutTexel.xyz, 1.0f);
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    scaledCoord = stage_input.scaledCoord;
    texCoord = stage_input.texCoord;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
