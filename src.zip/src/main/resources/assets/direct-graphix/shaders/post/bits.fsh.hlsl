cbuffer SamplerInfo : register(b1)
{
    float2 _13_OutSize : packoffset(c0);
    float2 _13_InSize : packoffset(c0.z);
};

cbuffer BitsConfig : register(b2)
{
    float _26_Resolution : packoffset(c0);
    float _26_MosaicSize : packoffset(c0.y);
};

Texture2D<float4> InSampler : register(t0);
SamplerState _InSampler_sampler : register(s0);

static float2 texCoord;
static float4 fragColor;

struct SPIRV_Cross_Input
{
    float2 texCoord : TEXCOORD0;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

void frag_main()
{
    float2 oneTexel = 1.0f.xx / _13_InSize;
    float2 mosaicInSize = _13_InSize / _26_MosaicSize.xx;
    float2 fractPix = frac(texCoord * mosaicInSize) / mosaicInSize;
    float4 baseTexel = InSampler.Sample(_InSampler_sampler, texCoord - fractPix);
    float3 fractTexel = baseTexel.xyz - (frac(baseTexel.xyz * _26_Resolution) / _26_Resolution.xxx);
    float luma = dot(fractTexel, float3(0.300000011920928955078125f, 0.589999973773956298828125f, 0.10999999940395355224609375f));
    float3 chroma = (fractTexel - luma.xxx) * 1.5f;
    float3 _88 = luma.xxx + chroma;
    baseTexel.x = _88.x;
    baseTexel.y = _88.y;
    baseTexel.z = _88.z;
    baseTexel.w = 1.0f;
    fragColor = baseTexel;
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    texCoord = stage_input.texCoord;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
