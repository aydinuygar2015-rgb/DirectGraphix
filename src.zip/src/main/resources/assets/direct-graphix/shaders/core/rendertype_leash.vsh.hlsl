cbuffer Projection : register(b1)
{
    row_major float4x4 _74_ProjMat : packoffset(c0);
};

cbuffer DynamicTransforms : register(b0)
{
    row_major float4x4 _80_ModelViewMat : packoffset(c0);
    row_major float4x4 _80_TextureMat : packoffset(c4);
    float4 _80_ColorModulator : packoffset(c8);
    float3 _80_ModelOffset : packoffset(c9);
};

cbuffer Fog : register(b0)
{
    float4 _122_FogColor : packoffset(c0);
    float _122_FogEnvironmentalStart : packoffset(c1);
    float _122_FogEnvironmentalEnd : packoffset(c1.y);
    float _122_FogRenderDistanceStart : packoffset(c1.z);
    float _122_FogRenderDistanceEnd : packoffset(c1.w);
    float _122_FogSkyEnd : packoffset(c2);
    float _122_FogCloudsEnd : packoffset(c2.y);
};

Texture2D<float4> Sampler2 : register(t2);
SamplerState _Sampler2_sampler : register(s2);

static float4 gl_Position;
static float3 Position;
static float sphericalVertexDistance;
static float cylindricalVertexDistance;
static float4 vertexColor;
static float4 Color;
static int2 UV2;

struct SPIRV_Cross_Input
{
    float3 Position : TEXCOORD0;
    float4 Color : TEXCOORD1;
    int2 UV2 : TEXCOORD2;
};

struct SPIRV_Cross_Output
{
    float sphericalVertexDistance : TEXCOORD0;
    float cylindricalVertexDistance : TEXCOORD1;
    nointerpolation float4 vertexColor : TEXCOORD2;
    float4 gl_Position : SV_Position;
};

float fog_spherical_distance(float3 pos)
{
    return length(pos);
}

float fog_cylindrical_distance(float3 pos)
{
    float distXZ = length(pos.xz);
    float distY = abs(pos.y);
    return max(distXZ, distY);
}

float4 sample_lightmap(Texture2D<float4> lightMap, SamplerState _lightMap_sampler, int2 uv)
{
    return lightMap.SampleLevel(_lightMap_sampler, clamp((float2(uv) / 256.0f.xx) + 0.03125f.xx, 0.03125f.xx, 0.96875f.xx), 0.0f);
}

void vert_main()
{
    gl_Position = mul(float4(Position, 1.0f), mul(_80_ModelViewMat, _74_ProjMat));
    float3 param = Position;
    sphericalVertexDistance = fog_spherical_distance(param);
    float3 param_1 = Position;
    cylindricalVertexDistance = fog_cylindrical_distance(param_1);
    int2 param_2 = UV2;
    vertexColor = (Color * _80_ColorModulator) * sample_lightmap(Sampler2, _Sampler2_sampler, param_2);
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    Position = stage_input.Position;
    Color = stage_input.Color;
    UV2 = stage_input.UV2;
    vert_main();
    SPIRV_Cross_Output stage_output;
    stage_output.gl_Position = gl_Position;
    stage_output.sphericalVertexDistance = sphericalVertexDistance;
    stage_output.cylindricalVertexDistance = cylindricalVertexDistance;
    stage_output.vertexColor = vertexColor;
    return stage_output;
}
