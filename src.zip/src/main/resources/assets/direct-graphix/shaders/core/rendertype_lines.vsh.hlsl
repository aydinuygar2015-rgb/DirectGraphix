cbuffer Projection : register(b2)
{
    row_major float4x4 _43_ProjMat : packoffset(c0);
};

cbuffer DynamicTransforms : register(b1)
{
    row_major float4x4 _60_ModelViewMat : packoffset(c0);
    row_major float4x4 _60_TextureMat : packoffset(c4);
    float4 _60_ColorModulator : packoffset(c8);
    float3 _60_ModelOffset : packoffset(c9);
};

cbuffer Globals : register(b0)
{
    int3 _113_CameraBlockPos : packoffset(c0);
    float _113_GlintAlpha : packoffset(c0.w);
    float3 _113_CameraOffset : packoffset(c1);
    float _113_GameTime : packoffset(c1.w);
    float2 _113_ScreenSize : packoffset(c2);
    int _113_MenuBlurRadius : packoffset(c2.z);
    int _113_UseRgss : packoffset(c2.w);
};

cbuffer Fog : register(b0)
{
    float4 _205_FogColor : packoffset(c0);
    float _205_FogEnvironmentalStart : packoffset(c1);
    float _205_FogEnvironmentalEnd : packoffset(c1.y);
    float _205_FogRenderDistanceStart : packoffset(c1.z);
    float _205_FogRenderDistanceEnd : packoffset(c1.w);
    float _205_FogSkyEnd : packoffset(c2);
    float _205_FogCloudsEnd : packoffset(c2.y);
};


static float4 gl_Position;
static int gl_VertexIndex;
static float3 Position;
static float3 Normal;
static float LineWidth;
static float sphericalVertexDistance;
static float cylindricalVertexDistance;
static float4 vertexColor;
static float4 Color;

struct SPIRV_Cross_Input
{
    float3 Position : TEXCOORD0;
    float4 Color : TEXCOORD1;
    float3 Normal : TEXCOORD2;
    float LineWidth : TEXCOORD3;
    uint gl_VertexIndex : SV_VertexID;
};

struct SPIRV_Cross_Output
{
    float sphericalVertexDistance : TEXCOORD0;
    float cylindricalVertexDistance : TEXCOORD1;
    float4 vertexColor : TEXCOORD2;
    float4 gl_Position : SV_Position;
};

float fog_spherical_distance(float3 pos)
{
    return length(pos);
}

float fog_cylindrical_distance(float3 pos)
{
    float distXZ = length(pos.xz);
    float distY = abs(pos.y);
    return max(distXZ, distY);
}

void vert_main()
{
    float4 linePosStart = mul(float4(Position, 1.0f), mul(_60_ModelViewMat, mul(float4x4(float4(0.99609375f, 0.0f, 0.0f, 0.0f), float4(0.0f, 0.99609375f, 0.0f, 0.0f), float4(0.0f, 0.0f, 0.99609375f, 0.0f), float4(0.0f, 0.0f, 0.0f, 1.0f)), _43_ProjMat)));
    float4 linePosEnd = mul(float4(Position + Normal, 1.0f), mul(_60_ModelViewMat, mul(float4x4(float4(0.99609375f, 0.0f, 0.0f, 0.0f), float4(0.0f, 0.99609375f, 0.0f, 0.0f), float4(0.0f, 0.0f, 0.99609375f, 0.0f), float4(0.0f, 0.0f, 0.0f, 1.0f)), _43_ProjMat)));
    float3 ndc1 = linePosStart.xyz / linePosStart.w.xxx;
    float3 ndc2 = linePosEnd.xyz / linePosEnd.w.xxx;
    float2 lineScreenDirection = normalize((ndc2.xy - ndc1.xy) * _113_ScreenSize);
    float2 lineOffset = (float2(-lineScreenDirection.y, lineScreenDirection.x) * LineWidth) / _113_ScreenSize;
    if (lineOffset.x < 0.0f)
    {
        lineOffset *= (-1.0f);
    }
    if ((gl_VertexIndex % 2) == 0)
    {
        gl_Position = float4((ndc1 + float3(lineOffset, 0.0f)) * linePosStart.w, linePosStart.w);
    }
    else
    {
        gl_Position = float4((ndc1 - float3(lineOffset, 0.0f)) * linePosStart.w, linePosStart.w);
    }
    float3 param = Position;
    sphericalVertexDistance = fog_spherical_distance(param);
    float3 param_1 = Position;
    cylindricalVertexDistance = fog_cylindrical_distance(param_1);
    vertexColor = Color;
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    gl_VertexIndex = int(stage_input.gl_VertexIndex);
    Position = stage_input.Position;
    Normal = stage_input.Normal;
    LineWidth = stage_input.LineWidth;
    Color = stage_input.Color;
    vert_main();
    SPIRV_Cross_Output stage_output;
    stage_output.gl_Position = gl_Position;
    stage_output.sphericalVertexDistance = sphericalVertexDistance;
    stage_output.cylindricalVertexDistance = cylindricalVertexDistance;
    stage_output.vertexColor = vertexColor;
    return stage_output;
}
