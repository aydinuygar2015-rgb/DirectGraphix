cbuffer DynamicTransforms : register(b0)
{
    row_major float4x4 _17_ModelViewMat : packoffset(c0);
    row_major float4x4 _17_TextureMat : packoffset(c4);
    float4 _17_ColorModulator : packoffset(c8);
    float3 _17_ModelOffset : packoffset(c9);
};

cbuffer Projection : register(b1)
{
    row_major float4x4 _33_ProjMat : packoffset(c0);
};


static float4 gl_Position;
static float3 Position;
static float2 texCoord0;
static float2 UV0;

struct SPIRV_Cross_Input
{
    float3 Position : TEXCOORD0;
    float2 UV0 : TEXCOORD1;
};

struct SPIRV_Cross_Output
{
    float2 texCoord0 : TEXCOORD0;
    float4 gl_Position : SV_Position;
};

void vert_main()
{
    float3 pos = Position + _17_ModelOffset;
    gl_Position = mul(float4(pos, 1.0f), mul(_17_ModelViewMat, _33_ProjMat));
    texCoord0 = mul(float4(UV0, 0.0f, 1.0f), _17_TextureMat).xy;
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    Position = stage_input.Position;
    UV0 = stage_input.UV0;
    vert_main();
    SPIRV_Cross_Output stage_output;
    stage_output.gl_Position = gl_Position;
    stage_output.texCoord0 = texCoord0;
    return stage_output;
}
