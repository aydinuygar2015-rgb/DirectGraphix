Texture2D<float4> InSampler : register(t0);
SamplerState _InSampler_sampler : register(s0);

static float4 gl_FragCoord;
static float gl_FragDepth;
static float2 texCoord;

struct SPIRV_Cross_Input
{
    float2 texCoord : TEXCOORD0;
    float4 gl_FragCoord : SV_Position;
};

struct SPIRV_Cross_Output
{
    float gl_FragDepth : SV_Depth;
};

void frag_main()
{
    float depth = InSampler.Load(int3(int2(gl_FragCoord.xy), 0)).x;
    if (depth == 0.0f)
    {
        discard;
    }
    gl_FragDepth = depth;
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    gl_FragCoord = stage_input.gl_FragCoord;
    gl_FragCoord.w = 1.0 / gl_FragCoord.w;
    texCoord = stage_input.texCoord;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.gl_FragDepth = gl_FragDepth;
    return stage_output;
}
