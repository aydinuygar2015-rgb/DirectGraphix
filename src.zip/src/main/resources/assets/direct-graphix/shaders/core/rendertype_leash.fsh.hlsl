cbuffer Fog : register(b0)
{
    float4 _122_FogColor : packoffset(c0);
    float _122_FogEnvironmentalStart : packoffset(c1);
    float _122_FogEnvironmentalEnd : packoffset(c1.y);
    float _122_FogRenderDistanceStart : packoffset(c1.z);
    float _122_FogRenderDistanceEnd : packoffset(c1.w);
    float _122_FogSkyEnd : packoffset(c2);
    float _122_FogCloudsEnd : packoffset(c2.y);
};


static float4 fragColor;
static float4 vertexColor;
static float sphericalVertexDistance;
static float cylindricalVertexDistance;

struct SPIRV_Cross_Input
{
    float sphericalVertexDistance : TEXCOORD0;
    float cylindricalVertexDistance : TEXCOORD1;
    nointerpolation float4 vertexColor : TEXCOORD2;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

float linear_fog_value(float vertexDistance, float fogStart, float fogEnd)
{
    if (vertexDistance <= fogStart)
    {
        return 0.0f;
    }
    else
    {
        if (vertexDistance >= fogEnd)
        {
            return 1.0f;
        }
    }
    return (vertexDistance - fogStart) / (fogEnd - fogStart);
}

float total_fog_value(float sphericalVertexDistance_1, float cylindricalVertexDistance_1, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd)
{
    float param = sphericalVertexDistance_1;
    float param_1 = environmentalStart;
    float param_2 = environmantalEnd;
    float param_3 = cylindricalVertexDistance_1;
    float param_4 = renderDistanceStart;
    float param_5 = renderDistanceEnd;
    return max(linear_fog_value(param, param_1, param_2), linear_fog_value(param_3, param_4, param_5));
}

float4 apply_fog(float4 inColor, float sphericalVertexDistance_1, float cylindricalVertexDistance_1, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd, float4 fogColor)
{
    float param = sphericalVertexDistance_1;
    float param_1 = cylindricalVertexDistance_1;
    float param_2 = environmentalStart;
    float param_3 = environmantalEnd;
    float param_4 = renderDistanceStart;
    float param_5 = renderDistanceEnd;
    float fogValue = total_fog_value(param, param_1, param_2, param_3, param_4, param_5);
    return float4(lerp(inColor.xyz, fogColor.xyz, (fogValue * fogColor.w).xxx), inColor.w);
}

void frag_main()
{
    float4 param = vertexColor;
    float param_1 = sphericalVertexDistance;
    float param_2 = cylindricalVertexDistance;
    float param_3 = _122_FogEnvironmentalStart;
    float param_4 = _122_FogEnvironmentalEnd;
    float param_5 = _122_FogRenderDistanceStart;
    float param_6 = _122_FogRenderDistanceEnd;
    float4 param_7 = _122_FogColor;
    fragColor = apply_fog(param, param_1, param_2, param_3, param_4, param_5, param_6, param_7);
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    vertexColor = stage_input.vertexColor;
    sphericalVertexDistance = stage_input.sphericalVertexDistance;
    cylindricalVertexDistance = stage_input.cylindricalVertexDistance;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
