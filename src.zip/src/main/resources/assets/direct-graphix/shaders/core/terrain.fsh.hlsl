static const float2 _311[4] = { float2(0.125f, 0.375f), float2(-0.125f, -0.375f), float2(0.375f, -0.125f), float2(-0.375f, 0.125f) };

cbuffer Fog : register(b0)
{
    float4 _368_FogColor : packoffset(c0);
    float _368_FogEnvironmentalStart : packoffset(c1);
    float _368_FogEnvironmentalEnd : packoffset(c1.y);
    float _368_FogRenderDistanceStart : packoffset(c1.z);
    float _368_FogRenderDistanceEnd : packoffset(c1.w);
    float _368_FogSkyEnd : packoffset(c2);
    float _368_FogCloudsEnd : packoffset(c2.y);
};

cbuffer Globals : register(b1)
{
    int3 _405_CameraBlockPos : packoffset(c0);
    float _405_GlintAlpha : packoffset(c0.w);
    float3 _405_CameraOffset : packoffset(c1);
    float _405_GameTime : packoffset(c1.w);
    float2 _405_ScreenSize : packoffset(c2);
    int _405_MenuBlurRadius : packoffset(c2.z);
    int _405_UseRgss : packoffset(c2.w);
};

cbuffer TerrainUniform : register(b2)
{
    row_major float4x4 _421_ModelViewMat : packoffset(c0);
    int2 _421_TextureSize : packoffset(c4);
};

cbuffer ChunkSection : register(b0)
{
    int3 _465_ChunkPosition : packoffset(c0);
    float _465_ChunkVisibility : packoffset(c0.w);
};

Texture2D<float4> Sampler0 : register(t3);
SamplerState _Sampler0_sampler : register(s3);

static float sphericalVertexDistance;
static float cylindricalVertexDistance;
static float2 texCoord0;
static float4 vertexColor;
static float chunkVisibility;
static float4 fragColor;

struct SPIRV_Cross_Input
{
    float sphericalVertexDistance : TEXCOORD0;
    float cylindricalVertexDistance : TEXCOORD1;
    float4 vertexColor : TEXCOORD2;
    float2 texCoord0 : TEXCOORD3;
    float chunkVisibility : TEXCOORD4;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

float4 sampleNearest(Texture2D<float4> source, SamplerState _source_sampler, inout float2 uv, float2 pixelSize, float2 du, float2 dv, float2 texelScreenSize)
{
    float2 uvTexelCoords = uv / pixelSize;
    float2 texelCenter = round(uvTexelCoords) - 0.5f.xx;
    float2 texelOffset = uvTexelCoords - texelCenter;
    texelOffset = (((texelOffset - 0.5f.xx) * pixelSize) / texelScreenSize) + 0.5f.xx;
    texelOffset = clamp(texelOffset, 0.0f.xx, 1.0f.xx);
    uv = (texelCenter + texelOffset) * pixelSize;
    return source.SampleGrad(_source_sampler, uv, du, dv);
}

float4 sampleRGSS(Texture2D<float4> source, SamplerState _source_sampler, float2 uv, float2 pixelSize)
{
    float2 du = ddx(uv);
    float2 dv = ddy(uv);
    float2 texelScreenSize = sqrt((du * du) + (dv * dv));
    float maxTexelSize = max(texelScreenSize.x, texelScreenSize.y);
    float minPixelSize = min(pixelSize.x, pixelSize.y);
    float transitionStart = minPixelSize * 1.0f;
    float transitionEnd = minPixelSize * 2.0f;
    float blendFactor = smoothstep(transitionStart, transitionEnd, maxTexelSize);
    float duLength = length(du);
    float dvLength = length(dv);
    float minDerivative = min(duLength, dvLength);
    float maxDerivative = max(duLength, dvLength);
    float effectiveDerivative = sqrt(minDerivative * maxDerivative);
    float mipLevelExact = max(0.0f, log2(effectiveDerivative / minPixelSize));
    float mipLevelLow = floor(mipLevelExact);
    float mipLevelHigh = mipLevelLow + 1.0f;
    float mipBlend = frac(mipLevelExact);
    float4 rgssColorLow = 0.0f.xxxx;
    float4 rgssColorHigh = 0.0f.xxxx;
    for (int i = 0; i < 4; i++)
    {
        float2 sampleUV = uv + (_311[i] * pixelSize);
        rgssColorLow += source.SampleLevel(_source_sampler, sampleUV, mipLevelLow);
        rgssColorHigh += source.SampleLevel(_source_sampler, sampleUV, mipLevelHigh);
    }
    rgssColorLow *= 0.25f;
    rgssColorHigh *= 0.25f;
    float4 rgssColor = lerp(rgssColorLow, rgssColorHigh, mipBlend.xxxx);
    float2 param = uv;
    float2 param_1 = pixelSize;
    float2 param_2 = du;
    float2 param_3 = dv;
    float2 param_4 = texelScreenSize;
    float4 _357 = sampleNearest(source, _source_sampler, param, param_1, param_2, param_3, param_4);
    float4 nearestColor = _357;
    return lerp(nearestColor, rgssColor, blendFactor.xxxx);
}

float4 sampleNearest(Texture2D<float4> source, SamplerState _source_sampler, float2 uv, float2 pixelSize)
{
    float2 du = ddx(uv);
    float2 dv = ddy(uv);
    float2 texelScreenSize = sqrt((du * du) + (dv * dv));
    float2 param = uv;
    float2 param_1 = pixelSize;
    float2 param_2 = du;
    float2 param_3 = dv;
    float2 param_4 = texelScreenSize;
    float4 _206 = sampleNearest(source, _source_sampler, param, param_1, param_2, param_3, param_4);
    return _206;
}

float linear_fog_value(float vertexDistance, float fogStart, float fogEnd)
{
    if (vertexDistance <= fogStart)
    {
        return 0.0f;
    }
    else
    {
        if (vertexDistance >= fogEnd)
        {
            return 1.0f;
        }
    }
    return (vertexDistance - fogStart) / (fogEnd - fogStart);
}

float total_fog_value(float sphericalVertexDistance_1, float cylindricalVertexDistance_1, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd)
{
    float param = sphericalVertexDistance_1;
    float param_1 = environmentalStart;
    float param_2 = environmantalEnd;
    float param_3 = cylindricalVertexDistance_1;
    float param_4 = renderDistanceStart;
    float param_5 = renderDistanceEnd;
    return max(linear_fog_value(param, param_1, param_2), linear_fog_value(param_3, param_4, param_5));
}

float4 apply_fog(float4 inColor, float sphericalVertexDistance_1, float cylindricalVertexDistance_1, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd, float4 fogColor)
{
    float param = sphericalVertexDistance_1;
    float param_1 = cylindricalVertexDistance_1;
    float param_2 = environmentalStart;
    float param_3 = environmantalEnd;
    float param_4 = renderDistanceStart;
    float param_5 = renderDistanceEnd;
    float fogValue = total_fog_value(param, param_1, param_2, param_3, param_4, param_5);
    return float4(lerp(inColor.xyz, fogColor.xyz, (fogValue * fogColor.w).xxx), inColor.w);
}

float4 calculateFinalColor(float4 color)
{
    float4 fogColor = _368_FogColor;
    float4 param = color;
    float param_1 = sphericalVertexDistance;
    float param_2 = cylindricalVertexDistance;
    float param_3 = _368_FogEnvironmentalStart;
    float param_4 = _368_FogEnvironmentalEnd;
    float param_5 = _368_FogRenderDistanceStart;
    float param_6 = _368_FogRenderDistanceEnd;
    float4 param_7 = fogColor;
    return apply_fog(param, param_1, param_2, param_3, param_4, param_5, param_6, param_7);
}

void frag_main()
{
    float4 _411;
    if (_405_UseRgss == 1)
    {
        float2 param = texCoord0;
        float2 param_1 = 1.0f.xx / float2(_421_TextureSize);
        _411 = sampleRGSS(Sampler0, _Sampler0_sampler, param, param_1);
    }
    else
    {
        float2 param_2 = texCoord0;
        float2 param_3 = 1.0f.xx / float2(_421_TextureSize);
        _411 = sampleNearest(Sampler0, _Sampler0_sampler, param_2, param_3);
    }
    float4 color = _411 * vertexColor;
    color = lerp(_368_FogColor * float4(1.0f, 1.0f, 1.0f, color.w), color, chunkVisibility.xxxx);
    float4 param_4 = color;
    fragColor = calculateFinalColor(param_4);
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    sphericalVertexDistance = stage_input.sphericalVertexDistance;
    cylindricalVertexDistance = stage_input.cylindricalVertexDistance;
    texCoord0 = stage_input.texCoord0;
    vertexColor = stage_input.vertexColor;
    chunkVisibility = stage_input.chunkVisibility;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
