cbuffer SpriteAnimationInfo : register(b0)
{
    row_major float4x4 _23_ProjectionMatrix : packoffset(c0);
    row_major float4x4 _23_SpriteMatrix : packoffset(c4);
    float _23_UPadding : packoffset(c8);
    float _23_VPadding : packoffset(c8.y);
    int _23_MipMapLevel : packoffset(c8.z);
};

Texture2D<float4> CurrentSprite : register(t1);
SamplerState _CurrentSprite_sampler : register(s1);
Texture2D<float4> NextSprite : register(t2);
SamplerState _NextSprite_sampler : register(s2);

static float2 texCoord0;
static float4 fragColor;
static float fAnimationProgress;

struct SPIRV_Cross_Input
{
    float fAnimationProgress : TEXCOORD0;
    float2 texCoord0 : TEXCOORD1;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

void frag_main()
{
    float4 currentColor = CurrentSprite.SampleLevel(_CurrentSprite_sampler, texCoord0, float(_23_MipMapLevel));
    float4 nextColor = NextSprite.SampleLevel(_NextSprite_sampler, texCoord0, float(_23_MipMapLevel));
    fragColor = lerp(currentColor, nextColor, fAnimationProgress.xxxx);
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    texCoord0 = stage_input.texCoord0;
    fAnimationProgress = stage_input.fAnimationProgress;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
