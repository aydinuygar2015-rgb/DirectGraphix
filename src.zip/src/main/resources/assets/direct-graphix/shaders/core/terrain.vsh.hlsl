cbuffer ChunkSection : register(b3)
{
    int3 _73_ChunkPosition : packoffset(c0);
    float _73_ChunkVisibility : packoffset(c0.w);
};

cbuffer Globals : register(b0)
{
    int3 _80_CameraBlockPos : packoffset(c0);
    float _80_GlintAlpha : packoffset(c0.w);
    float3 _80_CameraOffset : packoffset(c1);
    float _80_GameTime : packoffset(c1.w);
    float2 _80_ScreenSize : packoffset(c2);
    int _80_MenuBlurRadius : packoffset(c2.z);
    int _80_UseRgss : packoffset(c2.w);
};

cbuffer Projection : register(b1)
{
    row_major float4x4 _98_ProjMat : packoffset(c0);
};

cbuffer TerrainUniform : register(b2)
{
    row_major float4x4 _104_ModelViewMat : packoffset(c0);
    int2 _104_TextureSize : packoffset(c4);
};

cbuffer Fog : register(b0)
{
    float4 _158_FogColor : packoffset(c0);
    float _158_FogEnvironmentalStart : packoffset(c1);
    float _158_FogEnvironmentalEnd : packoffset(c1.y);
    float _158_FogRenderDistanceStart : packoffset(c1.z);
    float _158_FogRenderDistanceEnd : packoffset(c1.w);
    float _158_FogSkyEnd : packoffset(c2);
    float _158_FogCloudsEnd : packoffset(c2.y);
};

Texture2D<float4> Sampler2 : register(t4);
SamplerState _Sampler2_sampler : register(s4);

static float4 gl_Position;
static float3 Position;
static float sphericalVertexDistance;
static float cylindricalVertexDistance;
static float4 vertexColor;
static float4 Color;
static int2 UV2;
static float2 texCoord0;
static float2 UV0;
static float chunkVisibility;

struct SPIRV_Cross_Input
{
    float3 Position : TEXCOORD0;
    float4 Color : TEXCOORD1;
    float2 UV0 : TEXCOORD2;
    int2 UV2 : TEXCOORD3;
};

struct SPIRV_Cross_Output
{
    float sphericalVertexDistance : TEXCOORD0;
    float cylindricalVertexDistance : TEXCOORD1;
    float4 vertexColor : TEXCOORD2;
    float2 texCoord0 : TEXCOORD3;
    float chunkVisibility : TEXCOORD4;
    float4 gl_Position : SV_Position;
};

float fog_spherical_distance(float3 pos)
{
    return length(pos);
}

float fog_cylindrical_distance(float3 pos)
{
    float distXZ = length(pos.xz);
    float distY = abs(pos.y);
    return max(distXZ, distY);
}

float4 sample_lightmap(Texture2D<float4> lightMap, SamplerState _lightMap_sampler, int2 uv)
{
    return lightMap.SampleLevel(_lightMap_sampler, clamp((float2(uv) / 256.0f.xx) + 0.03125f.xx, 0.03125f.xx, 0.96875f.xx), 0.0f);
}

void vert_main()
{
    float3 pos = (Position + float3(_73_ChunkPosition - _80_CameraBlockPos)) + _80_CameraOffset;
    gl_Position = mul(float4(pos, 1.0f), mul(_104_ModelViewMat, _98_ProjMat));
    float3 param = pos;
    sphericalVertexDistance = fog_spherical_distance(param);
    float3 param_1 = pos;
    cylindricalVertexDistance = fog_cylindrical_distance(param_1);
    int2 param_2 = UV2;
    vertexColor = Color * sample_lightmap(Sampler2, _Sampler2_sampler, param_2);
    texCoord0 = UV0;
    float dist = length(pos);
    chunkVisibility = lerp(1.0f, _73_ChunkVisibility, clamp((dist - 16.0f) / 16.0f, 0.0f, 1.0f));
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    Position = stage_input.Position;
    Color = stage_input.Color;
    UV2 = stage_input.UV2;
    UV0 = stage_input.UV0;
    vert_main();
    SPIRV_Cross_Output stage_output;
    stage_output.gl_Position = gl_Position;
    stage_output.sphericalVertexDistance = sphericalVertexDistance;
    stage_output.cylindricalVertexDistance = cylindricalVertexDistance;
    stage_output.vertexColor = vertexColor;
    stage_output.texCoord0 = texCoord0;
    stage_output.chunkVisibility = chunkVisibility;
    return stage_output;
}
