cbuffer Fog : register(b0)
{
    float4 _144_FogColor : packoffset(c0);
    float _144_FogEnvironmentalStart : packoffset(c1);
    float _144_FogEnvironmentalEnd : packoffset(c1.y);
    float _144_FogRenderDistanceStart : packoffset(c1.z);
    float _144_FogRenderDistanceEnd : packoffset(c1.w);
    float _144_FogSkyEnd : packoffset(c2);
    float _144_FogCloudsEnd : packoffset(c2.y);
};

cbuffer DynamicTransforms : register(b1)
{
    row_major float4x4 _196_ModelViewMat : packoffset(c0);
    row_major float4x4 _196_TextureMat : packoffset(c4);
    float4 _196_ColorModulator : packoffset(c8);
    float3 _196_ModelOffset : packoffset(c9);
};

Texture2D<float4> Sampler0 : register(t2);
SamplerState _Sampler0_sampler : register(s2);

static float4 overlayColor;
static float4 lightMapColor;
static float sphericalVertexDistance;
static float cylindricalVertexDistance;
static float2 texCoord0;
static float4 vertexColor;
static float4 fragColor;

struct SPIRV_Cross_Input
{
    float sphericalVertexDistance : TEXCOORD0;
    float cylindricalVertexDistance : TEXCOORD1;
    float4 vertexColor : TEXCOORD2;
    float4 lightMapColor : TEXCOORD3;
    float4 overlayColor : TEXCOORD4;
    float2 texCoord0 : TEXCOORD5;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

float linear_fog_value(float vertexDistance, float fogStart, float fogEnd)
{
    if (vertexDistance <= fogStart)
    {
        return 0.0f;
    }
    else
    {
        if (vertexDistance >= fogEnd)
        {
            return 1.0f;
        }
    }
    return (vertexDistance - fogStart) / (fogEnd - fogStart);
}

float total_fog_value(float sphericalVertexDistance_1, float cylindricalVertexDistance_1, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd)
{
    float param = sphericalVertexDistance_1;
    float param_1 = environmentalStart;
    float param_2 = environmantalEnd;
    float param_3 = cylindricalVertexDistance_1;
    float param_4 = renderDistanceStart;
    float param_5 = renderDistanceEnd;
    return max(linear_fog_value(param, param_1, param_2), linear_fog_value(param_3, param_4, param_5));
}

float4 apply_fog(float4 inColor, float sphericalVertexDistance_1, float cylindricalVertexDistance_1, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd, float4 fogColor)
{
    float param = sphericalVertexDistance_1;
    float param_1 = cylindricalVertexDistance_1;
    float param_2 = environmentalStart;
    float param_3 = environmantalEnd;
    float param_4 = renderDistanceStart;
    float param_5 = renderDistanceEnd;
    float fogValue = total_fog_value(param, param_1, param_2, param_3, param_4, param_5);
    return float4(lerp(inColor.xyz, fogColor.xyz, (fogValue * fogColor.w).xxx), inColor.w);
}

float4 calculateFinalColor(inout float4 color)
{
    float4 _121 = color;
    float3 _127 = lerp(overlayColor.xyz, _121.xyz, overlayColor.w.xxx);
    color.x = _127.x;
    color.y = _127.y;
    color.z = _127.z;
    color *= lightMapColor;
    float4 fogColor = _144_FogColor;
    float4 param = color;
    float param_1 = sphericalVertexDistance;
    float param_2 = cylindricalVertexDistance;
    float param_3 = _144_FogEnvironmentalStart;
    float param_4 = _144_FogEnvironmentalEnd;
    float param_5 = _144_FogRenderDistanceStart;
    float param_6 = _144_FogRenderDistanceEnd;
    float4 param_7 = fogColor;
    return apply_fog(param, param_1, param_2, param_3, param_4, param_5, param_6, param_7);
}

void frag_main()
{
    float4 color = Sampler0.Sample(_Sampler0_sampler, texCoord0);
    color *= (vertexColor * _196_ColorModulator);
    float4 param = color;
    float4 _206 = calculateFinalColor(param);
    fragColor = _206;
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    overlayColor = stage_input.overlayColor;
    lightMapColor = stage_input.lightMapColor;
    sphericalVertexDistance = stage_input.sphericalVertexDistance;
    cylindricalVertexDistance = stage_input.cylindricalVertexDistance;
    texCoord0 = stage_input.texCoord0;
    vertexColor = stage_input.vertexColor;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
