cbuffer SpriteAnimationInfo : register(b0)
{
    row_major float4x4 _23_ProjectionMatrix : packoffset(c0);
    row_major float4x4 _23_SpriteMatrix : packoffset(c4);
    float _23_UPadding : packoffset(c8);
    float _23_VPadding : packoffset(c8.y);
    int _23_MipMapLevel : packoffset(c8.z);
};

Texture2D<float4> Sprite : register(t1);
SamplerState _Sprite_sampler : register(s1);

static float2 texCoord0;
static float4 fragColor;

struct SPIRV_Cross_Input
{
    float2 texCoord0 : TEXCOORD1;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

void frag_main()
{
    float4 color = Sprite.SampleLevel(_Sprite_sampler, texCoord0, float(_23_MipMapLevel));
    fragColor = color;
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    texCoord0 = stage_input.texCoord0;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
