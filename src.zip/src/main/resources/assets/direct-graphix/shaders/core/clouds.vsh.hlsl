static const float4 _206[6] = { float4(0.699999988079071044921875f, 0.699999988079071044921875f, 0.699999988079071044921875f, 1.0f), 1.0f.xxxx, float4(0.800000011920928955078125f, 0.800000011920928955078125f, 0.800000011920928955078125f, 1.0f), float4(0.800000011920928955078125f, 0.800000011920928955078125f, 0.800000011920928955078125f, 1.0f), float4(0.89999997615814208984375f, 0.89999997615814208984375f, 0.89999997615814208984375f, 1.0f), float4(0.89999997615814208984375f, 0.89999997615814208984375f, 0.89999997615814208984375f, 1.0f) };

cbuffer CloudInfo : register(b2)
{
    float4 _141_CloudColor : packoffset(c0);
    float3 _141_CloudOffset : packoffset(c1);
    float3 _141_CellSize : packoffset(c2);
};

cbuffer Projection : register(b1)
{
    row_major float4x4 _166_ProjMat : packoffset(c0);
};

cbuffer DynamicTransforms : register(b0)
{
    row_major float4x4 _172_ModelViewMat : packoffset(c0);
    row_major float4x4 _172_TextureMat : packoffset(c4);
    float4 _172_ColorModulator : packoffset(c8);
    float3 _172_ModelOffset : packoffset(c9);
};

cbuffer Fog : register(b0)
{
    float4 _219_FogColor : packoffset(c0);
    float _219_FogEnvironmentalStart : packoffset(c1);
    float _219_FogEnvironmentalEnd : packoffset(c1.y);
    float _219_FogRenderDistanceStart : packoffset(c1.z);
    float _219_FogRenderDistanceEnd : packoffset(c1.w);
    float _219_FogSkyEnd : packoffset(c2);
    float _219_FogCloudsEnd : packoffset(c2.y);
};

Buffer<int4> CloudFaces : register(t3);

static float4 gl_Position;
static int gl_VertexIndex;
static float vertexDistance;
static float4 vertexColor;

struct SPIRV_Cross_Input
{
    uint gl_VertexIndex : SV_VertexID;
};

struct SPIRV_Cross_Output
{
    float vertexDistance : TEXCOORD0;
    float4 vertexColor : TEXCOORD1;
    float4 gl_Position : SV_Position;
};

float3 vertex(int index)
{
    float3 pos = 0.0f.xxx;
    pos.x = float((15744195 >> index) & 1);
    pos.y = float((6711024 >> index) & 1);
    pos.z = float((12841062 >> index) & 1);
    return pos;
}

float fog_spherical_distance(float3 pos)
{
    return length(pos);
}

void vert_main()
{
    int quadVertex = gl_VertexIndex % 4;
    int index = (gl_VertexIndex / 4) * 3;
    int cellX = CloudFaces.Load(index).x;
    int cellZ = CloudFaces.Load(index + 1).x;
    int dirAndFlags = CloudFaces.Load(index + 2).x;
    int direction = dirAndFlags & 7;
    bool isInsideFace = (dirAndFlags & 16) == 16;
    bool useTopColor = (dirAndFlags & 32) == 32;
    cellX = (cellX << 1) | ((dirAndFlags & 128) >> 7);
    cellZ = (cellZ << 1) | ((dirAndFlags & 64) >> 6);
    int _125;
    if (isInsideFace)
    {
        _125 = 3 - quadVertex;
    }
    else
    {
        _125 = quadVertex;
    }
    int param = (direction * 4) + _125;
    float3 faceVertex = vertex(param);
    float3 pos = ((faceVertex * _141_CellSize) + (float3(float(cellX), 0.0f, float(cellZ)) * _141_CellSize)) + _141_CloudOffset;
    gl_Position = mul(float4(pos, 1.0f), mul(_172_ModelViewMat, _166_ProjMat));
    float3 param_1 = pos;
    vertexDistance = fog_spherical_distance(param_1);
    float4 _193;
    if (useTopColor)
    {
        _193 = 1.0f.xxxx;
    }
    else
    {
        _193 = _206[direction];
    }
    vertexColor = _193 * _141_CloudColor;
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    gl_VertexIndex = int(stage_input.gl_VertexIndex);
    vert_main();
    SPIRV_Cross_Output stage_output;
    stage_output.gl_Position = gl_Position;
    stage_output.vertexDistance = vertexDistance;
    stage_output.vertexColor = vertexColor;
    return stage_output;
}
