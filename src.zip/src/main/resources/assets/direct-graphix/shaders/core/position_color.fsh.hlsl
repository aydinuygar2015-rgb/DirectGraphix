cbuffer DynamicTransforms : register(b0)
{
    row_major float4x4 _35_ModelViewMat : packoffset(c0);
    row_major float4x4 _35_TextureMat : packoffset(c4);
    float4 _35_ColorModulator : packoffset(c8);
    float3 _35_ModelOffset : packoffset(c9);
};


static float4 vertexColor;
static float4 fragColor;

struct SPIRV_Cross_Input
{
    float4 vertexColor : TEXCOORD0;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

float4 calculateFinalColor(float4 color)
{
    return color;
}

void frag_main()
{
    float4 color = vertexColor;
    if (color.w == 0.0f)
    {
        discard;
    }
    color *= _35_ColorModulator;
    float4 param = color;
    fragColor = calculateFinalColor(param);
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    vertexColor = stage_input.vertexColor;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
