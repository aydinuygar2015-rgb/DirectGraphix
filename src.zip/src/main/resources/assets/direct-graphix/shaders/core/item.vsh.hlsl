cbuffer Projection : register(b2)
{
    row_major float4x4 _148_ProjMat : packoffset(c0);
};

cbuffer DynamicTransforms : register(b1)
{
    row_major float4x4 _154_ModelViewMat : packoffset(c0);
    row_major float4x4 _154_TextureMat : packoffset(c4);
    float4 _154_ColorModulator : packoffset(c8);
    float3 _154_ModelOffset : packoffset(c9);
};

cbuffer Lighting : register(b0)
{
    float3 _180_Light0_Direction : packoffset(c0);
    float3 _180_Light1_Direction : packoffset(c1);
};

cbuffer Fog : register(b0)
{
    float4 _218_FogColor : packoffset(c0);
    float _218_FogEnvironmentalStart : packoffset(c1);
    float _218_FogEnvironmentalEnd : packoffset(c1.y);
    float _218_FogRenderDistanceStart : packoffset(c1.z);
    float _218_FogRenderDistanceEnd : packoffset(c1.w);
    float _218_FogSkyEnd : packoffset(c2);
    float _218_FogCloudsEnd : packoffset(c2.y);
};

Texture2D<float4> Sampler2 : register(t4);
SamplerState _Sampler2_sampler : register(s4);
Texture2D<float4> Sampler1 : register(t3);
SamplerState _Sampler1_sampler : register(s3);

static float4 gl_Position;
static float3 Position;
static float sphericalVertexDistance;
static float cylindricalVertexDistance;
static float4 vertexColor;
static float3 Normal;
static float4 Color;
static float4 lightMapColor;
static int2 UV2;
static float4 overlayColor;
static int2 UV1;
static float2 texCoord0;
static float2 UV0;

struct SPIRV_Cross_Input
{
    float3 Position : TEXCOORD0;
    float4 Color : TEXCOORD1;
    float2 UV0 : TEXCOORD2;
    int2 UV1 : TEXCOORD3;
    int2 UV2 : TEXCOORD4;
    float3 Normal : TEXCOORD6;
};

struct SPIRV_Cross_Output
{
    float sphericalVertexDistance : TEXCOORD0;
    float cylindricalVertexDistance : TEXCOORD1;
    float4 vertexColor : TEXCOORD2;
    float4 lightMapColor : TEXCOORD3;
    float4 overlayColor : TEXCOORD4;
    float2 texCoord0 : TEXCOORD5;
    float4 gl_Position : SV_Position;
};

float fog_spherical_distance(float3 pos)
{
    return length(pos);
}

float fog_cylindrical_distance(float3 pos)
{
    float distXZ = length(pos.xz);
    float distY = abs(pos.y);
    return max(distXZ, distY);
}

float2 minecraft_compute_light(float3 lightDir0, float3 lightDir1, float3 normal)
{
    return float2(dot(lightDir0, normal), dot(lightDir1, normal));
}

float4 minecraft_mix_light_separate(float2 light, float4 color)
{
    float2 lightValue = max(0.0f.xx, light);
    float lightAccum = min(1.0f, ((lightValue.x + lightValue.y) * 0.60000002384185791015625f) + 0.4000000059604644775390625f);
    return float4(color.xyz * lightAccum, color.w);
}

float4 minecraft_mix_light(float3 lightDir0, float3 lightDir1, float3 normal, float4 color)
{
    float3 param = lightDir0;
    float3 param_1 = lightDir1;
    float3 param_2 = normal;
    float2 light = minecraft_compute_light(param, param_1, param_2);
    float2 param_3 = light;
    float4 param_4 = color;
    return minecraft_mix_light_separate(param_3, param_4);
}

float4 sample_lightmap(Texture2D<float4> lightMap, SamplerState _lightMap_sampler, int2 uv)
{
    return lightMap.SampleLevel(_lightMap_sampler, clamp((float2(uv) / 256.0f.xx) + 0.03125f.xx, 0.03125f.xx, 0.96875f.xx), 0.0f);
}

void vert_main()
{
    gl_Position = mul(float4(Position, 1.0f), mul(_154_ModelViewMat, _148_ProjMat));
    float3 param = Position;
    sphericalVertexDistance = fog_spherical_distance(param);
    float3 param_1 = Position;
    cylindricalVertexDistance = fog_cylindrical_distance(param_1);
    float3 param_2 = _180_Light0_Direction;
    float3 param_3 = _180_Light1_Direction;
    float3 param_4 = Normal;
    float4 param_5 = Color;
    vertexColor = minecraft_mix_light(param_2, param_3, param_4, param_5);
    int2 param_6 = UV2;
    lightMapColor = sample_lightmap(Sampler2, _Sampler2_sampler, param_6);
    overlayColor = Sampler1.Load(int3(UV1, 0));
    texCoord0 = UV0;
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    Position = stage_input.Position;
    Normal = stage_input.Normal;
    Color = stage_input.Color;
    UV2 = stage_input.UV2;
    UV1 = stage_input.UV1;
    UV0 = stage_input.UV0;
    vert_main();
    SPIRV_Cross_Output stage_output;
    stage_output.gl_Position = gl_Position;
    stage_output.sphericalVertexDistance = sphericalVertexDistance;
    stage_output.cylindricalVertexDistance = cylindricalVertexDistance;
    stage_output.vertexColor = vertexColor;
    stage_output.lightMapColor = lightMapColor;
    stage_output.overlayColor = overlayColor;
    stage_output.texCoord0 = texCoord0;
    return stage_output;
}
