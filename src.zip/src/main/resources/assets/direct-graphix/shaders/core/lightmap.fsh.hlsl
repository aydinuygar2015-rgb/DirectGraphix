cbuffer LightmapInfo : register(b0)
{
    float lightmapInfo_SkyFactor : packoffset(c0);
    float lightmapInfo_BlockFactor : packoffset(c0.y);
    float lightmapInfo_NightVisionFactor : packoffset(c0.z);
    float lightmapInfo_DarknessScale : packoffset(c0.w);
    float lightmapInfo_BossOverlayWorldDarkeningFactor : packoffset(c1);
    float lightmapInfo_BrightnessFactor : packoffset(c1.y);
    float3 lightmapInfo_BlockLightTint : packoffset(c2);
    float3 lightmapInfo_SkyLightColor : packoffset(c3);
    float3 lightmapInfo_AmbientColor : packoffset(c4);
    float3 lightmapInfo_NightVisionColor : packoffset(c5);
};


static float2 texCoord;
static float4 fragColor;

struct SPIRV_Cross_Input
{
    float2 texCoord : TEXCOORD0;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

float get_brightness(float level)
{
    return level / (4.0f - (3.0f * level));
}

float parabolicMixFactor(float level)
{
    return ((2.0f * level) - 1.0f) * ((2.0f * level) - 1.0f);
}

float3 notGamma(float3 color)
{
    float maxComponent = max(max(color.x, color.y), color.z);
    float maxInverted = 1.0f - maxComponent;
    float maxScaled = 1.0f - (((maxInverted * maxInverted) * maxInverted) * maxInverted);
    return color * (maxScaled / maxComponent);
}

void frag_main()
{
    float block_level = floor(texCoord.x * 16.0f) / 15.0f;
    float sky_level = floor(texCoord.y * 16.0f) / 15.0f;
    float param = block_level;
    float block_brightness = get_brightness(param) * lightmapInfo_BlockFactor;
    float param_1 = sky_level;
    float sky_brightness = get_brightness(param_1) * lightmapInfo_SkyFactor;
    float3 nightVisionColor = lightmapInfo_NightVisionColor * lightmapInfo_NightVisionFactor;
    float3 color = max(lightmapInfo_AmbientColor, nightVisionColor);
    color += (lightmapInfo_SkyLightColor * sky_brightness);
    float param_2 = block_level;
    float3 BlockLightColor = lerp(lightmapInfo_BlockLightTint, 1.0f.xxx, (0.89999997615814208984375f * parabolicMixFactor(param_2)).xxx);
    color += (BlockLightColor * block_brightness);
    color = lerp(color, color * float3(0.699999988079071044921875f, 0.60000002384185791015625f, 0.60000002384185791015625f), lightmapInfo_BossOverlayWorldDarkeningFactor.xxx);
    color -= lightmapInfo_DarknessScale.xxx;
    color = clamp(color, 0.0f.xxx, 1.0f.xxx);
    float3 param_3 = color;
    float3 notGamma_1 = notGamma(param_3);
    color = lerp(color, notGamma_1, lightmapInfo_BrightnessFactor.xxx);
    fragColor = float4(color, 1.0f);
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    texCoord = stage_input.texCoord;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
