cbuffer Projection : register(b1)
{
    row_major float4x4 _47_ProjMat : packoffset(c0);
};

cbuffer DynamicTransforms : register(b0)
{
    row_major float4x4 _53_ModelViewMat : packoffset(c0);
    row_major float4x4 _53_TextureMat : packoffset(c4);
    float4 _53_ColorModulator : packoffset(c8);
    float3 _53_ModelOffset : packoffset(c9);
};

cbuffer Fog : register(b0)
{
    float4 _93_FogColor : packoffset(c0);
    float _93_FogEnvironmentalStart : packoffset(c1);
    float _93_FogEnvironmentalEnd : packoffset(c1.y);
    float _93_FogRenderDistanceStart : packoffset(c1.z);
    float _93_FogRenderDistanceEnd : packoffset(c1.w);
    float _93_FogSkyEnd : packoffset(c2);
    float _93_FogCloudsEnd : packoffset(c2.y);
};


static float4 gl_Position;
static float3 Position;
static float sphericalVertexDistance;
static float cylindricalVertexDistance;
static float2 texCoord0;
static float2 UV0;

struct SPIRV_Cross_Input
{
    float3 Position : TEXCOORD0;
    float2 UV0 : TEXCOORD1;
};

struct SPIRV_Cross_Output
{
    float sphericalVertexDistance : TEXCOORD0;
    float cylindricalVertexDistance : TEXCOORD1;
    float2 texCoord0 : TEXCOORD2;
    float4 gl_Position : SV_Position;
};

float fog_spherical_distance(float3 pos)
{
    return length(pos);
}

float fog_cylindrical_distance(float3 pos)
{
    float distXZ = length(pos.xz);
    float distY = abs(pos.y);
    return max(distXZ, distY);
}

void vert_main()
{
    gl_Position = mul(float4(Position, 1.0f), mul(_53_ModelViewMat, _47_ProjMat));
    float3 param = Position;
    sphericalVertexDistance = fog_spherical_distance(param);
    float3 param_1 = Position;
    cylindricalVertexDistance = fog_cylindrical_distance(param_1);
    texCoord0 = mul(float4(UV0, 0.0f, 1.0f), _53_TextureMat).xy;
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    Position = stage_input.Position;
    UV0 = stage_input.UV0;
    vert_main();
    SPIRV_Cross_Output stage_output;
    stage_output.gl_Position = gl_Position;
    stage_output.sphericalVertexDistance = sphericalVertexDistance;
    stage_output.cylindricalVertexDistance = cylindricalVertexDistance;
    stage_output.texCoord0 = texCoord0;
    return stage_output;
}
