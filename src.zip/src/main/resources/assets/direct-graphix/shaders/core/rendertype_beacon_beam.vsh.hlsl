cbuffer Projection : register(b1)
{
    row_major float4x4 _19_ProjMat : packoffset(c0);
};

cbuffer DynamicTransforms : register(b0)
{
    row_major float4x4 _26_ModelViewMat : packoffset(c0);
    row_major float4x4 _26_TextureMat : packoffset(c4);
    float4 _26_ColorModulator : packoffset(c8);
    float3 _26_ModelOffset : packoffset(c9);
};


static float4 gl_Position;
static float3 Position;
static float4 vertexColor;
static float4 Color;
static float2 texCoord0;
static float2 UV0;

struct SPIRV_Cross_Input
{
    float3 Position : TEXCOORD0;
    float4 Color : TEXCOORD1;
    float2 UV0 : TEXCOORD2;
};

struct SPIRV_Cross_Output
{
    float4 vertexColor : TEXCOORD0;
    float2 texCoord0 : TEXCOORD1;
    float4 gl_Position : SV_Position;
};

void vert_main()
{
    gl_Position = mul(float4(Position, 1.0f), mul(_26_ModelViewMat, _19_ProjMat));
    vertexColor = Color;
    texCoord0 = UV0;
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    Position = stage_input.Position;
    Color = stage_input.Color;
    UV0 = stage_input.UV0;
    vert_main();
    SPIRV_Cross_Output stage_output;
    stage_output.gl_Position = gl_Position;
    stage_output.vertexColor = vertexColor;
    stage_output.texCoord0 = texCoord0;
    return stage_output;
}
