cbuffer Projection : register(b0)
{
    row_major float4x4 _21_ProjMat : packoffset(c0);
};

Texture2D<float4> DepthBoundsSampler : register(t1);
SamplerState _DepthBoundsSampler_sampler : register(s1);

static float4 gl_FragCoord;
static float gl_FragDepth;
static float4 fragColor;
static float2 texCoord;

struct SPIRV_Cross_Input
{
    float2 texCoord : TEXCOORD0;
    float4 gl_FragCoord : SV_Position;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
    float gl_FragDepth : SV_Depth;
};

float deviceToLinearDepth(inout float deviceDepth)
{
    deviceDepth = (deviceDepth - 0.5f) * 2.0f;
    return _21_ProjMat[3].z / (deviceDepth + _21_ProjMat[2].z);
}

void frag_main()
{
    int2 pixelCoords = int2(gl_FragCoord.xy);
    float4 depthBounds = DepthBoundsSampler.Load(int3(pixelCoords, 0));
    float closestBoundLinearDepthNegated = depthBounds.x;
    float furthestBoundLinearDepth = depthBounds.y;
    float closestBoundDeviceDepth = depthBounds.z;
    float opaqueOitDeviceDepth = depthBounds.w;
    float param = opaqueOitDeviceDepth;
    float _75 = deviceToLinearDepth(param);
    float opaqueOitLinearDepth = _75;
    fragColor = float4(closestBoundLinearDepthNegated, min(furthestBoundLinearDepth, opaqueOitLinearDepth), closestBoundDeviceDepth, opaqueOitDeviceDepth);
    gl_FragDepth = opaqueOitDeviceDepth;
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    gl_FragCoord = stage_input.gl_FragCoord;
    gl_FragCoord.w = 1.0 / gl_FragCoord.w;
    texCoord = stage_input.texCoord;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.gl_FragDepth = gl_FragDepth;
    stage_output.fragColor = fragColor;
    return stage_output;
}
