TextureCube<float4> Sampler0 : register(t0);
SamplerState _Sampler0_sampler : register(s0);

static float4 fragColor;
static float3 texCoord0;

struct SPIRV_Cross_Input
{
    float3 texCoord0 : TEXCOORD0;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

void frag_main()
{
    fragColor = Sampler0.Sample(_Sampler0_sampler, texCoord0);
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    texCoord0 = stage_input.texCoord0;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
