static const float2 _60[6] = { 0.0f.xx, float2(1.0f, 0.0f), float2(0.0f, 1.0f), float2(0.0f, 1.0f), float2(1.0f, 0.0f), 1.0f.xx };

cbuffer SpriteAnimationInfo : register(b0)
{
    row_major float4x4 _30_ProjectionMatrix : packoffset(c0);
    row_major float4x4 _30_SpriteMatrix : packoffset(c4);
    float _30_UPadding : packoffset(c8);
    float _30_VPadding : packoffset(c8.y);
    int _30_MipMapLevel : packoffset(c8.z);
};


static float4 gl_Position;
static int gl_VertexIndex;
static float2 texCoord0;
static float fAnimationProgress;

struct SPIRV_Cross_Input
{
    uint gl_VertexIndex : SV_VertexID;
};

struct SPIRV_Cross_Output
{
    float fAnimationProgress : TEXCOORD0;
    float2 texCoord0 : TEXCOORD1;
    float4 gl_Position : SV_Position;
};

void vert_main()
{
    int index = gl_VertexIndex & 7;
    float frameProgress = float(gl_VertexIndex >> 3) / 1000.0f;
    float2 padding = float2(_30_UPadding, _30_VPadding);
    gl_Position = mul(float4(_60[index], 0.0f, 1.0f), mul(_30_SpriteMatrix, _30_ProjectionMatrix));
    float2 uv = _60[index];
    float2 direction = (uv * 2.0f) - 1.0f.xx;
    texCoord0 = uv + (padding * direction);
    fAnimationProgress = frameProgress;
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    gl_VertexIndex = int(stage_input.gl_VertexIndex);
    vert_main();
    SPIRV_Cross_Output stage_output;
    stage_output.gl_Position = gl_Position;
    stage_output.texCoord0 = texCoord0;
    stage_output.fAnimationProgress = fAnimationProgress;
    return stage_output;
}
