cbuffer Projection : register(b0)
{
    row_major float4x4 _385_ProjMat : packoffset(c0);
};

Texture2D<float4> Coeff0 : register(t0);
SamplerState _Coeff0_sampler : register(s0);
Texture2D<float4> Coeff1 : register(t1);
SamplerState _Coeff1_sampler : register(s1);
Texture2D<float4> Sampler0 : register(t2);
SamplerState _Sampler0_sampler : register(s2);
Texture2D<float4> DepthBoundsSampler : register(t3);
SamplerState _DepthBoundsSampler_sampler : register(s3);

static float4 gl_FragCoord;
static float gl_FragDepth;
static float4 fragColor;
static float2 texCoord;

struct SPIRV_Cross_Input
{
    float2 texCoord : TEXCOORD0;
    float4 gl_FragCoord : SV_Position;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
    float gl_FragDepth : SV_Depth;
};

float toAbsorbance(float transmittance)
{
    return clamp(-log(max(transmittance, 9.9999997473787516355514526367188e-05f)), 0.0f, 4.0f);
}

float sampleAbsorbance(float coefficients[8], float originalDepth, float currentAbsorbance)
{
    float averageAbsorbance = coefficients[0];
    if (averageAbsorbance == 0.0f)
    {
        return 0.0f;
    }
    float depthMeasuredInBins = originalDepth * 7.0f;
    float depth = depthMeasuredInBins / 8.0f;
    float currentAverageAbsorbanceContribution = currentAbsorbance * (1.0f - depth);
    averageAbsorbance -= currentAverageAbsorbanceContribution;
    int treeIndexB = clamp(int(floor(depthMeasuredInBins)), 0, 7);
    bool shouldSampleA = treeIndexB >= 1;
    int _91;
    if (shouldSampleA)
    {
        _91 = treeIndexB - 1;
    }
    else
    {
        _91 = treeIndexB;
    }
    int treeIndexA = _91;
    treeIndexB += 8;
    treeIndexA += 8;
    float sampleB = averageAbsorbance;
    float sampleA = shouldSampleA ? averageAbsorbance : 0.0f;
    float _196;
    for (int waveletLevel = 0; waveletLevel <= 3; waveletLevel++)
    {
        int power = 3 - waveletLevel;
        float waveletWidth = exp2(float(-power));
        float waveletHeightScale = exp2(float(power) * 0.5f);
        int parentIndexB = treeIndexB >> 1;
        int isRightHalfB = treeIndexB & 1;
        int waveletSignB = 1 - (isRightHalfB << 1);
        float indexAtParentLevel = float(parentIndexB & ((1 << power) - 1));
        float depthOffsetRelativeToWavelet = depth - (waveletWidth * indexAtParentLevel);
        float currentDifferenceCoefficient = (((float(isRightHalfB) * waveletWidth) + (float(waveletSignB) * depthOffsetRelativeToWavelet)) * waveletHeightScale) * currentAbsorbance;
        float differenceCoefficientB = coefficients[parentIndexB];
        differenceCoefficientB -= currentDifferenceCoefficient;
        sampleB -= ((waveletHeightScale * differenceCoefficientB) * float(waveletSignB));
        treeIndexB = parentIndexB;
        if (shouldSampleA)
        {
            int parentIndexA = treeIndexA >> 1;
            if (parentIndexA == parentIndexB)
            {
                _196 = differenceCoefficientB;
            }
            else
            {
                _196 = coefficients[parentIndexA];
            }
            float differenceCoefficientA = _196;
            int isRightHalfA = treeIndexA & 1;
            int waveletSignA = 1 - (isRightHalfA << 1);
            sampleA -= ((waveletHeightScale * differenceCoefficientA) * float(waveletSignA));
            treeIndexA = parentIndexA;
        }
    }
    float _226;
    if (depthMeasuredInBins >= 8.0f)
    {
        _226 = 1.0f;
    }
    else
    {
        _226 = frac(depthMeasuredInBins);
    }
    float lerpAlpha = _226;
    return lerp(sampleA, sampleB, lerpAlpha);
}

float toTransmittance(float absorbance)
{
    return clamp(exp(-absorbance), 9.9999997473787516355514526367188e-05f, 1.0f);
}

float sampleTransmittance(int2 pos, float depth, float currentTransmittance)
{
    float4 coeffSamples[2];
    coeffSamples[0] = Coeff0.Load(int3(pos, 0));
    coeffSamples[1] = Coeff1.Load(int3(pos, 0));
    float coefficients[8];
    for (int i = 0; i < 2; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            coefficients[(i * 4) + j] = coeffSamples[i][j];
        }
    }
    float param = currentTransmittance;
    float param_1[8] = coefficients;
    float param_2 = depth;
    float param_3 = toAbsorbance(param);
    float param_4 = sampleAbsorbance(param_1, param_2, param_3);
    return toTransmittance(param_4);
}

void frag_main()
{
    int2 pixelCoords = int2(gl_FragCoord.xy);
    float4 accumulatedColor = Sampler0.Load(int3(pixelCoords, 0));
    int2 param = pixelCoords;
    float param_1 = 100000.0f;
    float param_2 = 1.0f;
    float sampledTransmittance = sampleTransmittance(param, param_1, param_2);
    float coverage = 1.0f - ((sampledTransmittance < 0.0199999995529651641845703125f) ? 0.0f : sampledTransmittance);
    bool _334 = coverage < 9.9999997473787516355514526367188e-06f;
    bool _343;
    if (_334)
    {
        _343 = dot(accumulatedColor.xyz, 1.0f.xxx) < 9.9999997473787516355514526367188e-06f;
    }
    else
    {
        _343 = _334;
    }
    if (_343)
    {
        discard;
    }
    float _352;
    if (accumulatedColor.w > 9.9999997473787516355514526367188e-06f)
    {
        _352 = coverage / accumulatedColor.w;
    }
    else
    {
        _352 = 1.0f;
    }
    float normalization = _352;
    fragColor = float4(accumulatedColor.xyz * normalization, coverage);
    float closestBoundDeviceDepth = DepthBoundsSampler.Load(int3(pixelCoords, 0)).z;
    gl_FragDepth = closestBoundDeviceDepth;
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    gl_FragCoord = stage_input.gl_FragCoord;
    gl_FragCoord.w = 1.0 / gl_FragCoord.w;
    texCoord = stage_input.texCoord;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.gl_FragDepth = gl_FragDepth;
    stage_output.fragColor = fragColor;
    return stage_output;
}
