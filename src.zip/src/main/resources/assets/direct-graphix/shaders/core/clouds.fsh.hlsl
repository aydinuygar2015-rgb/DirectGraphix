cbuffer Fog : register(b0)
{
    float4 _56_FogColor : packoffset(c0);
    float _56_FogEnvironmentalStart : packoffset(c1);
    float _56_FogEnvironmentalEnd : packoffset(c1.y);
    float _56_FogRenderDistanceStart : packoffset(c1.z);
    float _56_FogRenderDistanceEnd : packoffset(c1.w);
    float _56_FogSkyEnd : packoffset(c2);
    float _56_FogCloudsEnd : packoffset(c2.y);
};


static float4 vertexColor;
static float vertexDistance;
static float4 fragColor;

struct SPIRV_Cross_Input
{
    float vertexDistance : TEXCOORD0;
    float4 vertexColor : TEXCOORD1;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

float linear_fog_value(float vertexDistance_1, float fogStart, float fogEnd)
{
    if (vertexDistance_1 <= fogStart)
    {
        return 0.0f;
    }
    else
    {
        if (vertexDistance_1 >= fogEnd)
        {
            return 1.0f;
        }
    }
    return (vertexDistance_1 - fogStart) / (fogEnd - fogStart);
}

float4 calculateFinalColor(float4 color)
{
    return color;
}

void frag_main()
{
    float4 color = vertexColor;
    float param = vertexDistance;
    float param_1 = 0.0f;
    float param_2 = _56_FogCloudsEnd;
    color.w *= (1.0f - linear_fog_value(param, param_1, param_2));
    float4 param_3 = color;
    fragColor = calculateFinalColor(param_3);
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    vertexColor = stage_input.vertexColor;
    vertexDistance = stage_input.vertexDistance;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
