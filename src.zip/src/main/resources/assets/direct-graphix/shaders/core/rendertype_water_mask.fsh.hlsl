cbuffer DynamicTransforms : register(b0)
{
    row_major float4x4 _14_ModelViewMat : packoffset(c0);
    row_major float4x4 _14_TextureMat : packoffset(c4);
    float4 _14_ColorModulator : packoffset(c8);
    float3 _14_ModelOffset : packoffset(c9);
};


static float4 fragColor;

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

void frag_main()
{
    fragColor = _14_ColorModulator;
}

SPIRV_Cross_Output main()
{
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
