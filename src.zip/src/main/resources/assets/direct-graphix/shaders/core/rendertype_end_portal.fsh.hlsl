static const float3 _319[16] = { float3(0.022087000310420989990234375f, 0.09839899837970733642578125f, 0.1108179986476898193359375f), float3(0.01189200021326541900634765625f, 0.095923997461795806884765625f, 0.089484997093677520751953125f), float3(0.02763600088655948638916015625f, 0.101689003407955169677734375f, 0.100326001644134521484375f), float3(0.0465640015900135040283203125f, 0.109883002936840057373046875f, 0.114837996661663055419921875f), float3(0.064901001751422882080078125f, 0.11769600212574005126953125f, 0.097189001739025115966796875f), float3(0.063761003315448760986328125f, 0.086894996464252471923828125f, 0.123645998537540435791015625f), float3(0.084816999733448028564453125f, 0.1119939982891082763671875f, 0.16638000309467315673828125f), float3(0.09748899936676025390625f, 0.1541199982166290283203125f, 0.091063998639583587646484375f), float3(0.106151998043060302734375f, 0.13114400207996368408203125f, 0.1951909959316253662109375f), float3(0.097721002995967864990234375f, 0.110187999904155731201171875f, 0.18722899258136749267578125f), float3(0.13351599872112274169921875f, 0.13827799260616302490234375f, 0.14858199656009674072265625f), float3(0.07000599801540374755859375f, 0.2433319985866546630859375f, 0.23579199612140655517578125f), float3(0.19676600396633148193359375f, 0.1428990066051483154296875f, 0.21469600498676300048828125f), float3(0.0472810007631778717041015625f, 0.3153379857540130615234375f, 0.3219699859619140625f), float3(0.20467500388622283935546875f, 0.39000999927520751953125f, 0.3020659983158111572265625f), float3(0.0809549987316131591796875f, 0.3148210048675537109375f, 0.661490976810455322265625f) };

cbuffer Globals : register(b1)
{
    int3 _152_CameraBlockPos : packoffset(c0);
    float _152_GlintAlpha : packoffset(c0.w);
    float3 _152_CameraOffset : packoffset(c1);
    float _152_GameTime : packoffset(c1.w);
    float2 _152_ScreenSize : packoffset(c2);
    int _152_MenuBlurRadius : packoffset(c2.z);
    int _152_UseRgss : packoffset(c2.w);
};

cbuffer Fog : register(b0)
{
    float4 _342_FogColor : packoffset(c0);
    float _342_FogEnvironmentalStart : packoffset(c1);
    float _342_FogEnvironmentalEnd : packoffset(c1.y);
    float _342_FogRenderDistanceStart : packoffset(c1.z);
    float _342_FogRenderDistanceEnd : packoffset(c1.w);
    float _342_FogSkyEnd : packoffset(c2);
    float _342_FogCloudsEnd : packoffset(c2.y);
};

Texture2D<float4> Sampler0 : register(t2);
SamplerState _Sampler0_sampler : register(s2);
Texture2D<float4> Sampler1 : register(t3);
SamplerState _Sampler1_sampler : register(s3);

static float4 texProj0;
static float4 fragColor;
static float sphericalVertexDistance;
static float cylindricalVertexDistance;

struct SPIRV_Cross_Input
{
    float4 texProj0 : TEXCOORD0;
    float sphericalVertexDistance : TEXCOORD1;
    float cylindricalVertexDistance : TEXCOORD2;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

float2x2 mat2_rotate_z(float _radians)
{
    return float2x2(float2(cos(_radians), -sin(_radians)), float2(sin(_radians), cos(_radians)));
}

float4x4 end_portal_layer(float layer)
{
    float4x4 translate = float4x4(float4(1.0f, 0.0f, 0.0f, 17.0f / layer), float4(0.0f, 1.0f, 0.0f, (2.0f + (layer / 1.5f)) * (_152_GameTime * 1.5f)), float4(0.0f, 0.0f, 1.0f, 0.0f), float4(0.0f, 0.0f, 0.0f, 1.0f));
    float param = radians((((layer * layer) * 4321.0f) + (layer * 9.0f)) * 2.0f);
    float2x2 rotate = mat2_rotate_z(param);
    float _185 = (4.5f - (layer / 4.0f)) * 2.0f;
    float2x2 scale = float2x2(float2(_185, 0.0f), float2(0.0f, _185));
    float2x2 _191 = mul(rotate, scale);
    return mul(float4x4(float4(0.5f, 0.0f, 0.0f, 0.25f), float4(0.0f, 0.5f, 0.0f, 0.25f), float4(0.0f, 0.0f, 1.0f, 0.0f), float4(0.0f, 0.0f, 0.0f, 1.0f)), mul(translate, float4x4(float4(_191[0].x, _191[0].y, 0.0f, 0.0f), float4(_191[1].x, _191[1].y, 0.0f, 0.0f), float4(0.0f, 0.0f, 1.0f, 0.0f), float4(0.0f, 0.0f, 0.0f, 1.0f))));
}

float linear_fog_value(float vertexDistance, float fogStart, float fogEnd)
{
    if (vertexDistance <= fogStart)
    {
        return 0.0f;
    }
    else
    {
        if (vertexDistance >= fogEnd)
        {
            return 1.0f;
        }
    }
    return (vertexDistance - fogStart) / (fogEnd - fogStart);
}

float total_fog_value(float sphericalVertexDistance_1, float cylindricalVertexDistance_1, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd)
{
    float param = sphericalVertexDistance_1;
    float param_1 = environmentalStart;
    float param_2 = environmantalEnd;
    float param_3 = cylindricalVertexDistance_1;
    float param_4 = renderDistanceStart;
    float param_5 = renderDistanceEnd;
    return max(linear_fog_value(param, param_1, param_2), linear_fog_value(param_3, param_4, param_5));
}

float4 apply_fog(float4 inColor, float sphericalVertexDistance_1, float cylindricalVertexDistance_1, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd, float4 fogColor)
{
    float param = sphericalVertexDistance_1;
    float param_1 = cylindricalVertexDistance_1;
    float param_2 = environmentalStart;
    float param_3 = environmantalEnd;
    float param_4 = renderDistanceStart;
    float param_5 = renderDistanceEnd;
    float fogValue = total_fog_value(param, param_1, param_2, param_3, param_4, param_5);
    return float4(lerp(inColor.xyz, fogColor.xyz, (fogValue * fogColor.w).xxx), inColor.w);
}

void frag_main()
{
    float4 _222 = texProj0;
    _222.z = _222.w;
    float3 color = Sampler0.Sample(_Sampler0_sampler, _222.xy / _222.z).xyz * float3(0.022087000310420989990234375f, 0.09839899837970733642578125f, 0.1108179986476898193359375f);
    for (int i = 0; i < 15; i++)
    {
        float param = float(i + 1);
        float4 _252 = mul(end_portal_layer(param), texProj0);
        _252.z = _252.w;
        color += (Sampler1.Sample(_Sampler1_sampler, _252.xy / _252.z).xyz * _319[i]);
    }
    float4 param_1 = float4(color, 1.0f);
    float param_2 = sphericalVertexDistance;
    float param_3 = cylindricalVertexDistance;
    float param_4 = _342_FogEnvironmentalStart;
    float param_5 = _342_FogEnvironmentalEnd;
    float param_6 = _342_FogRenderDistanceStart;
    float param_7 = _342_FogRenderDistanceEnd;
    float4 param_8 = _342_FogColor;
    fragColor = apply_fog(param_1, param_2, param_3, param_4, param_5, param_6, param_7, param_8);
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    texProj0 = stage_input.texProj0;
    sphericalVertexDistance = stage_input.sphericalVertexDistance;
    cylindricalVertexDistance = stage_input.cylindricalVertexDistance;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
