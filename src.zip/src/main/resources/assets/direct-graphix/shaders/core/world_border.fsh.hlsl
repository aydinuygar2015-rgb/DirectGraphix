cbuffer DynamicTransforms : register(b0)
{
    row_major float4x4 _17_ModelViewMat : packoffset(c0);
    row_major float4x4 _17_TextureMat : packoffset(c4);
    float4 _17_ColorModulator : packoffset(c8);
    float3 _17_ModelOffset : packoffset(c9);
};

Texture2D<float4> Sampler0 : register(t1);
SamplerState _Sampler0_sampler : register(s1);

static float2 texCoord0;
static float4 fragColor;

struct SPIRV_Cross_Input
{
    float2 texCoord0 : TEXCOORD0;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

float4 calculateFinalColor(inout float4 color)
{
    color *= _17_ColorModulator;
    return color;
}

void frag_main()
{
    float4 color = Sampler0.Sample(_Sampler0_sampler, texCoord0);
    if (color.w == 0.0f)
    {
        discard;
    }
    float4 param = color;
    float4 _54 = calculateFinalColor(param);
    fragColor = _54;
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    texCoord0 = stage_input.texCoord0;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
