cbuffer DynamicTransforms : register(b0)
{
    row_major float4x4 _31_ModelViewMat : packoffset(c0);
    row_major float4x4 _31_TextureMat : packoffset(c4);
    float4 _31_ColorModulator : packoffset(c8);
    float3 _31_ModelOffset : packoffset(c9);
};


static float4 vertexColor;
static float4 fragColor;

struct SPIRV_Cross_Input
{
    float4 vertexColor : TEXCOORD0;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

void frag_main()
{
    float4 color = vertexColor;
    if (color.w == 0.0f)
    {
        discard;
    }
    fragColor = color * _31_ColorModulator;
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    vertexColor = stage_input.vertexColor;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
