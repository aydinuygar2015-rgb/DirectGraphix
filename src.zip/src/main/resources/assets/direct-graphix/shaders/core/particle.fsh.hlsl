cbuffer Fog : register(b0)
{
    float4 _120_FogColor : packoffset(c0);
    float _120_FogEnvironmentalStart : packoffset(c1);
    float _120_FogEnvironmentalEnd : packoffset(c1.y);
    float _120_FogRenderDistanceStart : packoffset(c1.z);
    float _120_FogRenderDistanceEnd : packoffset(c1.w);
    float _120_FogSkyEnd : packoffset(c2);
    float _120_FogCloudsEnd : packoffset(c2.y);
};

cbuffer DynamicTransforms : register(b1)
{
    row_major float4x4 _175_ModelViewMat : packoffset(c0);
    row_major float4x4 _175_TextureMat : packoffset(c4);
    float4 _175_ColorModulator : packoffset(c8);
    float3 _175_ModelOffset : packoffset(c9);
};

Texture2D<float4> Sampler0 : register(t2);
SamplerState _Sampler0_sampler : register(s2);

static float sphericalVertexDistance;
static float cylindricalVertexDistance;
static float2 texCoord0;
static float4 vertexColor;
static float4 fragColor;

struct SPIRV_Cross_Input
{
    float sphericalVertexDistance : TEXCOORD0;
    float cylindricalVertexDistance : TEXCOORD1;
    float2 texCoord0 : TEXCOORD2;
    float4 vertexColor : TEXCOORD3;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

float linear_fog_value(float vertexDistance, float fogStart, float fogEnd)
{
    if (vertexDistance <= fogStart)
    {
        return 0.0f;
    }
    else
    {
        if (vertexDistance >= fogEnd)
        {
            return 1.0f;
        }
    }
    return (vertexDistance - fogStart) / (fogEnd - fogStart);
}

float total_fog_value(float sphericalVertexDistance_1, float cylindricalVertexDistance_1, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd)
{
    float param = sphericalVertexDistance_1;
    float param_1 = environmentalStart;
    float param_2 = environmantalEnd;
    float param_3 = cylindricalVertexDistance_1;
    float param_4 = renderDistanceStart;
    float param_5 = renderDistanceEnd;
    return max(linear_fog_value(param, param_1, param_2), linear_fog_value(param_3, param_4, param_5));
}

float4 apply_fog(float4 inColor, float sphericalVertexDistance_1, float cylindricalVertexDistance_1, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd, float4 fogColor)
{
    float param = sphericalVertexDistance_1;
    float param_1 = cylindricalVertexDistance_1;
    float param_2 = environmentalStart;
    float param_3 = environmantalEnd;
    float param_4 = renderDistanceStart;
    float param_5 = renderDistanceEnd;
    float fogValue = total_fog_value(param, param_1, param_2, param_3, param_4, param_5);
    return float4(lerp(inColor.xyz, fogColor.xyz, (fogValue * fogColor.w).xxx), inColor.w);
}

float4 calculateFinalColor(float4 color)
{
    float4 fogColor = _120_FogColor;
    float4 param = color;
    float param_1 = sphericalVertexDistance;
    float param_2 = cylindricalVertexDistance;
    float param_3 = _120_FogEnvironmentalStart;
    float param_4 = _120_FogEnvironmentalEnd;
    float param_5 = _120_FogRenderDistanceStart;
    float param_6 = _120_FogRenderDistanceEnd;
    float4 param_7 = fogColor;
    return apply_fog(param, param_1, param_2, param_3, param_4, param_5, param_6, param_7);
}

void frag_main()
{
    float4 color = (Sampler0.Sample(_Sampler0_sampler, texCoord0) * vertexColor) * _175_ColorModulator;
    if (color.w < 0.100000001490116119384765625f)
    {
        discard;
    }
    float4 param = color;
    fragColor = calculateFinalColor(param);
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    sphericalVertexDistance = stage_input.sphericalVertexDistance;
    cylindricalVertexDistance = stage_input.cylindricalVertexDistance;
    texCoord0 = stage_input.texCoord0;
    vertexColor = stage_input.vertexColor;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
