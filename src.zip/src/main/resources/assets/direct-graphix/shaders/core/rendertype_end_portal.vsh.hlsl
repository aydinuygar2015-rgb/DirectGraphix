cbuffer Projection : register(b0)
{
    row_major float4x4 _83_ProjMat : packoffset(c0);
};

cbuffer DynamicTransforms : register(b1)
{
    row_major float4x4 _89_ModelViewMat : packoffset(c0);
    row_major float4x4 _89_TextureMat : packoffset(c4);
    float4 _89_ColorModulator : packoffset(c8);
    float3 _89_ModelOffset : packoffset(c9);
};

cbuffer Fog : register(b0)
{
    float4 _120_FogColor : packoffset(c0);
    float _120_FogEnvironmentalStart : packoffset(c1);
    float _120_FogEnvironmentalEnd : packoffset(c1.y);
    float _120_FogRenderDistanceStart : packoffset(c1.z);
    float _120_FogRenderDistanceEnd : packoffset(c1.w);
    float _120_FogSkyEnd : packoffset(c2);
    float _120_FogCloudsEnd : packoffset(c2.y);
};


static float4 gl_Position;
static float3 Position;
static float4 texProj0;
static float sphericalVertexDistance;
static float cylindricalVertexDistance;

struct SPIRV_Cross_Input
{
    float3 Position : TEXCOORD0;
};

struct SPIRV_Cross_Output
{
    float4 texProj0 : TEXCOORD0;
    float sphericalVertexDistance : TEXCOORD1;
    float cylindricalVertexDistance : TEXCOORD2;
    float4 gl_Position : SV_Position;
};

float4 projection_from_position(float4 position)
{
    float4 projection = position * 0.5f;
    float _49 = projection.x;
    float _52 = projection.w;
    float _55 = projection.y;
    float _57 = projection.w;
    float2 _59 = float2(_49 + _52, _55 + _57);
    projection.x = _59.x;
    projection.y = _59.y;
    projection.z = position.zw.x;
    projection.w = position.zw.y;
    return projection;
}

float fog_spherical_distance(float3 pos)
{
    return length(pos);
}

float fog_cylindrical_distance(float3 pos)
{
    float distXZ = length(pos.xz);
    float distY = abs(pos.y);
    return max(distXZ, distY);
}

void vert_main()
{
    gl_Position = mul(float4(Position, 1.0f), mul(_89_ModelViewMat, _83_ProjMat));
    float4 param = gl_Position;
    texProj0 = projection_from_position(param);
    float3 param_1 = Position;
    sphericalVertexDistance = fog_spherical_distance(param_1);
    float3 param_2 = Position;
    cylindricalVertexDistance = fog_cylindrical_distance(param_2);
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    Position = stage_input.Position;
    vert_main();
    SPIRV_Cross_Output stage_output;
    stage_output.gl_Position = gl_Position;
    stage_output.texProj0 = texProj0;
    stage_output.sphericalVertexDistance = sphericalVertexDistance;
    stage_output.cylindricalVertexDistance = cylindricalVertexDistance;
    return stage_output;
}
