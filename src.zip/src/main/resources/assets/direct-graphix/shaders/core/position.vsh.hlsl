cbuffer Projection : register(b1)
{
    row_major float4x4 _47_ProjMat : packoffset(c0);
};

cbuffer DynamicTransforms : register(b0)
{
    row_major float4x4 _53_ModelViewMat : packoffset(c0);
    row_major float4x4 _53_TextureMat : packoffset(c4);
    float4 _53_ColorModulator : packoffset(c8);
    float3 _53_ModelOffset : packoffset(c9);
};

cbuffer Fog : register(b0)
{
    float4 _79_FogColor : packoffset(c0);
    float _79_FogEnvironmentalStart : packoffset(c1);
    float _79_FogEnvironmentalEnd : packoffset(c1.y);
    float _79_FogRenderDistanceStart : packoffset(c1.z);
    float _79_FogRenderDistanceEnd : packoffset(c1.w);
    float _79_FogSkyEnd : packoffset(c2);
    float _79_FogCloudsEnd : packoffset(c2.y);
};


static float4 gl_Position;
static float3 Position;
static float sphericalVertexDistance;
static float cylindricalVertexDistance;

struct SPIRV_Cross_Input
{
    float3 Position : TEXCOORD0;
};

struct SPIRV_Cross_Output
{
    float sphericalVertexDistance : TEXCOORD0;
    float cylindricalVertexDistance : TEXCOORD1;
    float4 gl_Position : SV_Position;
};

float fog_spherical_distance(float3 pos)
{
    return length(pos);
}

float fog_cylindrical_distance(float3 pos)
{
    float distXZ = length(pos.xz);
    float distY = abs(pos.y);
    return max(distXZ, distY);
}

void vert_main()
{
    gl_Position = mul(float4(Position, 1.0f), mul(_53_ModelViewMat, _47_ProjMat));
    float3 param = Position;
    sphericalVertexDistance = fog_spherical_distance(param);
    float3 param_1 = Position;
    cylindricalVertexDistance = fog_cylindrical_distance(param_1);
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    Position = stage_input.Position;
    vert_main();
    SPIRV_Cross_Output stage_output;
    stage_output.gl_Position = gl_Position;
    stage_output.sphericalVertexDistance = sphericalVertexDistance;
    stage_output.cylindricalVertexDistance = cylindricalVertexDistance;
    return stage_output;
}
