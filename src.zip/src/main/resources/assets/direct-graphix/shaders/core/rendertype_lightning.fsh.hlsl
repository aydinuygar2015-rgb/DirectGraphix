cbuffer DynamicTransforms : register(b1)
{
    row_major float4x4 _82_ModelViewMat : packoffset(c0);
    row_major float4x4 _82_TextureMat : packoffset(c4);
    float4 _82_ColorModulator : packoffset(c8);
    float3 _82_ModelOffset : packoffset(c9);
};

cbuffer Fog : register(b0)
{
    float4 _94_FogColor : packoffset(c0);
    float _94_FogEnvironmentalStart : packoffset(c1);
    float _94_FogEnvironmentalEnd : packoffset(c1.y);
    float _94_FogRenderDistanceStart : packoffset(c1.z);
    float _94_FogRenderDistanceEnd : packoffset(c1.w);
    float _94_FogSkyEnd : packoffset(c2);
    float _94_FogCloudsEnd : packoffset(c2.y);
};


static float4 vertexColor;
static float sphericalVertexDistance;
static float cylindricalVertexDistance;
static float4 fragColor;

struct SPIRV_Cross_Input
{
    float sphericalVertexDistance : TEXCOORD0;
    float cylindricalVertexDistance : TEXCOORD1;
    float4 vertexColor : TEXCOORD2;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

float linear_fog_value(float vertexDistance, float fogStart, float fogEnd)
{
    if (vertexDistance <= fogStart)
    {
        return 0.0f;
    }
    else
    {
        if (vertexDistance >= fogEnd)
        {
            return 1.0f;
        }
    }
    return (vertexDistance - fogStart) / (fogEnd - fogStart);
}

float total_fog_value(float sphericalVertexDistance_1, float cylindricalVertexDistance_1, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd)
{
    float param = sphericalVertexDistance_1;
    float param_1 = environmentalStart;
    float param_2 = environmantalEnd;
    float param_3 = cylindricalVertexDistance_1;
    float param_4 = renderDistanceStart;
    float param_5 = renderDistanceEnd;
    return max(linear_fog_value(param, param_1, param_2), linear_fog_value(param_3, param_4, param_5));
}

float4 calculateFinalColor(float4 color)
{
    return color;
}

void frag_main()
{
    float param = sphericalVertexDistance;
    float param_1 = cylindricalVertexDistance;
    float param_2 = _94_FogEnvironmentalStart;
    float param_3 = _94_FogEnvironmentalEnd;
    float param_4 = _94_FogRenderDistanceStart;
    float param_5 = _94_FogRenderDistanceEnd;
    float4 color = (vertexColor * _82_ColorModulator) * (1.0f - total_fog_value(param, param_1, param_2, param_3, param_4, param_5));
    float4 param_6 = color;
    fragColor = calculateFinalColor(param_6);
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    vertexColor = stage_input.vertexColor;
    sphericalVertexDistance = stage_input.sphericalVertexDistance;
    cylindricalVertexDistance = stage_input.cylindricalVertexDistance;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
