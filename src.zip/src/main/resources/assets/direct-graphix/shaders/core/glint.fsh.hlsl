cbuffer DynamicTransforms : register(b2)
{
    row_major float4x4 _82_ModelViewMat : packoffset(c0);
    row_major float4x4 _82_TextureMat : packoffset(c4);
    float4 _82_ColorModulator : packoffset(c8);
    float3 _82_ModelOffset : packoffset(c9);
};

cbuffer Fog : register(b0)
{
    float4 _104_FogColor : packoffset(c0);
    float _104_FogEnvironmentalStart : packoffset(c1);
    float _104_FogEnvironmentalEnd : packoffset(c1.y);
    float _104_FogRenderDistanceStart : packoffset(c1.z);
    float _104_FogRenderDistanceEnd : packoffset(c1.w);
    float _104_FogSkyEnd : packoffset(c2);
    float _104_FogCloudsEnd : packoffset(c2.y);
};

cbuffer Globals : register(b1)
{
    int3 _130_CameraBlockPos : packoffset(c0);
    float _130_GlintAlpha : packoffset(c0.w);
    float3 _130_CameraOffset : packoffset(c1);
    float _130_GameTime : packoffset(c1.w);
    float2 _130_ScreenSize : packoffset(c2);
    int _130_MenuBlurRadius : packoffset(c2.z);
    int _130_UseRgss : packoffset(c2.w);
};

Texture2D<float4> Sampler0 : register(t3);
SamplerState _Sampler0_sampler : register(s3);

static float2 texCoord0;
static float sphericalVertexDistance;
static float cylindricalVertexDistance;
static float4 fragColor;

struct SPIRV_Cross_Input
{
    float sphericalVertexDistance : TEXCOORD0;
    float cylindricalVertexDistance : TEXCOORD1;
    float2 texCoord0 : TEXCOORD2;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

float linear_fog_value(float vertexDistance, float fogStart, float fogEnd)
{
    if (vertexDistance <= fogStart)
    {
        return 0.0f;
    }
    else
    {
        if (vertexDistance >= fogEnd)
        {
            return 1.0f;
        }
    }
    return (vertexDistance - fogStart) / (fogEnd - fogStart);
}

float total_fog_value(float sphericalVertexDistance_1, float cylindricalVertexDistance_1, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd)
{
    float param = sphericalVertexDistance_1;
    float param_1 = environmentalStart;
    float param_2 = environmantalEnd;
    float param_3 = cylindricalVertexDistance_1;
    float param_4 = renderDistanceStart;
    float param_5 = renderDistanceEnd;
    return max(linear_fog_value(param, param_1, param_2), linear_fog_value(param_3, param_4, param_5));
}

void frag_main()
{
    float4 color = Sampler0.Sample(_Sampler0_sampler, texCoord0) * _82_ColorModulator;
    if (color.w < 0.100000001490116119384765625f)
    {
        discard;
    }
    float param = sphericalVertexDistance;
    float param_1 = cylindricalVertexDistance;
    float param_2 = _104_FogEnvironmentalStart;
    float param_3 = _104_FogEnvironmentalEnd;
    float param_4 = _104_FogRenderDistanceStart;
    float param_5 = _104_FogRenderDistanceEnd;
    float fade = (1.0f - total_fog_value(param, param_1, param_2, param_3, param_4, param_5)) * _130_GlintAlpha;
    fragColor = float4(color.xyz * fade, color.w);
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    texCoord0 = stage_input.texCoord0;
    sphericalVertexDistance = stage_input.sphericalVertexDistance;
    cylindricalVertexDistance = stage_input.cylindricalVertexDistance;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
