cbuffer DynamicTransforms : register(b0)
{
    row_major float4x4 _37_ModelViewMat : packoffset(c0);
    row_major float4x4 _37_TextureMat : packoffset(c4);
    float4 _37_ColorModulator : packoffset(c8);
    float3 _37_ModelOffset : packoffset(c9);
};

Texture2D<float4> Sampler0 : register(t1);
SamplerState _Sampler0_sampler : register(s1);

static float2 texCoord0;
static float4 fragColor;
static float4 vertexColor;

struct SPIRV_Cross_Input
{
    float4 vertexColor : TEXCOORD0;
    float2 texCoord0 : TEXCOORD1;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

void frag_main()
{
    float4 color = Sampler0.Sample(_Sampler0_sampler, texCoord0);
    if (color.w == 0.0f)
    {
        discard;
    }
    fragColor = float4(_37_ColorModulator.xyz * vertexColor.xyz, _37_ColorModulator.w);
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    texCoord0 = stage_input.texCoord0;
    vertexColor = stage_input.vertexColor;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
