cbuffer DynamicTransforms : register(b1)
{
    row_major float4x4 _118_ModelViewMat : packoffset(c0);
    row_major float4x4 _118_TextureMat : packoffset(c4);
    float4 _118_ColorModulator : packoffset(c8);
    float3 _118_ModelOffset : packoffset(c9);
};

cbuffer Fog : register(b0)
{
    float4 _126_FogColor : packoffset(c0);
    float _126_FogEnvironmentalStart : packoffset(c1);
    float _126_FogEnvironmentalEnd : packoffset(c1.y);
    float _126_FogRenderDistanceStart : packoffset(c1.z);
    float _126_FogRenderDistanceEnd : packoffset(c1.w);
    float _126_FogSkyEnd : packoffset(c2);
    float _126_FogCloudsEnd : packoffset(c2.y);
};


static float4 fragColor;
static float sphericalVertexDistance;
static float cylindricalVertexDistance;

struct SPIRV_Cross_Input
{
    float sphericalVertexDistance : TEXCOORD0;
    float cylindricalVertexDistance : TEXCOORD1;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

float linear_fog_value(float vertexDistance, float fogStart, float fogEnd)
{
    if (vertexDistance <= fogStart)
    {
        return 0.0f;
    }
    else
    {
        if (vertexDistance >= fogEnd)
        {
            return 1.0f;
        }
    }
    return (vertexDistance - fogStart) / (fogEnd - fogStart);
}

float total_fog_value(float sphericalVertexDistance_1, float cylindricalVertexDistance_1, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd)
{
    float param = sphericalVertexDistance_1;
    float param_1 = environmentalStart;
    float param_2 = environmantalEnd;
    float param_3 = cylindricalVertexDistance_1;
    float param_4 = renderDistanceStart;
    float param_5 = renderDistanceEnd;
    return max(linear_fog_value(param, param_1, param_2), linear_fog_value(param_3, param_4, param_5));
}

float4 apply_fog(float4 inColor, float sphericalVertexDistance_1, float cylindricalVertexDistance_1, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd, float4 fogColor)
{
    float param = sphericalVertexDistance_1;
    float param_1 = cylindricalVertexDistance_1;
    float param_2 = environmentalStart;
    float param_3 = environmantalEnd;
    float param_4 = renderDistanceStart;
    float param_5 = renderDistanceEnd;
    float fogValue = total_fog_value(param, param_1, param_2, param_3, param_4, param_5);
    return float4(lerp(inColor.xyz, fogColor.xyz, (fogValue * fogColor.w).xxx), inColor.w);
}

void frag_main()
{
    float4 param = _118_ColorModulator;
    float param_1 = sphericalVertexDistance;
    float param_2 = cylindricalVertexDistance;
    float param_3 = 0.0f;
    float param_4 = _126_FogSkyEnd;
    float param_5 = _126_FogSkyEnd;
    float param_6 = _126_FogSkyEnd;
    float4 param_7 = _126_FogColor;
    fragColor = apply_fog(param, param_1, param_2, param_3, param_4, param_5, param_6, param_7);
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    sphericalVertexDistance = stage_input.sphericalVertexDistance;
    cylindricalVertexDistance = stage_input.cylindricalVertexDistance;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
