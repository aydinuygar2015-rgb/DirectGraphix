cbuffer Fog : register(b0)
{
    float4 _120_FogColor : packoffset(c0);
    float _120_FogEnvironmentalStart : packoffset(c1);
    float _120_FogEnvironmentalEnd : packoffset(c1.y);
    float _120_FogRenderDistanceStart : packoffset(c1.z);
    float _120_FogRenderDistanceEnd : packoffset(c1.w);
    float _120_FogSkyEnd : packoffset(c2);
    float _120_FogCloudsEnd : packoffset(c2.y);
};

cbuffer DynamicTransforms : register(b1)
{
    row_major float4x4 _177_ModelViewMat : packoffset(c0);
    row_major float4x4 _177_TextureMat : packoffset(c4);
    float4 _177_ColorModulator : packoffset(c8);
    float3 _177_ModelOffset : packoffset(c9);
};

Texture2D<float4> Sampler0 : register(t2);
SamplerState _Sampler0_sampler : register(s2);

static float4 gl_FragCoord;
static float2 texCoord0;
static float4 vertexColor;
static float4 fragColor;

struct SPIRV_Cross_Input
{
    float4 vertexColor : TEXCOORD0;
    float2 texCoord0 : TEXCOORD1;
    float4 gl_FragCoord : SV_Position;
};

struct SPIRV_Cross_Output
{
    float4 fragColor : SV_Target0;
};

float linear_fog_value(float vertexDistance, float fogStart, float fogEnd)
{
    if (vertexDistance <= fogStart)
    {
        return 0.0f;
    }
    else
    {
        if (vertexDistance >= fogEnd)
        {
            return 1.0f;
        }
    }
    return (vertexDistance - fogStart) / (fogEnd - fogStart);
}

float total_fog_value(float sphericalVertexDistance, float cylindricalVertexDistance, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd)
{
    float param = sphericalVertexDistance;
    float param_1 = environmentalStart;
    float param_2 = environmantalEnd;
    float param_3 = cylindricalVertexDistance;
    float param_4 = renderDistanceStart;
    float param_5 = renderDistanceEnd;
    return max(linear_fog_value(param, param_1, param_2), linear_fog_value(param_3, param_4, param_5));
}

float4 apply_fog(float4 inColor, float sphericalVertexDistance, float cylindricalVertexDistance, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd, float4 fogColor)
{
    float param = sphericalVertexDistance;
    float param_1 = cylindricalVertexDistance;
    float param_2 = environmentalStart;
    float param_3 = environmantalEnd;
    float param_4 = renderDistanceStart;
    float param_5 = renderDistanceEnd;
    float fogValue = total_fog_value(param, param_1, param_2, param_3, param_4, param_5);
    return float4(lerp(inColor.xyz, fogColor.xyz, (fogValue * fogColor.w).xxx), inColor.w);
}

float4 calculateFinalColor(float4 color)
{
    float4 fogColor = _120_FogColor;
    float fragmentDistance = 1.0f / gl_FragCoord.w;
    float4 param = color;
    float param_1 = fragmentDistance;
    float param_2 = fragmentDistance;
    float param_3 = _120_FogEnvironmentalStart;
    float param_4 = _120_FogEnvironmentalEnd;
    float param_5 = _120_FogRenderDistanceStart;
    float param_6 = _120_FogRenderDistanceEnd;
    float4 param_7 = fogColor;
    return apply_fog(param, param_1, param_2, param_3, param_4, param_5, param_6, param_7);
}

void frag_main()
{
    float4 color = Sampler0.Sample(_Sampler0_sampler, texCoord0);
    color *= (vertexColor * _177_ColorModulator);
    float4 param = color;
    fragColor = calculateFinalColor(param);
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    gl_FragCoord = stage_input.gl_FragCoord;
    gl_FragCoord.w = 1.0 / gl_FragCoord.w;
    texCoord0 = stage_input.texCoord0;
    vertexColor = stage_input.vertexColor;
    frag_main();
    SPIRV_Cross_Output stage_output;
    stage_output.fragColor = fragColor;
    return stage_output;
}
