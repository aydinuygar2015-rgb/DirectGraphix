cbuffer DynamicTransforms : register(b0)
{
    row_major float4x4 _73_ModelViewMat : packoffset(c0);
    row_major float4x4 _73_TextureMat : packoffset(c4);
    float4 _73_ColorModulator : packoffset(c8);
    float3 _73_ModelOffset : packoffset(c9);
};

cbuffer Projection : register(b1)
{
    row_major float4x4 _86_ProjMat : packoffset(c0);
};

cbuffer Fog : register(b0)
{
    float4 _129_FogColor : packoffset(c0);
    float _129_FogEnvironmentalStart : packoffset(c1);
    float _129_FogEnvironmentalEnd : packoffset(c1.y);
    float _129_FogRenderDistanceStart : packoffset(c1.z);
    float _129_FogRenderDistanceEnd : packoffset(c1.w);
    float _129_FogSkyEnd : packoffset(c2);
    float _129_FogCloudsEnd : packoffset(c2.y);
};

Texture2D<float4> Sampler2 : register(t2);
SamplerState _Sampler2_sampler : register(s2);

static float4 gl_Position;
static float3 Position;
static float sphericalVertexDistance;
static float cylindricalVertexDistance;
static float4 vertexColor;
static float4 Color;
static int2 UV2;
static float2 texCoord0;
static float2 UV0;

struct SPIRV_Cross_Input
{
    float3 Position : TEXCOORD0;
    float4 Color : TEXCOORD1;
    float2 UV0 : TEXCOORD2;
    int2 UV2 : TEXCOORD3;
};

struct SPIRV_Cross_Output
{
    float sphericalVertexDistance : TEXCOORD0;
    float cylindricalVertexDistance : TEXCOORD1;
    float4 vertexColor : TEXCOORD2;
    float2 texCoord0 : TEXCOORD3;
    float4 gl_Position : SV_Position;
};

float fog_spherical_distance(float3 pos)
{
    return length(pos);
}

float fog_cylindrical_distance(float3 pos)
{
    float distXZ = length(pos.xz);
    float distY = abs(pos.y);
    return max(distXZ, distY);
}

float4 sample_lightmap(Texture2D<float4> lightMap, SamplerState _lightMap_sampler, int2 uv)
{
    return lightMap.SampleLevel(_lightMap_sampler, clamp((float2(uv) / 256.0f.xx) + 0.03125f.xx, 0.03125f.xx, 0.96875f.xx), 0.0f);
}

void vert_main()
{
    float3 pos = Position + _73_ModelOffset;
    gl_Position = mul(float4(pos, 1.0f), mul(_73_ModelViewMat, _86_ProjMat));
    float3 param = pos;
    sphericalVertexDistance = fog_spherical_distance(param);
    float3 param_1 = pos;
    cylindricalVertexDistance = fog_cylindrical_distance(param_1);
    int2 param_2 = UV2;
    vertexColor = Color * sample_lightmap(Sampler2, _Sampler2_sampler, param_2);
    texCoord0 = UV0;
}

SPIRV_Cross_Output main(SPIRV_Cross_Input stage_input)
{
    Position = stage_input.Position;
    Color = stage_input.Color;
    UV2 = stage_input.UV2;
    UV0 = stage_input.UV0;
    vert_main();
    SPIRV_Cross_Output stage_output;
    stage_output.gl_Position = gl_Position;
    stage_output.sphericalVertexDistance = sphericalVertexDistance;
    stage_output.cylindricalVertexDistance = cylindricalVertexDistance;
    stage_output.vertexColor = vertexColor;
    stage_output.texCoord0 = texCoord0;
    return stage_output;
}
