package com.directx.client;

import com.directx.DirectGraphix;
import net.fabricmc.api.ClientModInitializer;

public class DirectGraphixClient implements ClientModInitializer {
	// Acil durum anahtari, JVM argumani: -Ddirectgraphix.disable=true
	private static final boolean DISABLED = Boolean.getBoolean("directgraphix.disable");

	public static boolean isDisabled() {
		return DISABLED;
	}

	@Override
	public void onInitializeClient() {
		DirectGraphix.LOGGER.info("[DirectGraphix] client init, disabled = {}", DISABLED);
	}
}