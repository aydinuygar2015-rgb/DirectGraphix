package com.directx.client.d3d11;

import com.mojang.renderpearl.backend.api.BackendRenderPipeline;

public class D3D11Pending implements BackendRenderPipeline.Pending {
	private final BackendRenderPipeline pipeline;

	public D3D11Pending(BackendRenderPipeline pipeline) {
		this.pipeline = pipeline;
	}

	@Override
	public BackendRenderPipeline finishCompile() {
		return this.pipeline;
	}
}