package com.directx.client.d3d11;

import static java.lang.foreign.ValueLayout.ADDRESS;
import static java.lang.foreign.ValueLayout.JAVA_INT;
import static java.lang.foreign.ValueLayout.JAVA_LONG;

import com.directx.DirectGraphix;
import com.mojang.renderpearl.api.device.GpuSurface;
import com.mojang.renderpearl.api.textures.GpuTextureView;
import com.mojang.renderpearl.backend.api.CommandEncoderBackend;
import com.mojang.renderpearl.backend.api.GpuSurfaceBackend;
import java.lang.foreign.Arena;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.MemorySegment;
import java.lang.invoke.MethodHandle;
import java.util.Collection;
import java.util.EnumSet;
import java.util.Set;
import java.util.function.BooleanSupplier;

public class D3D11GpuSurface implements GpuSurfaceBackend {
	private static final int DXGI_USAGE_RENDER_TARGET_OUTPUT = 0x20;
	private static final int DXGI_FORMAT_R8G8B8A8_UNORM = 28;
	private static final int DXGI_SWAP_EFFECT_DISCARD = 0;
	private static final int DXGI_MWA_NO_ALT_ENTER = 0x2;

	private final D3D11Context context;
	private final long windowHandle;
	private final BooleanSupplier isIconified;

	private MemorySegment swapchain = MemorySegment.NULL;
	private MemorySegment backBuffer = MemorySegment.NULL;
	private MemorySegment backBufferRtv = MemorySegment.NULL;
	private D3D11FlipBlit flipBlit;
	private boolean flipBlitFailed;
	private MethodHandle presentHandle;
	private MethodHandle copyRegionHandle;
	private int swapchainWidth;
	private int swapchainHeight;
	private GpuSurface.PresentMode presentMode = GpuSurface.PresentMode.FIFO;
	private boolean suboptimal;
	private boolean outOfDate;
	private boolean closed;

	private final Set<GpuSurface.PresentMode> supportedPresentModes =
		EnumSet.of(GpuSurface.PresentMode.IMMEDIATE, GpuSurface.PresentMode.FIFO);

	public D3D11GpuSurface(D3D11Context context, long windowHandle, BooleanSupplier isIconified) {
		this.context = context;
		this.windowHandle = windowHandle;
		this.isIconified = isIconified;
	}

	@Override
	public Collection<GpuSurface.PresentMode> supportedPresentModes() {
		return this.supportedPresentModes;
	}

	private void releaseBackBuffer() {
		D3D11Com.release(this.backBufferRtv);
		this.backBufferRtv = MemorySegment.NULL;
		D3D11Com.release(this.backBuffer);
		this.backBuffer = MemorySegment.NULL;
	}

	private void destroySwapchain() {
		this.releaseBackBuffer();
		D3D11Com.release(this.swapchain);
		this.swapchain = MemorySegment.NULL;
		this.presentHandle = null;
		this.outOfDate = false;
		this.suboptimal = false;
	}

	@Override
	public void configure(GpuSurface.Configuration config) {
		int width = Math.max(1, config.width());
		int height = Math.max(1, config.height());
		this.presentMode = config.presentMode();

		try {
			if (this.swapchain.address() != 0L) {
				this.resizeSwapchain(width, height);
			} else {
				this.createSwapchain(width, height);
			}

			this.swapchainWidth = width;
			this.swapchainHeight = height;
			this.outOfDate = false;
			this.suboptimal = false;
		} catch (Throwable throwable) {
			DirectGraphix.LOGGER.error("[DirectGraphix] Failed to configure D3D11 swap chain", throwable);
			this.destroySwapchain();
			this.outOfDate = true;
		}
	}

	private void createSwapchain(int width, int height) throws Throwable {
		long hwnd = D3D11Dxgi.getHwnd(this.windowHandle);
		MemorySegment factory = D3D11Dxgi.getFactory(this.context);

		try (Arena arena = Arena.ofConfined()) {
			// DXGI_SWAP_CHAIN_DESC (68 bayt, 72'ye yuvarlandi)
			MemorySegment desc = arena.allocate(72, 8);
			desc.set(JAVA_INT, 0, width);                                  // BufferDesc.Width
			desc.set(JAVA_INT, 4, height);                                 // BufferDesc.Height
			desc.set(JAVA_INT, 8, 0);                                      // RefreshRate.Numerator
			desc.set(JAVA_INT, 12, 1);                                     // RefreshRate.Denominator
			desc.set(JAVA_INT, 16, DXGI_FORMAT_R8G8B8A8_UNORM);            // Format
			desc.set(JAVA_INT, 20, 0);                                     // ScanlineOrdering
			desc.set(JAVA_INT, 24, 0);                                     // Scaling
			desc.set(JAVA_INT, 28, 1);                                     // SampleDesc.Count
			desc.set(JAVA_INT, 32, 0);                                     // SampleDesc.Quality
			desc.set(JAVA_INT, 36, DXGI_USAGE_RENDER_TARGET_OUTPUT);       // BufferUsage
			desc.set(JAVA_INT, 40, 1);                                     // BufferCount
			desc.set(JAVA_LONG, 48, hwnd);                                 // OutputWindow (HWND)
			desc.set(JAVA_INT, 56, 1);                                     // Windowed
			desc.set(JAVA_INT, 60, DXGI_SWAP_EFFECT_DISCARD);              // SwapEffect
			desc.set(JAVA_INT, 64, 0);                                     // Flags

			MemorySegment outSwapchain = arena.allocate(ADDRESS);
			// IDXGIFactory::CreateSwapChain = vtable index 10
			MethodHandle createSwapchain = D3D11Com.method(
				factory,
				10,
				FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, ADDRESS, ADDRESS)
			);
			D3D11Com.checkHr((int) createSwapchain.invoke(factory, this.context.device, desc, outSwapchain), "IDXGIFactory::CreateSwapChain");
			this.swapchain = outSwapchain.get(ADDRESS, 0);

			// IDXGIFactory::MakeWindowAssociation = vtable index 8 (Alt+Enter'i DXGI'dan al, SDL yonetsin)
			MethodHandle makeAssociation = D3D11Com.method(factory, 8, FunctionDescriptor.of(JAVA_INT, ADDRESS, JAVA_LONG, JAVA_INT));
			int ignored = (int) makeAssociation.invoke(factory, hwnd, DXGI_MWA_NO_ALT_ENTER);

			// IDXGISwapChain::Present = vtable index 8
			this.presentHandle = D3D11Com.method(this.swapchain, 8, FunctionDescriptor.of(JAVA_INT, ADDRESS, JAVA_INT, JAVA_INT));
		} finally {
			D3D11Com.release(factory);
		}

		this.fetchBackBuffer();
	}

	private void resizeSwapchain(int width, int height) throws Throwable {
		// Yeniden boyutlandirmadan once back buffer referansi birakilmali.
		this.releaseBackBuffer();

		// IDXGISwapChain::ResizeBuffers = vtable index 13
		MethodHandle resize = D3D11Com.method(
			this.swapchain,
			13,
			FunctionDescriptor.of(JAVA_INT, ADDRESS, JAVA_INT, JAVA_INT, JAVA_INT, JAVA_INT, JAVA_INT)
		);
		D3D11Com.checkHr((int) resize.invoke(this.swapchain, 0, width, height, 0, 0), "IDXGISwapChain::ResizeBuffers");
		this.fetchBackBuffer();
	}

	private void fetchBackBuffer() throws Throwable {
		try (Arena arena = Arena.ofConfined()) {
			MemorySegment out = arena.allocate(ADDRESS);
			// IDXGISwapChain::GetBuffer = vtable index 9
			MethodHandle getBuffer = D3D11Com.method(
				this.swapchain,
				9,
				FunctionDescriptor.of(JAVA_INT, ADDRESS, JAVA_INT, ADDRESS, ADDRESS)
			);
			D3D11Com.checkHr((int) getBuffer.invoke(this.swapchain, 0, D3D11Dxgi.iidTexture2D(arena), out), "IDXGISwapChain::GetBuffer");
			this.backBuffer = out.get(ADDRESS, 0);

			// Flip-blit icin back buffer'in render target view'i (olusmazsa satir satir kopyalama kullanilir)
			MemorySegment outRtv = arena.allocate(ADDRESS);
			MethodHandle createRtv = D3D11Com.method(
				this.context.device,
				9,
				FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, ADDRESS, ADDRESS)
			);
			int hr = (int) createRtv.invokeExact(this.context.device, this.backBuffer, MemorySegment.NULL, outRtv);
			if (hr >= 0) {
				this.backBufferRtv = outRtv.get(ADDRESS, 0);
			}
		}
	}

	@Override
	public boolean isSuboptimal() {
		return this.suboptimal;
	}

	@Override
	public void acquireNextTexture() {
		// D3D11'de (DISCARD modeli) back buffer her zaman hazir, yapilacak bir sey yok.
	}

	@Override
	public void blitFromTexture(CommandEncoderBackend commandEncoder, GpuTextureView textureView) {
		if (this.outOfDate || this.backBuffer.address() == 0L) {
			return;
		}

		D3D11GpuTexture source = (D3D11GpuTexture) textureView.texture();
		if (source.resource().address() == 0L) {
			return;
		}

		int width = Math.min(this.swapchainWidth, source.getWidth(0));
		int height = Math.min(this.swapchainHeight, source.getHeight(0));
		if (width <= 0 || height <= 0) {
			return;
		}

		// DUZELTME: Ana hedef OpenGL/Vulkan duzeninde (satir 0 = ekranin alti) oldugu icin DIKEY CEVIREREK basilir.
		if (this.flipBlit == null && !this.flipBlitFailed) {
			this.flipBlit = D3D11FlipBlit.tryCreate(this.context);
			this.flipBlitFailed = this.flipBlit == null;
		}
		if (this.flipBlit != null
			&& this.backBufferRtv.address() != 0L
			&& textureView instanceof D3D11GpuTextureView d3dView
			&& d3dView.resource().address() != 0L) {
			if (this.flipBlit.blit(d3dView.resource(), this.backBufferRtv, width, height)) {
				return;
			}
		}

		// Yedek yontem: satir satir ters kopyalama (yavas ama her zaman calisir)
		try (Arena arena = Arena.ofConfined()) {
			if (this.copyRegionHandle == null) {
				// ID3D11DeviceContext::CopySubresourceRegion = vtable index 46
				this.copyRegionHandle = D3D11Com.method(
					this.context.immediateContext,
					46,
					FunctionDescriptor.ofVoid(ADDRESS, ADDRESS, JAVA_INT, JAVA_INT, JAVA_INT, JAVA_INT, ADDRESS, JAVA_INT, ADDRESS)
				);
			}

			// D3D11_BOX: left, top, front, right, bottom, back
			MemorySegment box = arena.allocate(24, 4);
			box.set(JAVA_INT, 0, 0);
			box.set(JAVA_INT, 8, 0);
			box.set(JAVA_INT, 12, width);
			box.set(JAVA_INT, 20, 1);

			for (int row = 0; row < height; row++) {
				box.set(JAVA_INT, 4, row);
				box.set(JAVA_INT, 16, row + 1);
				this.copyRegionHandle.invokeExact(this.context.immediateContext, this.backBuffer, 0, 0, height - 1 - row, 0, source.resource(), 0, box);
			}
		} catch (Throwable throwable) {
			DirectGraphix.LOGGER.error("[DirectGraphix] D3D11 blit to back buffer failed", throwable);
		}
	}

	@Override
	public void present() {
		if (this.outOfDate || this.swapchain.address() == 0L || this.presentHandle == null) {
			return;
		}

		if (this.isIconified.getAsBoolean()) {
			return;
		}

		int syncInterval = this.presentMode == GpuSurface.PresentMode.IMMEDIATE ? 0 : 1;
		try {
			int hr = (int) this.presentHandle.invokeExact(this.swapchain, syncInterval, 0);
			if (hr < 0) {
				DirectGraphix.LOGGER.error("[DirectGraphix] IDXGISwapChain::Present failed, HRESULT = 0x{}", Integer.toHexString(hr));
				this.suboptimal = true;
				this.outOfDate = true;
			}
		} catch (Throwable throwable) {
			throw new IllegalStateException("D3D11 Present failed", throwable);
		}
	}

	@Override
	public void close() {
		if (this.closed) {
			return;
		}

		this.closed = true;
		if (this.flipBlit != null) {
			this.flipBlit.close();
			this.flipBlit = null;
		}
		this.destroySwapchain();
	}
}

