package com.directx.client.d3d11;

import static java.lang.foreign.ValueLayout.ADDRESS;
import static java.lang.foreign.ValueLayout.JAVA_FLOAT;
import static java.lang.foreign.ValueLayout.JAVA_INT;

import com.mojang.renderpearl.api.textures.AddressMode;
import com.mojang.renderpearl.api.textures.FilterMode;
import com.mojang.renderpearl.api.textures.GpuSampler;
import java.lang.foreign.Arena;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.MemorySegment;
import java.lang.invoke.MethodHandle;
import java.util.OptionalDouble;

public class D3D11GpuSampler implements GpuSampler {
	private static final int DEVICE_CREATE_SAMPLER_STATE = 23;

	private static final int D3D11_TEXTURE_ADDRESS_WRAP = 1;
	private static final int D3D11_TEXTURE_ADDRESS_MIRROR = 2;
	private static final int D3D11_TEXTURE_ADDRESS_CLAMP = 3;

	private static final int D3D11_FILTER_MIN_MAG_MIP_POINT = 0x00000000;
	private static final int D3D11_FILTER_MIN_MAG_POINT_MIP_LINEAR = 0x00000001;
	private static final int D3D11_FILTER_MIN_POINT_MAG_LINEAR_MIP_POINT = 0x00000004;
	private static final int D3D11_FILTER_MIN_LINEAR_MAG_MIP_POINT = 0x00000010;
	private static final int D3D11_FILTER_MIN_MAG_MIP_LINEAR = 0x00000015;
	private static final int D3D11_FILTER_ANISOTROPIC = 0x00000055;

	private static final int D3D11_COMPARISON_NEVER = 1;
	private static final float D3D11_FLOAT32_MAX = 3.402823466e+38f;

	private final D3D11Context context;
	private final MemorySegment resource;
	private final AddressMode addressModeU;
	private final AddressMode addressModeV;
	private final FilterMode minFilter;
	private final FilterMode magFilter;
	private final int maxAnisotropy;
	private final OptionalDouble maxLod;
	private boolean closed;

	public D3D11GpuSampler(
		D3D11Context context,
		AddressMode addressModeU,
		AddressMode addressModeV,
		FilterMode minFilter,
		FilterMode magFilter,
		int maxAnisotropy,
		OptionalDouble maxLod,
		MemorySegment resource
	) {
		this.context = context;
		this.addressModeU = addressModeU;
		this.addressModeV = addressModeV;
		this.minFilter = minFilter;
		this.magFilter = magFilter;
		this.maxAnisotropy = maxAnisotropy;
		this.maxLod = maxLod;
		this.resource = resource;
	}

	public static D3D11GpuSampler create(
		D3D11Context context,
		AddressMode addressModeU,
		AddressMode addressModeV,
		FilterMode minFilter,
		FilterMode magFilter,
		int maxAnisotropy,
		OptionalDouble maxLod
	) {
		int clampedAniso = Math.max(1, Math.min(16, maxAnisotropy));
		boolean useAnisotropic = clampedAniso > 1 && (minFilter == FilterMode.LINEAR || magFilter == FilterMode.LINEAR);
		int filter = useAnisotropic ? D3D11_FILTER_ANISOTROPIC : resolveFilter(minFilter, magFilter);
		float maxLodValue = maxLod.isPresent() ? Math.max(0.0f, (float) maxLod.getAsDouble()) : D3D11_FLOAT32_MAX;

		MemorySegment resource;
		try (Arena arena = Arena.ofConfined()) {
			// D3D11_SAMPLER_DESC (52 bayt)
			MemorySegment desc = arena.allocate(52, 4);
			desc.set(JAVA_INT, 0, filter);
			desc.set(JAVA_INT, 4, resolveAddress(addressModeU));
			desc.set(JAVA_INT, 8, resolveAddress(addressModeV));
			desc.set(JAVA_INT, 12, D3D11_TEXTURE_ADDRESS_CLAMP);
			desc.set(JAVA_FLOAT, 16, 0.0f); // MipLODBias
			desc.set(JAVA_INT, 20, clampedAniso);
			desc.set(JAVA_INT, 24, D3D11_COMPARISON_NEVER);
			desc.set(JAVA_FLOAT, 28, 0.0f); // BorderColor[0]
			desc.set(JAVA_FLOAT, 32, 0.0f); // BorderColor[1]
			desc.set(JAVA_FLOAT, 36, 0.0f); // BorderColor[2]
			desc.set(JAVA_FLOAT, 40, 0.0f); // BorderColor[3]
			desc.set(JAVA_FLOAT, 44, 0.0f); // MinLOD
			desc.set(JAVA_FLOAT, 48, maxLodValue); // MaxLOD

			MemorySegment out = arena.allocate(ADDRESS);
			MethodHandle handle = D3D11Com.method(
				context.device,
				DEVICE_CREATE_SAMPLER_STATE,
				FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, ADDRESS)
			);
			int hr = (int) handle.invokeExact(context.device, desc, out);
			D3D11Com.checkHr(hr, "CreateSamplerState");
			resource = out.get(ADDRESS, 0).reinterpret(8);
		} catch (Throwable throwable) {
			throw new IllegalStateException("Failed to create D3D11 sampler", throwable);
		}

		return new D3D11GpuSampler(context, addressModeU, addressModeV, minFilter, magFilter, maxAnisotropy, maxLod, resource);
	}

	private static int resolveAddress(AddressMode mode) {
		if (mode == null) {
			return D3D11_TEXTURE_ADDRESS_CLAMP;
		}
		return switch (mode.name()) {
			case "REPEAT" -> D3D11_TEXTURE_ADDRESS_WRAP;
			case "MIRROR", "MIRRORED_REPEAT", "MIRROR_REPEAT" -> D3D11_TEXTURE_ADDRESS_MIRROR;
			case "CLAMP_TO_EDGE", "CLAMP" -> D3D11_TEXTURE_ADDRESS_CLAMP;
			default -> D3D11_TEXTURE_ADDRESS_CLAMP;
		};
	}

	private static int resolveFilter(FilterMode min, FilterMode mag) {
		if (min == FilterMode.LINEAR && mag == FilterMode.LINEAR) {
			return D3D11_FILTER_MIN_MAG_MIP_LINEAR;
		}
		if (min == FilterMode.LINEAR && mag == FilterMode.NEAREST) {
			return D3D11_FILTER_MIN_LINEAR_MAG_MIP_POINT;
		}
		if (min == FilterMode.NEAREST && mag == FilterMode.LINEAR) {
			return D3D11_FILTER_MIN_POINT_MAG_LINEAR_MIP_POINT;
		}
		return D3D11_FILTER_MIN_MAG_MIP_POINT;
	}

	public MemorySegment resource() {
		return this.resource;
	}

	@Override
	public AddressMode getAddressModeU() {
		return this.addressModeU;
	}

	@Override
	public AddressMode getAddressModeV() {
		return this.addressModeV;
	}

	@Override
	public FilterMode getMinFilter() {
		return this.minFilter;
	}

	@Override
	public FilterMode getMagFilter() {
		return this.magFilter;
	}

	@Override
	public int getMaxAnisotropy() {
		return this.maxAnisotropy;
	}

	@Override
	public OptionalDouble getMaxLod() {
		return this.maxLod;
	}

	@Override
	public boolean isClosed() {
		return this.closed;
	}

	@Override
	public void close() {
		if (this.closed) {
			return;
		}
		this.closed = true;
		D3D11Com.release(this.resource);
	}
}