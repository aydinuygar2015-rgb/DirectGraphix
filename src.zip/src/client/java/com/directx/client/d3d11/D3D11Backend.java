package com.directx.client.d3d11;

import com.directx.DirectGraphix;
import com.mojang.renderpearl.api.buffers.GpuBuffer;
import com.mojang.renderpearl.api.device.BackendCreationException;
import com.mojang.renderpearl.api.device.GpuBackend;
import com.mojang.renderpearl.api.device.GpuDebugOptions;
import com.mojang.renderpearl.api.device.GpuDevice;
import com.mojang.renderpearl.frontend.FrontendGpuDevice;
import java.lang.foreign.Arena;
import java.lang.foreign.SymbolLookup;
import java.nio.ByteBuffer;
import java.util.Locale;
import org.jspecify.annotations.Nullable;
import org.lwjgl.sdl.SDLVideo;
import org.lwjgl.system.MemoryUtil;

public class D3D11Backend implements GpuBackend {
    private boolean libraryLoaded;

    @Override
    public String getName() {
        return "Direct3D 11";
    }

    @Override
    public void loadLibrary() throws BackendCreationException {
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);

        if (!os.contains("win")) {
            throw new BackendCreationException(
                "Direct3D 11 is only available on Windows",
                BackendCreationException.Reason.PLATFORM_ERROR
            );
        }

        try {
            SymbolLookup.libraryLookup("d3d11.dll", Arena.global());
        } catch (IllegalArgumentException exception) {
            throw new BackendCreationException(
                "d3d11.dll could not be loaded: " + exception.getMessage(),
                BackendCreationException.Reason.PLATFORM_ERROR
            );
        }

        this.libraryLoaded = true;
    }

    @Override
    public void unloadLibrary() {
        if (this.libraryLoaded) {
            DirectGraphix.LOGGER.info(
                "[DirectGraphix] D3D11 backend unloadLibrary() called"
            );
            this.libraryLoaded = false;
        }
    }

    @Override
    public long createWindow(
            @Nullable String title,
            int width,
            int height,
            long flags
    ) {
        return SDLVideo.SDL_CreateWindow(title, width, height, flags);
    }

    @Override
    public GpuDevice createDevice(
            GpuDebugOptions debugOptions
    ) throws BackendCreationException {

        D3D11Context context;

        try {
            context = D3D11Context.create();
        } catch (Throwable throwable) {
            DirectGraphix.LOGGER.error(
                "[DirectGraphix] D3D11 device creation failed",
                throwable
            );

            throw new BackendCreationException(
                "D3D11 device creation failed: " + throwable,
                BackendCreationException.Reason.OTHER
            );
        }

        DirectGraphix.LOGGER.info(
            "[DirectGraphix] D3D11 device OK: adapter='{}', vendorId=0x{}, deviceId=0x{}, vram={} MB, featureLevel={}",
            context.adapterName,
            Integer.toHexString(context.vendorId),
            Integer.toHexString(context.deviceId),
            context.dedicatedVideoMemory / (1024L * 1024L),
            context.featureLevelName()
        );

        DirectGraphix.LOGGER.info(
            "[DirectGraphix] Experimental startup gate removed; continuing with D3D11"
        );

        try {
            runBufferSmokeTest(context);

            return new FrontendGpuDevice(
                new D3D11Device(context)
            );

        } catch (RuntimeException exception) {
            context.close();

            DirectGraphix.LOGGER.error(
                "[DirectGraphix] Failed to initialize D3D11 device",
                exception
            );

            throw new BackendCreationException(
                "Failed to initialize D3D11 device: " + exception,
                BackendCreationException.Reason.OTHER
            );
        }
    }

    private static void runBufferSmokeTest(D3D11Context context) {
        ByteBuffer initial = MemoryUtil.memAlloc(64);
        ByteBuffer update = MemoryUtil.memAlloc(16);

        try {
            for (int i = 0; i < 64; i++) {
                initial.put((byte) i);
            }

            initial.flip();

            for (int i = 0; i < 16; i++) {
                update.put((byte) (100 + i));
            }

            update.flip();

            D3D11GpuBuffer plain = D3D11GpuBuffer.create(
                context,
                "smoke-vertex",
                GpuBuffer.USAGE_VERTEX | GpuBuffer.USAGE_COPY_DST,
                64,
                initial
            );

            plain.writeData(16, update);
            plain.close();

            D3D11GpuBuffer mapped = D3D11GpuBuffer.create(
                context,
                "smoke-uniform",
                GpuBuffer.USAGE_UNIFORM | GpuBuffer.USAGE_MAP_WRITE,
                256,
                null
            );

            try (var view = mapped.map(false, true)) {
                view.data().putInt(0, 12345);
            }

            mapped.checkCanBeUsed();
            mapped.close();

            DirectGraphix.LOGGER.info(
                "[DirectGraphix] D3D11 buffer smoke test OK"
            );

        } finally {
            MemoryUtil.memFree(initial);
            MemoryUtil.memFree(update);
        }
    }
}