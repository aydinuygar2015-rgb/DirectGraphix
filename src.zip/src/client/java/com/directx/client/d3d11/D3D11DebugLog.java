package com.directx.client.d3d11;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import org.jspecify.annotations.Nullable;

public final class D3D11DebugLog {
	private static final int MAX_DETAILED_PASSES = 25;
	private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm:ss.SSS");
	private static final AtomicBoolean INITIALIZED = new AtomicBoolean(false);
	private static final AtomicInteger PASS_COUNT = new AtomicInteger(0);
	private static final Object LOCK = new Object();

	private static @Nullable BufferedWriter writer;
	private static boolean currentPassDetailed = false;

	private D3D11DebugLog() {
	}

	public static void init() {
		if (!INITIALIZED.compareAndSet(false, true)) {
			return;
		}
		synchronized (LOCK) {
			try {
				Path logPath = Paths.get("logs", "directgraphix-d3d11.txt");
				if (logPath.getParent() != null) {
					Files.createDirectories(logPath.getParent());
				}
				writer = Files.newBufferedWriter(
					logPath,
					StandardCharsets.UTF_8,
					StandardOpenOption.CREATE,
					StandardOpenOption.TRUNCATE_EXISTING,
					StandardOpenOption.WRITE
				);
				writeRaw("================================================================================\n");
				writeRaw(" DirectGraphix D3D11 Detayli Teshis Gunlugu\n");
				writeRaw(" Dosya: " + logPath.toAbsolutePath() + "\n");
				writeRaw("================================================================================\n\n");
				flushLocked();

				Runtime.getRuntime().addShutdownHook(new Thread(D3D11DebugLog::close, "D3D11DebugLog-Shutdown"));
			} catch (IOException e) {
				System.err.println("[DirectGraphix] D3D11DebugLog baslatilamadi: " + e.getMessage());
			}
		}
	}

	public static boolean isDetailedPassActive() {
		return currentPassDetailed;
	}

	public static void info(String category, String message) {
		init();
		synchronized (LOCK) {
			writeLine("INFO", category, message);
		}
	}

	public static void warn(String category, String message) {
		init();
		synchronized (LOCK) {
			writeLine("WARN", category, message);
			flushLocked();
		}
	}

	public static void error(String category, String message, @Nullable Throwable throwable) {
		init();
		synchronized (LOCK) {
			writeLine("ERROR", category, message);
			if (throwable != null) {
				StringWriter sw = new StringWriter();
				throwable.printStackTrace(new PrintWriter(sw));
				writeRaw(sw + "\n");
			}
			flushLocked();
		}
	}

	public static void shader(
		String stage,
		String entryPoint,
		Map<String, Integer> cbuffers,
		Map<String, Integer> textures,
		Map<String, Integer> samplers,
		String hlsl
	) {
		init();
		synchronized (LOCK) {
			writeLine("SHADER", stage, "entry=" + entryPoint + " | cb=" + cbuffers + " | tex=" + textures + " | samp=" + samplers);
			writeRaw("--- BEGIN HLSL (" + stage + ") ---\n");
			writeRaw(hlsl);
			if (!hlsl.endsWith("\n")) {
				writeRaw("\n");
			}
			writeRaw("--- END HLSL (" + stage + ") ---\n\n");
			flushLocked();
		}
	}

	public static void pipeline(
		String name,
		String topology,
		int[] strides,
		List<String> attribs,
		List<String> uniforms,
		int vsPushSlot,
		int psPushSlot
	) {
		init();
		synchronized (LOCK) {
			StringBuilder sb = new StringBuilder();
			sb.append("name='").append(name).append("' topology=").append(topology)
				.append(" pushSlots(vs=").append(vsPushSlot).append(", ps=").append(psPushSlot).append(")\n");
			sb.append("    VertexStrides: [");
			for (int i = 0; i < strides.length; i++) {
				if (i > 0) sb.append(", ");
				sb.append("slot").append(i).append("=").append(strides[i]);
			}
			sb.append("]\n");
			for (String attr : attribs) {
				sb.append("    Attrib: ").append(attr).append("\n");
			}
			for (String u : uniforms) {
				sb.append("    Uniform: ").append(u).append("\n");
			}
			writeLine("PIPELINE", "CREATE", sb.toString().stripTrailing());
			flushLocked();
		}
	}

	public static void texture(
		@Nullable String label,
		String format,
		int dxgiFormat,
		int width,
		int height,
		int layers,
		int mips,
		int usage,
		int bindFlags
	) {
		init();
		synchronized (LOCK) {
			writeLine(
				"TEXTURE",
				"CREATE",
				String.format(
					"label='%s' fmt=%s (dxgi=%d) size=%dx%d layers=%d mips=%d usage=0x%x bind=0x%x",
					label == null ? "" : label, format, dxgiFormat, width, height, layers, mips, usage, bindFlags
				)
			);
			flushLocked();
		}
	}

	public static void textureView(
		@Nullable String label,
		String format,
		int baseMip,
		int mipLevels,
		int totalMips,
		int hr
	) {
		init();
		synchronized (LOCK) {
			writeLine(
				"TEX_VIEW",
				hr >= 0 ? "OK" : "FAIL",
				String.format(
					"label='%s' fmt=%s baseMip=%d mipLevels=%d/%d hr=0x%x",
					label == null ? "" : label, format, baseMip, mipLevels, totalMips, hr
				)
			);
			flushLocked();
		}
	}

	public static void beginPass(String label, int colorCount, boolean hasDepth, int width, int height) {
		init();
		int passIndex = PASS_COUNT.incrementAndGet();
		currentPassDetailed = passIndex <= MAX_DETAILED_PASSES;
		if (!currentPassDetailed) {
			return;
		}
		synchronized (LOCK) {
			writeRaw("\n==================== PASS #" + passIndex + " : '" + label + "' ====================\n");
			writeLine(
				"PASS",
				"BEGIN",
				String.format("colors=%d depth=%s outputSize=%dx%d", colorCount, hasDepth, width, height)
			);
			flushLocked();
		}
	}

	public static void passDetail(String action, String details) {
		if (!currentPassDetailed) {
			return;
		}
		synchronized (LOCK) {
			writeLine("DRAW", action, details);
		}
	}

	public static String dumpFloats(@Nullable ByteBuffer buffer, int maxFloats) {
		if (buffer == null || buffer.remaining() < 4) {
			return "[]";
		}
		ByteBuffer dup = buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN);
		int count = Math.min(maxFloats, dup.remaining() / 4);
		StringBuilder sb = new StringBuilder("[");
		for (int i = 0; i < count; i++) {
			if (i > 0) sb.append(", ");
			sb.append(String.format("%.4f", dup.getFloat()));
		}
		if (dup.remaining() >= 4) {
			sb.append(", ...");
		}
		sb.append("]");
		return sb.toString();
	}

	public static String dumpVertices(@Nullable ByteBuffer buffer, int strideBytes, int maxVertices) {
		if (buffer == null || strideBytes <= 0 || buffer.remaining() < strideBytes) {
			return "[]";
		}
		ByteBuffer dup = buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN);
		int startPos = dup.position();
		int availableVerts = dup.remaining() / strideBytes;
		int count = Math.min(maxVertices, availableVerts);
		int floatsPerVert = strideBytes / 4;

		StringBuilder sb = new StringBuilder();
		for (int v = 0; v < count; v++) {
			sb.append("\n      v[").append(v).append("]: ");
			int base = startPos + v * strideBytes;
			for (int f = 0; f < floatsPerVert; f++) {
				if (f > 0) sb.append(" | ");
				int intBits = dup.getInt(base + f * 4);
				float floatVal = Float.intBitsToFloat(intBits);
				if (Float.isFinite(floatVal) && Math.abs(floatVal) < 1_000_000.0f && (intBits == 0 || Math.abs(floatVal) > 1e-6f)) {
					sb.append(String.format("%.4f (0x%08x)", floatVal, intBits));
				} else {
					sb.append(String.format("0x%08x", intBits));
				}
			}
		}
		return sb.toString();
	}

	public static void flush() {
		synchronized (LOCK) {
			flushLocked();
		}
	}

	public static void close() {
		synchronized (LOCK) {
			if (writer != null) {
				try {
					writeLine("SYSTEM", "CLOSE", "D3D11DebugLog kapatiliyor.");
					writer.flush();
					writer.close();
				} catch (IOException ignored) {
				} finally {
					writer = null;
				}
			}
		}
	}

	private static void writeLine(String level, String tag, String msg) {
		String time = LocalTime.now().format(TIME_FMT);
		writeRaw("[" + time + "] [" + level + "/" + tag + "] " + msg + "\n");
	}

	private static void writeRaw(String text) {
		if (writer == null) {
			return;
		}
		try {
			writer.write(text);
		} catch (IOException ignored) {
		}
	}

	private static void flushLocked() {
		if (writer != null) {
			try {
				writer.flush();
			} catch (IOException ignored) {
			}
		}
	}
}