package com.directx.client.d3d11;

import com.mojang.renderpearl.api.commands.GpuFence;

/**
 * Su an her zaman "tamamlanmis" sayilan fence. UpdateSubresource veriyi cagri aninda kopyaladigi icin
 * CPU golge kopyalari hemen tekrar kullanilabilir. Gerekirse sonra D3D11 event query ile degistirilecek.
 */
public class D3D11Fence implements GpuFence {
	@Override
	public void close() {
	}

	@Override
	public boolean awaitCompletion(long timeoutNS) {
		return true;
	}
}