package com.directx.client.d3d11;

import static java.lang.foreign.ValueLayout.ADDRESS;
import static java.lang.foreign.ValueLayout.JAVA_BYTE;
import static java.lang.foreign.ValueLayout.JAVA_INT;
import static java.lang.foreign.ValueLayout.JAVA_SHORT;

import java.lang.foreign.Arena;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.MemorySegment;
import java.lang.invoke.MethodHandle;
import org.lwjgl.sdl.SDLError;
import org.lwjgl.sdl.SDLProperties;
import org.lwjgl.sdl.SDLVideo;

/** DXGI ile ilgili yardimcilar: SDL penceresinden HWND alma, device'in kendi factory'sini bulma, GUID'ler. */
public final class D3D11Dxgi {
	private static final String SDL_HWND_PROPERTY = "SDL.window.win32.hwnd";

	private D3D11Dxgi() {
	}

	/** SDL_Window* isaretcisinden Win32 HWND'yi alir. */
	public static long getHwnd(long sdlWindow) {
		int props = SDLVideo.SDL_GetWindowProperties(sdlWindow);
		if (props == 0) {
			throw new IllegalStateException("SDL_GetWindowProperties failed: " + SDLError.SDL_GetError());
		}

		long hwnd = SDLProperties.SDL_GetPointerProperty(props, SDL_HWND_PROPERTY, 0L);
		if (hwnd == 0L) {
			throw new IllegalStateException("SDL window has no Win32 HWND property");
		}

		return hwnd;
	}

	public static MemorySegment guid(Arena arena, int data1, short data2, short data3, int... data4) {
		MemorySegment guid = arena.allocate(16, 4);
		guid.set(JAVA_INT, 0, data1);
		guid.set(JAVA_SHORT, 4, data2);
		guid.set(JAVA_SHORT, 6, data3);
		for (int i = 0; i < 8; i++) {
			guid.set(JAVA_BYTE, 8 + i, (byte) data4[i]);
		}
		return guid;
	}

	/** IID_IDXGIDevice = {54ec77fa-1377-44e6-8c32-88fd5f44c84c} */
	public static MemorySegment iidDxgiDevice(Arena arena) {
		return guid(arena, 0x54ec77fa, (short) 0x1377, (short) 0x44e6, 0x8c, 0x32, 0x88, 0xfd, 0x5f, 0x44, 0xc8, 0x4c);
	}

	/** IID_IDXGIFactory = {7b7166ec-21c7-44ae-b21a-c9ae321ae369} */
	public static MemorySegment iidDxgiFactory(Arena arena) {
		return guid(arena, 0x7b7166ec, (short) 0x21c7, (short) 0x44ae, 0xb2, 0x1a, 0xc9, 0xae, 0x32, 0x1a, 0xe3, 0x69);
	}

	/** IID_ID3D11Texture2D = {6f15aaf2-d208-4e89-9ab4-489535d34f9c} */
	public static MemorySegment iidTexture2D(Arena arena) {
		return guid(arena, 0x6f15aaf2, (short) 0xd208, (short) 0x4e89, 0x9a, 0xb4, 0x48, 0x95, 0x35, 0xd3, 0x4f, 0x9c);
	}

	/**
	 * Device'in kendi adaptorunun factory'sini verir: device -> IDXGIDevice -> IDXGIAdapter -> IDXGIFactory.
	 * Swapchain, device ile ayni factory'den olusturulmali. Donen nesneyi cagiran Release etmeli.
	 */
	public static MemorySegment getFactory(D3D11Context context) throws Throwable {
		MemorySegment dxgiDevice = MemorySegment.NULL;
		MemorySegment adapter = MemorySegment.NULL;

		try (Arena arena = Arena.ofConfined()) {
			MemorySegment out = arena.allocate(ADDRESS);

			// IUnknown::QueryInterface = vtable index 0
			MethodHandle queryInterface = D3D11Com.method(context.device, 0, FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, ADDRESS));
			D3D11Com.checkHr((int) queryInterface.invoke(context.device, iidDxgiDevice(arena), out), "QueryInterface(IDXGIDevice)");
			dxgiDevice = out.get(ADDRESS, 0);

			// IDXGIDevice::GetAdapter = vtable index 7
			MethodHandle getAdapter = D3D11Com.method(dxgiDevice, 7, FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS));
			D3D11Com.checkHr((int) getAdapter.invoke(dxgiDevice, out), "IDXGIDevice::GetAdapter");
			adapter = out.get(ADDRESS, 0);

			// IDXGIObject::GetParent = vtable index 6
			MethodHandle getParent = D3D11Com.method(adapter, 6, FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, ADDRESS));
			D3D11Com.checkHr((int) getParent.invoke(adapter, iidDxgiFactory(arena), out), "IDXGIAdapter::GetParent(IDXGIFactory)");
			return out.get(ADDRESS, 0);
		} finally {
			D3D11Com.release(adapter);
			D3D11Com.release(dxgiDevice);
		}
	}
}