package com.directx.client.d3d11;

import com.directx.DirectGraphix;
import com.mojang.renderpearl.api.GpuFormat;
import com.mojang.renderpearl.api.buffers.GpuBuffer;
import com.mojang.renderpearl.api.commands.GpuQueryPool;
import com.mojang.renderpearl.api.device.DeviceFeatures;
import com.mojang.renderpearl.api.device.DeviceInfo;
import com.mojang.renderpearl.api.device.DeviceLimits;
import com.mojang.renderpearl.api.device.DeviceType;
import com.mojang.renderpearl.api.device.HintsAndWorkarounds;
import com.mojang.renderpearl.api.pipeline.ShaderType;
import com.mojang.renderpearl.api.textures.AddressMode;
import com.mojang.renderpearl.api.textures.FilterMode;
import com.mojang.renderpearl.api.textures.GpuSampler;
import com.mojang.renderpearl.api.textures.GpuTexture;
import com.mojang.renderpearl.api.textures.GpuTextureView;
import com.mojang.renderpearl.backend.api.BackendRenderPipeline;
import com.mojang.renderpearl.backend.api.CommandEncoderBackend;
import com.mojang.renderpearl.backend.api.GpuDeviceBackend;
import com.mojang.renderpearl.backend.api.GpuSurfaceBackend;
import com.mojang.renderpearl.backend.api.SpvModule;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.OptionalDouble;
import java.util.Set;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;
import org.jspecify.annotations.Nullable;

public class D3D11Device implements GpuDeviceBackend {
	private final D3D11Context context;
	private final DeviceInfo deviceInfo;

	public D3D11Device(D3D11Context context) {
		this.context = context;
		this.deviceInfo = buildDeviceInfo(context);
	}

	private static DeviceInfo buildDeviceInfo(D3D11Context context) {
		String vendorName = switch (context.vendorId) {
			case 0x10de -> "NVIDIA";
			case 0x1002, 0x1022 -> "AMD";
			case 0x8086 -> "Intel";
			case 0x1414 -> "Microsoft";
			default -> "0x" + Integer.toHexString(context.vendorId);
		};

		DeviceType type = context.vendorId == 0x8086 || context.dedicatedVideoMemory < (1L << 30)
			? DeviceType.INTEGRATED
			: DeviceType.DISCRETE;

		int maxTextureSize = context.featureLevel >= 0xb000 ? 16384 : 8192;

		DeviceLimits limits = new DeviceLimits(
			16,
			256,
			maxTextureSize,
			Math.max(1L << 30, context.dedicatedVideoMemory),
			0,
			8,
			1
		);

		DeviceFeatures features = new DeviceFeatures(
			true,
			false,
			false,
			false,
			false,
			true,
			true,
			false
		);

		return new DeviceInfo(
			context.adapterName,
			vendorName,
			"Direct3D 11 (feature level " + context.featureLevelName() + ")",
			true,
			"Direct3D 11",
			1.0f,
			limits,
			features,
			Set.of("D3D_FEATURE_LEVEL_" + context.featureLevelName()),
			new HintsAndWorkarounds(false, false, false, false),
			type
		);
	}

	@Override
	public GpuSurfaceBackend createSurface(long windowHandle, BooleanSupplier isIconified) {
		return new D3D11GpuSurface(this.context, windowHandle, isIconified);
	}

	@Override
	public CommandEncoderBackend createCommandEncoder() {
		return new D3D11CommandEncoder(this.context);
	}

	@Override
	public GpuSampler createSampler(
		AddressMode addressModeU,
		AddressMode addressModeV,
		FilterMode minFilter,
		FilterMode magFilter,
		int maxAnisotropy,
		OptionalDouble maxLod
	) {
		return D3D11GpuSampler.create(this.context, addressModeU, addressModeV, minFilter, magFilter, maxAnisotropy, maxLod);
	}

	@Override
	public GpuTexture createTexture(
		@Nullable String label,
		int usage,
		GpuFormat format,
		int width,
		int height,
		int depthOrLayers,
		int mipLevels
	) {
		return D3D11GpuTexture.create(this.context, label, usage, format, width, height, depthOrLayers, mipLevels);
	}

	@Override
	public GpuTextureView createTextureView(GpuTexture texture, int baseMipLevel, int mipLevels) {
		return D3D11GpuTextureView.create(this.context, texture, baseMipLevel, mipLevels);
	}

	@Override
	public GpuBuffer createBuffer(@Nullable Supplier<String> label, int usage, long size) {
		return D3D11GpuBuffer.create(this.context, label == null ? null : label.get(), usage, size, null);
	}

	@Override
	public GpuBuffer createBuffer(@Nullable Supplier<String> label, int usage, ByteBuffer data) {
		return D3D11GpuBuffer.create(this.context, label == null ? null : label.get(), usage, data.remaining(), data);
	}

	@Override
	public List<String> getLastDebugMessages() {
		return List.of();
	}

	@Override
	public boolean isDebuggingEnabled() {
		return false;
	}

	@Override
	public BackendRenderPipeline.Pending compilePipeline(BackendRenderPipeline.CreateInfo pipelineCreateInfo) {
		D3D11Shader.Result vertexResult = null;
		D3D11Shader.Result pixelResult = null;
		try {
			for (BackendRenderPipeline.CreateInfo.Shader shader : pipelineCreateInfo.shaders()) {
				SpvModule module = shader.module();
				D3D11Shader.Result result = D3D11Shader.compile(this.context, module.type(), module, shader.entryPoint());
				if (module.type() == ShaderType.VERTEX) {
					if (vertexResult != null) D3D11Com.release(vertexResult.shader());
					vertexResult = result;
				} else if (module.type() == ShaderType.FRAGMENT) {
					if (pixelResult != null) D3D11Com.release(pixelResult.shader());
					pixelResult = result;
				} else {
					D3D11Com.release(result.shader());
					throw new UnsupportedOperationException("D3D11 currently supports vertex and fragment shaders only; got " + module.type());
				}
			}
			if (vertexResult == null || vertexResult.shader().address() == 0L || pixelResult == null || pixelResult.shader().address() == 0L) {
				throw new IllegalStateException("Pipeline '" + pipelineCreateInfo.name() + "' must contain both vertex and fragment shaders");
			}
			return new D3D11Pending(new D3D11RenderPipeline(this.context, vertexResult, pixelResult, pipelineCreateInfo));
		} catch (Throwable throwable) {
			if (vertexResult != null) D3D11Com.release(vertexResult.shader());
			if (pixelResult != null) D3D11Com.release(pixelResult.shader());
			DirectGraphix.LOGGER.warn("[DirectGraphix] Skipping unsupported pipeline '{}': {}", pipelineCreateInfo.name(), throwable.getMessage());
			return BackendRenderPipeline.Pending.NULL;
		}
	}

	@Override
	public void close() {
		this.context.close();
	}

	@Override
	public GpuQueryPool createTimestampQueryPool(int size) {
		return new D3D11QueryPool(size);
	}

	@Override
	public long getTimestampCalibrationOffset() {
		return 0L;
	}

	@Override
	public DeviceInfo getDeviceInfo() {
		return this.deviceInfo;
	}
}