package com.directx.client.d3d11;

import static java.lang.foreign.ValueLayout.ADDRESS;
import static java.lang.foreign.ValueLayout.JAVA_BYTE;
import static java.lang.foreign.ValueLayout.JAVA_FLOAT;
import static java.lang.foreign.ValueLayout.JAVA_INT;

import com.mojang.renderpearl.api.buffers.GpuBuffer;
import com.mojang.renderpearl.api.buffers.GpuBufferSlice;
import com.mojang.renderpearl.api.buffers.TransientMemory;
import com.mojang.renderpearl.api.commands.GpuFence;
import com.mojang.renderpearl.api.commands.GpuQueryPool;
import com.mojang.renderpearl.api.commands.RenderPassDescriptor;
import com.mojang.renderpearl.api.textures.GpuTexture;
import com.mojang.renderpearl.backend.api.CommandEncoderBackend;
import com.mojang.renderpearl.backend.api.RenderPassBackend;
import java.lang.foreign.Arena;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.MemorySegment;
import java.lang.invoke.MethodHandle;
import java.nio.ByteBuffer;
import org.joml.Vector4fc;

public class D3D11CommandEncoder implements CommandEncoderBackend {
	private static final int SHADOW_USAGE_MASK =
		GpuBuffer.USAGE_MAP_READ | GpuBuffer.USAGE_MAP_WRITE | GpuBuffer.USAGE_UNIFORM | GpuBuffer.USAGE_COPY_SRC;

	private static final int DEVICE_CREATE_TEXTURE2D = 5;
	private static final int DEVICE_CREATE_RTV = 9;
	private static final int DEVICE_CREATE_DSV = 10;
	private static final int CONTEXT_MAP = 14;
	private static final int CONTEXT_UNMAP = 15;
	private static final int CONTEXT_OM_SET_RENDER_TARGETS = 33;
	private static final int CONTEXT_COPY_SUBRESOURCE_REGION = 46;
	private static final int CONTEXT_CLEAR_RTV = 50;
	private static final int CONTEXT_CLEAR_DSV = 53;

	private final D3D11Context context;
	private final D3D11TransientMemory transientMemory;

	public D3D11CommandEncoder(D3D11Context context) {
		this.context = context;
		this.transientMemory = new D3D11TransientMemory(context);
	}

	@Override
	public void submit() {
	}

	@Override
	public TransientMemory transientMemory() {
		return this.transientMemory;
	}

	@Override
	public RenderPassBackend createRenderPass(RenderPassDescriptor descriptor) {
		return new D3D11RenderPass(this.context, descriptor);
	}

	@Override
	public void submitRenderPass() {
		try {
			MethodHandle setRenderTargets = D3D11Com.method(
				this.context.immediateContext,
				CONTEXT_OM_SET_RENDER_TARGETS,
				FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, ADDRESS, ADDRESS)
			);
			setRenderTargets.invokeExact(this.context.immediateContext, 0, MemorySegment.NULL, MemorySegment.NULL);
		} catch (Throwable throwable) {
			throw new IllegalStateException("D3D11 submitRenderPass failed", throwable);
		}
	}

	@Override
	public void clearColorTexture(GpuTexture colorTexture, Vector4fc clearColor) {
		D3D11GpuTexture texture = (D3D11GpuTexture) colorTexture;
		try (Arena arena = Arena.ofConfined()) {
			MemorySegment outRtv = arena.allocate(ADDRESS);
			MethodHandle createRtv = D3D11Com.method(
				this.context.device,
				DEVICE_CREATE_RTV,
				FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, ADDRESS, ADDRESS)
			);
			int hr = (int) createRtv.invokeExact(this.context.device, texture.resource(), MemorySegment.NULL, outRtv);
			if (hr >= 0) {
				MemorySegment rtv = outRtv.get(ADDRESS, 0);
				try {
					MemorySegment color = arena.allocate(16, 4);
					color.set(JAVA_FLOAT, 0, clearColor.x());
					color.set(JAVA_FLOAT, 4, clearColor.y());
					color.set(JAVA_FLOAT, 8, clearColor.z());
					color.set(JAVA_FLOAT, 12, clearColor.w());

					MethodHandle clear = D3D11Com.method(
						this.context.immediateContext,
						CONTEXT_CLEAR_RTV,
						FunctionDescriptor.ofVoid(ADDRESS, ADDRESS, ADDRESS)
					);
					clear.invokeExact(this.context.immediateContext, rtv, color);
				} finally {
					D3D11Com.release(rtv);
				}
			}
		} catch (Throwable throwable) {
			throw new IllegalStateException("D3D11 clearColorTexture failed", throwable);
		}
	}

	@Override
	public void clearColorAndDepthTextures(GpuTexture colorTexture, Vector4fc clearColor, GpuTexture depthTexture, double clearDepth) {
		this.clearColorTexture(colorTexture, clearColor);
		this.clearDepthTexture(depthTexture, clearDepth);
	}

	@Override
	public void clearColorAndDepthTextures(
		GpuTexture colorTexture,
		Vector4fc clearColor,
		GpuTexture depthTexture,
		double clearDepth,
		int regionX,
		int regionY,
		int regionWidth,
		int regionHeight,
		int mipLevel
	) {
		this.clearColorRegion(colorTexture, clearColor, regionX, regionY, regionWidth, regionHeight, mipLevel);
		this.clearDepthTexture(depthTexture, clearDepth);
	}

	private void clearColorRegion(GpuTexture colorTexture, Vector4fc clearColor, int x, int y, int width, int height, int mipLevel) {
		D3D11GpuTexture texture = (D3D11GpuTexture) colorTexture;
		int mipWidth = Math.max(1, texture.getWidth(mipLevel));
		int mipHeight = Math.max(1, texture.getHeight(mipLevel));
		int left = Math.max(0, x);
		int top = Math.max(0, y);
		int right = Math.min(mipWidth, x + width);
		int bottom = Math.min(mipHeight, y + height);
		if (right <= left || bottom <= top) {
			return;
		}
		boolean full = left == 0 && top == 0 && right == mipWidth && bottom == mipHeight;

		try (Arena arena = Arena.ofConfined()) {
			MemorySegment rtvDesc = MemorySegment.NULL;
			if (mipLevel > 0 && texture.getDepthOrLayers() <= 1) {
				rtvDesc = arena.allocate(20, 4);
				rtvDesc.set(JAVA_INT, 0, D3D11GpuTexture.dxgiFormat(texture.getFormat()));
				rtvDesc.set(JAVA_INT, 4, 4); // D3D11_RTV_DIMENSION_TEXTURE2D
				rtvDesc.set(JAVA_INT, 8, mipLevel);
			}

			MemorySegment outRtv = arena.allocate(ADDRESS);
			MethodHandle createRtv = D3D11Com.method(
				this.context.device,
				DEVICE_CREATE_RTV,
				FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, ADDRESS, ADDRESS)
			);
			int hr = (int) createRtv.invokeExact(this.context.device, texture.resource(), rtvDesc, outRtv);
			if (hr < 0) {
				return;
			}
			MemorySegment rtv = outRtv.get(ADDRESS, 0);
			try {
				if (full || !this.context.clearRenderTargetRegion(
					rtv, clearColor.x(), clearColor.y(), clearColor.z(), clearColor.w(), left, top, right - left, bottom - top
				)) {
					MemorySegment color = arena.allocate(16, 4);
					color.set(JAVA_FLOAT, 0, clearColor.x());
					color.set(JAVA_FLOAT, 4, clearColor.y());
					color.set(JAVA_FLOAT, 8, clearColor.z());
					color.set(JAVA_FLOAT, 12, clearColor.w());
					MethodHandle clear = D3D11Com.method(
						this.context.immediateContext,
						CONTEXT_CLEAR_RTV,
						FunctionDescriptor.ofVoid(ADDRESS, ADDRESS, ADDRESS)
					);
					clear.invokeExact(this.context.immediateContext, rtv, color);
				}
			} finally {
				D3D11Com.release(rtv);
			}
		} catch (Throwable throwable) {
			throw new IllegalStateException("D3D11 clearColorRegion failed", throwable);
		}
	}

	@Override
	public void clearDepthTexture(GpuTexture depthTexture, double clearDepth) {
		D3D11GpuTexture texture = (D3D11GpuTexture) depthTexture;
		try (Arena arena = Arena.ofConfined()) {
			MemorySegment dsvDesc = arena.allocate(20, 4);
			dsvDesc.set(JAVA_INT, 0, D3D11GpuTexture.dxgiFormat(texture.getFormat()));
			dsvDesc.set(JAVA_INT, 4, 3); // D3D11_DSV_DIMENSION_TEXTURE2D
			dsvDesc.set(JAVA_INT, 8, 0);
			dsvDesc.set(JAVA_INT, 12, 0);

			MemorySegment outDsv = arena.allocate(ADDRESS);
			MethodHandle createDsv = D3D11Com.method(
				this.context.device,
				DEVICE_CREATE_DSV,
				FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, ADDRESS, ADDRESS)
			);
			int hr = (int) createDsv.invokeExact(this.context.device, texture.resource(), dsvDesc, outDsv);
			D3D11Com.checkHr(hr, "CreateDepthStencilView");
			MemorySegment dsv = outDsv.get(ADDRESS, 0);
			try {
				MethodHandle clear = D3D11Com.method(
					this.context.immediateContext,
					CONTEXT_CLEAR_DSV,
					FunctionDescriptor.ofVoid(ADDRESS, ADDRESS, JAVA_INT, JAVA_FLOAT, JAVA_INT)
				);
				clear.invokeExact(this.context.immediateContext, dsv, 0x1, (float) clearDepth, 0);
			} finally {
				D3D11Com.release(dsv);
			}
		} catch (Throwable throwable) {
			throw new IllegalStateException("D3D11 clearDepthTexture failed", throwable);
		}
	}

	@Override
	public void writeToBuffer(GpuBufferSlice slice, ByteBuffer data) {
		D3D11GpuBuffer buffer = (D3D11GpuBuffer) slice.buffer();
		buffer.writeData(slice.offset(), data);
	}

	@Override
	public void copyToBuffer(GpuBufferSlice source, GpuBufferSlice target) {
		D3D11GpuBuffer sourceBuffer = (D3D11GpuBuffer) source.buffer();
		D3D11GpuBuffer targetBuffer = (D3D11GpuBuffer) target.buffer();
		sourceBuffer.flush();
		targetBuffer.flush();

		long length = Math.min(source.length(), target.length());
		if (length <= 0L) {
			return;
		}

		try (Arena arena = Arena.ofConfined()) {
			MemorySegment box = arena.allocate(24, 4);
			box.set(JAVA_INT, 0, (int) source.offset());
			box.set(JAVA_INT, 4, 0);
			box.set(JAVA_INT, 8, 0);
			box.set(JAVA_INT, 12, (int) (source.offset() + length));
			box.set(JAVA_INT, 16, 1);
			box.set(JAVA_INT, 20, 1);

			MethodHandle copy = D3D11Com.method(
				this.context.immediateContext,
				CONTEXT_COPY_SUBRESOURCE_REGION,
				FunctionDescriptor.ofVoid(ADDRESS, ADDRESS, JAVA_INT, JAVA_INT, JAVA_INT, JAVA_INT, ADDRESS, JAVA_INT, ADDRESS)
			);
			copy.invokeExact(
				this.context.immediateContext,
				targetBuffer.resource(), 0, (int) target.offset(), 0, 0,
				sourceBuffer.resource(), 0, box
			);

			if ((sourceBuffer.usage() & SHADOW_USAGE_MASK) != 0 && (targetBuffer.usage() & SHADOW_USAGE_MASK) != 0) {
				ByteBuffer srcView = sourceBuffer.shadowRange(source.offset(), Math.toIntExact(length));
				ByteBuffer dstView = targetBuffer.shadowRange(target.offset(), Math.toIntExact(length));
				dstView.put(srcView);
			}
		} catch (Throwable throwable) {
			throw new IllegalStateException("D3D11 copyToBuffer failed", throwable);
		}
	}

	@Override
	public void writeToTexture(
		GpuTexture destination,
		ByteBuffer source,
		int mipLevel,
		int depthOrLayer,
		int destX,
		int destY,
		int width,
		int height
	) {
		if (width <= 0 || height <= 0) {
			return;
		}
		D3D11GpuTexture texture = (D3D11GpuTexture) destination;
		int subresource = texture.subresourceIndex(mipLevel, depthOrLayer);
		boolean expandRgb = D3D11GpuTexture.isRgb8(texture.getFormat());
		int srcBytesPerPixel = texture.getFormat().blockSize();
		int srcRowPitch = width * srcBytesPerPixel;
		int uploadRowPitch = expandRgb ? (width * 4) : srcRowPitch;

		try (Arena arena = Arena.ofConfined()) {
			MemorySegment box = arena.allocate(24, 4);
			box.set(JAVA_INT, 0, destX);
			box.set(JAVA_INT, 4, destY);
			box.set(JAVA_INT, 8, 0);
			box.set(JAVA_INT, 12, destX + width);
			box.set(JAVA_INT, 16, destY + height);
			box.set(JAVA_INT, 20, 1);

			ByteBuffer dup = source.duplicate();
			MemorySegment srcSegment;
			if (expandRgb) {
				srcSegment = expandRgbRowsToRgba(arena, dup, width, width, height);
			} else if (dup.isDirect()) {
				// MemorySegment.ofBuffer(dup) ByteBuffer.position() ofsetini otomatik baz alir
				srcSegment = MemorySegment.ofBuffer(dup);
			} else {
				byte[] arr = new byte[dup.remaining()];
				dup.get(arr);
				MemorySegment buf = arena.allocate(arr.length, 4);
				MemorySegment.copy(arr, 0, buf, JAVA_BYTE, 0, arr.length);
				srcSegment = buf;
			}

			this.context.updateSubresource(texture.resource(), subresource, box, srcSegment, uploadRowPitch, 0);
		} catch (Throwable throwable) {
			throw new IllegalStateException("D3D11 writeToTexture failed", throwable);
		}
	}

	@Override
	public void copyBufferToTexture(
		GpuBufferSlice source,
		int sourceX,
		int sourceY,
		int sourceWidth,
		int sourceHeight,
		GpuTexture destination,
		int destinationX,
		int destinationY,
		int copyWidth,
		int copyHeight,
		int mipLevel,
		int arrayLayer
	) {
		if (copyWidth <= 0 || copyHeight <= 0) {
			return;
		}

		D3D11GpuBuffer sourceBuffer = (D3D11GpuBuffer) source.buffer();
		D3D11GpuTexture destinationTexture = (D3D11GpuTexture) destination;

		boolean expandRgb = D3D11GpuTexture.isRgb8(destinationTexture.getFormat());
		int bytesPerPixel = destinationTexture.getFormat().blockSize();
		long sourceRowPitch = Math.multiplyExact((long) sourceWidth, bytesPerPixel);
		long sourceByteOffset = Math.multiplyExact(
			Math.addExact(Math.multiplyExact((long) sourceY, sourceWidth), sourceX),
			bytesPerPixel
		);

		long requiredBytes = Math.multiplyExact((long) (copyHeight - 1), sourceRowPitch)
			+ Math.multiplyExact((long) copyWidth, bytesPerPixel);

		ByteBuffer sourceBytes = sourceBuffer.shadowRange(
			source.offset() + sourceByteOffset,
			Math.toIntExact(Math.min(source.length() - sourceByteOffset, requiredBytes))
		);
		int subresource = destinationTexture.subresourceIndex(mipLevel, arrayLayer);

		try (Arena arena = Arena.ofConfined()) {
			MemorySegment box = arena.allocate(24, 4);
			box.set(JAVA_INT, 0, destinationX);
			box.set(JAVA_INT, 4, destinationY);
			box.set(JAVA_INT, 8, 0);
			box.set(JAVA_INT, 12, destinationX + copyWidth);
			box.set(JAVA_INT, 16, destinationY + copyHeight);
			box.set(JAVA_INT, 20, 1);

			MemorySegment sourceSegment;
			int uploadRowPitch;
			if (expandRgb) {
				sourceSegment = expandRgbRowsToRgba(arena, sourceBytes, sourceWidth, copyWidth, copyHeight);
				uploadRowPitch = copyWidth * 4;
			} else if (sourceBytes.isDirect()) {
				sourceSegment = MemorySegment.ofBuffer(sourceBytes);
				uploadRowPitch = Math.toIntExact(sourceRowPitch);
			} else {
				ByteBuffer dup = sourceBytes.duplicate();
				byte[] arr = new byte[dup.remaining()];
				dup.get(arr);
				MemorySegment buf = arena.allocate(arr.length, 4);
				MemorySegment.copy(arr, 0, buf, JAVA_BYTE, 0, arr.length);
				sourceSegment = buf;
				uploadRowPitch = Math.toIntExact(sourceRowPitch);
			}

			this.context.updateSubresource(
				destinationTexture.resource(),
				subresource,
				box,
				sourceSegment,
				uploadRowPitch,
				0
			);
		} catch (Throwable throwable) {
			throw new IllegalStateException("D3D11 copyBufferToTexture failed", throwable);
		}
	}

	private static MemorySegment expandRgbRowsToRgba(Arena arena, ByteBuffer src, int srcRowPixels, int copyWidth, int copyHeight) {
		int basePos = src.position();
		int srcRowBytes = srcRowPixels * 3;
		int dstRowBytes = copyWidth * 4;
		MemorySegment dst = arena.allocate((long) dstRowBytes * copyHeight, 4);
		for (int y = 0; y < copyHeight; y++) {
			int srcRowStart = basePos + y * srcRowBytes;
			long dstRowStart = (long) y * dstRowBytes;
			for (int x = 0; x < copyWidth; x++) {
				int s = srcRowStart + x * 3;
				long d = dstRowStart + (long) x * 4L;
				dst.set(JAVA_BYTE, d + 0, src.get(s + 0));
				dst.set(JAVA_BYTE, d + 1, src.get(s + 1));
				dst.set(JAVA_BYTE, d + 2, src.get(s + 2));
				dst.set(JAVA_BYTE, d + 3, (byte) 0xFF);
			}
		}
		return dst;
	}

	@Override
	public void copyTextureToBuffer(GpuTexture source, GpuBuffer destination, long offset, Runnable callback, int mipLevel) {
		int width = Math.max(1, source.getWidth(mipLevel));
		int height = Math.max(1, source.getHeight(mipLevel));
		copyTextureToBuffer(source, destination, offset, callback, mipLevel, 0, 0, width, height);
	}

	@Override
	public void copyTextureToBuffer(
		GpuTexture source,
		GpuBuffer destination,
		long offset,
		Runnable callback,
		int mipLevel,
		int x,
		int y,
		int width,
		int height
	) {
		D3D11GpuTexture srcTex = (D3D11GpuTexture) source;
		D3D11GpuBuffer dstBuf = (D3D11GpuBuffer) destination;
		int bytesPerPixel = D3D11GpuTexture.storageBytesPerPixel(srcTex.getFormat());

		if (width > 0 && height > 0 && bytesPerPixel > 0 && srcTex.resource().address() != 0L) {
			try (Arena arena = Arena.ofConfined()) {
				// D3D11_TEXTURE2D_DESC: D3D11_USAGE_STAGING (3), CPU_ACCESS_READ (0x20000)
				MemorySegment desc = arena.allocate(44, 4);
				desc.set(JAVA_INT, 0, width);
				desc.set(JAVA_INT, 4, height);
				desc.set(JAVA_INT, 8, 1);
				desc.set(JAVA_INT, 12, 1);
				desc.set(JAVA_INT, 16, srcTex.nativeDxgiFormat());
				desc.set(JAVA_INT, 20, 1);
				desc.set(JAVA_INT, 24, 0);
				desc.set(JAVA_INT, 28, 3);       // D3D11_USAGE_STAGING
				desc.set(JAVA_INT, 32, 0);       // BindFlags = 0
				desc.set(JAVA_INT, 36, 0x20000); // D3D11_CPU_ACCESS_READ
				desc.set(JAVA_INT, 40, 0);

				MemorySegment outStaging = arena.allocate(ADDRESS);
				MethodHandle createTex = D3D11Com.method(
					this.context.device,
					DEVICE_CREATE_TEXTURE2D,
					FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, ADDRESS, ADDRESS)
				);
				int hr = (int) createTex.invokeExact(this.context.device, desc, MemorySegment.NULL, outStaging);
				D3D11Com.checkHr(hr, "CreateStagingTextureForReadback");
				MemorySegment staging = outStaging.get(ADDRESS, 0);

				try {
					MemorySegment box = arena.allocate(24, 4);
					box.set(JAVA_INT, 0, x);
					box.set(JAVA_INT, 4, y);
					box.set(JAVA_INT, 8, 0);
					box.set(JAVA_INT, 12, x + width);
					box.set(JAVA_INT, 16, y + height);
					box.set(JAVA_INT, 20, 1);

					MethodHandle copy = D3D11Com.method(
						this.context.immediateContext,
						CONTEXT_COPY_SUBRESOURCE_REGION,
						FunctionDescriptor.ofVoid(ADDRESS, ADDRESS, JAVA_INT, JAVA_INT, JAVA_INT, JAVA_INT, ADDRESS, JAVA_INT, ADDRESS)
					);
					copy.invokeExact(this.context.immediateContext, staging, 0, 0, 0, 0, srcTex.resource(), mipLevel, box);

					// D3D11_MAPPED_SUBRESOURCE (16 bayt: pData, RowPitch, DepthPitch)
					MemorySegment mapped = arena.allocate(16, 8);
					MethodHandle map = D3D11Com.method(
						this.context.immediateContext,
						CONTEXT_MAP,
						FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, JAVA_INT, JAVA_INT, JAVA_INT, ADDRESS)
					);
					hr = (int) map.invokeExact(this.context.immediateContext, staging, 0, 1, 0, mapped); // D3D11_MAP_READ = 1
					D3D11Com.checkHr(hr, "MapStagingTexture");
					try {
						MemorySegment pData = mapped.get(ADDRESS, 0);
						int rowPitch = mapped.get(JAVA_INT, 8);
						int dstRowBytes = width * bytesPerPixel;
						long mappedBytes = (long) rowPitch * height;
						MemorySegment srcMem = pData.reinterpret(mappedBytes);

						ByteBuffer dstView = dstBuf.shadowRange(offset, dstRowBytes * height);
						MemorySegment dstMem = MemorySegment.ofBuffer(dstView);
						for (int row = 0; row < height; row++) {
							MemorySegment.copy(srcMem, (long) row * rowPitch, dstMem, (long) row * dstRowBytes, dstRowBytes);
						}
					} finally {
						MethodHandle unmap = D3D11Com.method(
							this.context.immediateContext,
							CONTEXT_UNMAP,
							FunctionDescriptor.ofVoid(ADDRESS, ADDRESS, JAVA_INT)
						);
						unmap.invokeExact(this.context.immediateContext, staging, 0);
					}
				} finally {
					D3D11Com.release(staging);
				}
			} catch (Throwable throwable) {
				throw new IllegalStateException("D3D11 copyTextureToBuffer failed", throwable);
			}
		}

		if (callback != null) {
			callback.run();
		}
	}

	@Override
	public void copyTextureToTexture(GpuTexture source, GpuTexture destination, int mipLevel, int destX, int destY, int sourceX, int sourceY, int width, int height) {
		if (width <= 0 || height <= 0) {
			return;
		}

		D3D11GpuTexture src = (D3D11GpuTexture) source;
		D3D11GpuTexture dst = (D3D11GpuTexture) destination;
		try (Arena arena = Arena.ofConfined()) {
			MemorySegment box = arena.allocate(24, 4);
			box.set(JAVA_INT, 0, sourceX);
			box.set(JAVA_INT, 4, sourceY);
			box.set(JAVA_INT, 8, 0);
			box.set(JAVA_INT, 12, sourceX + width);
			box.set(JAVA_INT, 16, sourceY + height);
			box.set(JAVA_INT, 20, 1);

			MethodHandle copy = D3D11Com.method(
				this.context.immediateContext,
				CONTEXT_COPY_SUBRESOURCE_REGION,
				FunctionDescriptor.ofVoid(ADDRESS, ADDRESS, JAVA_INT, JAVA_INT, JAVA_INT, JAVA_INT, ADDRESS, JAVA_INT, ADDRESS)
			);

			if (src.resource().address() == dst.resource().address()) {
				MemorySegment desc = arena.allocate(44, 4);
				desc.set(JAVA_INT, 0, width);
				desc.set(JAVA_INT, 4, height);
				desc.set(JAVA_INT, 8, 1);
				desc.set(JAVA_INT, 12, 1);
				desc.set(JAVA_INT, 16, src.nativeDxgiFormat());
				desc.set(JAVA_INT, 20, 1);
				desc.set(JAVA_INT, 24, 0);
				desc.set(JAVA_INT, 28, 0);
				desc.set(JAVA_INT, 32, D3D11GpuTexture.D3D11_BIND_SHADER_RESOURCE);
				desc.set(JAVA_INT, 36, 0);
				desc.set(JAVA_INT, 40, 0);

				MemorySegment outTemp = arena.allocate(ADDRESS);
				MethodHandle createTex = D3D11Com.method(
					this.context.device,
					DEVICE_CREATE_TEXTURE2D,
					FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, ADDRESS, ADDRESS)
				);
				int hr = (int) createTex.invokeExact(this.context.device, desc, MemorySegment.NULL, outTemp);
				D3D11Com.checkHr(hr, "CreateTempTextureForSelfCopy");
				MemorySegment temp = outTemp.get(ADDRESS, 0);
				try {
					copy.invokeExact(this.context.immediateContext, temp, 0, 0, 0, 0, src.resource(), mipLevel, box);
					MemorySegment tempBox = arena.allocate(24, 4);
					tempBox.set(JAVA_INT, 0, 0);
					tempBox.set(JAVA_INT, 4, 0);
					tempBox.set(JAVA_INT, 8, 0);
					tempBox.set(JAVA_INT, 12, width);
					tempBox.set(JAVA_INT, 16, height);
					tempBox.set(JAVA_INT, 20, 1);
					copy.invokeExact(this.context.immediateContext, dst.resource(), mipLevel, destX, destY, 0, temp, 0, tempBox);
				} finally {
					D3D11Com.release(temp);
				}
			} else {
				copy.invokeExact(this.context.immediateContext, dst.resource(), mipLevel, destX, destY, 0, src.resource(), mipLevel, box);
			}
		} catch (Throwable throwable) {
			throw new IllegalStateException("D3D11 copyTextureToTexture failed", throwable);
		}
	}

	@Override
	public GpuFence createFence() {
		return new D3D11Fence();
	}

	@Override
	public void writeTimestamp(GpuQueryPool pool, int index) {
	}
}