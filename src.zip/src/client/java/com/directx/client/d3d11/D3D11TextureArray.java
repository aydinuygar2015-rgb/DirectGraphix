package com.directx.client.d3d11;

/**
 * D3D11 doku sistemi dogrudan native Texture2D, Texture2DArray ve TextureCube kaynaklarini kullanir.
 */
public final class D3D11TextureArray {
	private D3D11TextureArray() {
	}
}