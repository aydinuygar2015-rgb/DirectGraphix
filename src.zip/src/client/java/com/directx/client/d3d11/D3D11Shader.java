package com.directx.client.d3d11;

import static java.lang.foreign.ValueLayout.ADDRESS;
import static java.lang.foreign.ValueLayout.JAVA_BYTE;
import static java.lang.foreign.ValueLayout.JAVA_INT;
import static java.lang.foreign.ValueLayout.JAVA_LONG;

import com.directx.DirectGraphix;
import com.mojang.renderpearl.api.pipeline.ShaderType;
import com.mojang.renderpearl.backend.api.SpvModule;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.foreign.Arena;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.Linker;
import java.lang.foreign.MemorySegment;
import java.lang.foreign.SymbolLookup;
import java.lang.invoke.MethodHandle;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class D3D11Shader {
	private static final Pattern CBUFFER_PATTERN = Pattern.compile("cbuffer\\s+([\\w$]+)\\s*:\\s*register\\(b(\\d+)\\)");
	private static final Pattern TEXTURE_PATTERN = Pattern.compile("(?:Texture\\w+|Buffer)(?:<[^>]+>)?\\s+(\\w+)\\s*:\\s*register\\(t(\\d+)\\)");
	private static final Pattern SAMPLER_PATTERN = Pattern.compile("Sampler(?:Comparison)?State\\s+(\\w+)\\s*:\\s*register\\(s(\\d+)\\)");
	private static final AtomicBoolean LOGGED_TEXTURE_HLSL = new AtomicBoolean();

	public record Result(
		MemorySegment shader,
		MemorySegment bytecode,
		long bytecodeSize,
		Map<String, Integer> cbufferRegisters,
		Map<String, Integer> textureRegisters,
		Map<String, Integer> samplerRegisters,
		Set<Integer> pushConstantRegisters
	) {
		public Result(
			MemorySegment shader,
			MemorySegment bytecode,
			long bytecodeSize,
			Map<String, Integer> cbufferRegisters,
			Map<String, Integer> textureRegisters,
			Map<String, Integer> samplerRegisters
		) {
			this(shader, bytecode, bytecodeSize, cbufferRegisters, textureRegisters, samplerRegisters, Set.of());
		}
	}

	private static Path spirvCrossPath;

	public static synchronized Path getSpirvCross() {
		if (spirvCrossPath != null && Files.exists(spirvCrossPath)) {
			return spirvCrossPath;
		}
		try {
			Path temp = Paths.get(System.getProperty("java.io.tmpdir"), "directgraphix-spirv-cross.exe");
			if (!Files.exists(temp)) {
				try (InputStream in = D3D11Shader.class.getResourceAsStream("/assets/direct-graphix/native/spirv-cross.exe")) {
					if (in == null) {
						throw new IllegalStateException("spirv-cross.exe not found in jar resources");
					}
					Files.copy(in, temp, StandardCopyOption.REPLACE_EXISTING);
				}
				temp.toFile().setExecutable(true);
			}
			spirvCrossPath = temp;
			DirectGraphix.LOGGER.info("[DirectGraphix] Extracted spirv-cross to {}", temp);
			return temp;
		} catch (Throwable throwable) {
			throw new IllegalStateException("Failed to extract spirv-cross", throwable);
		}
	}

	public static Result compile(D3D11Context context, ShaderType type, SpvModule module, String entryPoint) {
		String stage = (type == ShaderType.VERTEX) ? "vert" : "frag";
		String target = (type == ShaderType.VERTEX) ? "vs_5_0" : "ps_5_0";
		Path spvPath = null;
		Path hlslPath = null;
		try {
			byte[] spvBytes = stripUnsupportedSpvBuiltins(toBytes(module.spv()));

			Map<String, Integer> cbuffers = new HashMap<>();
			Map<String, Integer> textures = new HashMap<>();
			Map<String, Integer> samplers = new HashMap<>();
			Set<Integer> pushConstantRegisters = new HashSet<>();
			parseSpvMetadata(spvBytes, cbuffers, textures, samplers, pushConstantRegisters);

			spvPath = Files.createTempFile("dg", ".spv");
			Files.write(spvPath, spvBytes);
			hlslPath = Files.createTempFile("dg", ".hlsl");

			Path exe = getSpirvCross();
			List<String> cmd = Arrays.asList(
				exe.toString(),
				spvPath.toString(),
				"--hlsl",
				"--shader-model", "50",
				"--entry", entryPoint,
				"--stage", stage,
				"--output", hlslPath.toString()
			);
			ProcessBuilder pb = new ProcessBuilder(cmd);
			pb.redirectErrorStream(true);
			Process process = pb.start();
			StringBuilder out = new StringBuilder();
			try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
				String line;
				while ((line = reader.readLine()) != null) {
					out.append(line).append("\n");
				}
			}
			int exit = process.waitFor();
			if (exit != 0) {
				DirectGraphix.LOGGER.error("[DirectGraphix] spirv-cross output:\n{}", out);
				D3D11DebugLog.error("SHADER", "spirv-cross exit=" + exit + "\n" + out, null);
				throw new IllegalStateException("spirv-cross failed with exit code " + exit + ": " + out);
			}
			String hlsl = Files.readString(hlslPath);
			hlsl = hlsl.replaceAll("(?m)^.*_RESERVED_IDENTIFIER_FIXUP_gl_PointSize.*$\\r?\\n?", "");
			if (type == ShaderType.FRAGMENT) {
				hlsl = hlsl.replaceAll(":\\s*COLOR(\\d+)", ": SV_Target$1");
			}
			if (type == ShaderType.VERTEX) {
				hlsl = flipVertexOutputY(hlsl);
			}

			parseRegisters(hlsl, cbuffers, textures, samplers, pushConstantRegisters);

			if (type == ShaderType.FRAGMENT && !textures.isEmpty() && LOGGED_TEXTURE_HLSL.compareAndSet(false, true)) {
				DirectGraphix.LOGGER.info(
					"[DirectGraphix] Sample textured PS registers: cb={}, tex={}, samp={}\n{}",
					cbuffers,
					textures,
					samplers,
					hlsl.substring(0, Math.min(hlsl.length(), 1500))
				);
			}

			D3D11DebugLog.shader(stage, entryPoint, cbuffers, textures, samplers, hlsl);
			return compileHlsl(context, type, hlsl, entryPoint, target, cbuffers, textures, samplers, pushConstantRegisters);
		} catch (Throwable throwable) {
			DirectGraphix.LOGGER.error("[DirectGraphix] D3D11Shader.compile failed for {}", type, throwable);
			throw new IllegalStateException("D3D11Shader.compile failed", throwable);
		} finally {
			if (spvPath != null) {
				try { Files.deleteIfExists(spvPath); } catch (Throwable ignored) {}
			}
			if (hlslPath != null) {
				try { Files.deleteIfExists(hlslPath); } catch (Throwable ignored) {}
			}
		}
	}

	private static final Pattern GL_POSITION_OUT_PATTERN = Pattern.compile("(stage_output\\.gl_Position\\s*=\\s*[^;]+;)");
	private static final AtomicBoolean WARNED_NO_FLIP = new AtomicBoolean();

	private static String flipVertexOutputY(String hlsl) {
		Matcher matcher = GL_POSITION_OUT_PATTERN.matcher(hlsl);
		if (matcher.find()) {
			return matcher.replaceAll("$1\n    stage_output.gl_Position.y = -stage_output.gl_Position.y;");
		}
		if (WARNED_NO_FLIP.compareAndSet(false, true)) {
			DirectGraphix.LOGGER.warn("[DirectGraphix] Vertex shader Y-flip pattern not found in HLSL; some shaders may render upside down");
		}
		return hlsl;
	}

	public static Result compileRaw(D3D11Context context, ShaderType type, String hlsl, String entryPoint) {
		String target = (type == ShaderType.VERTEX) ? "vs_5_0" : "ps_5_0";
		return compileHlsl(context, type, hlsl, entryPoint, target, new HashMap<>(), new HashMap<>(), new HashMap<>(), Set.of());
	}

	/** SPIR-V ikili dosyasindan dogrudan degisken isimlerini ve Binding yuvalarini okur. */
	private static void parseSpvMetadata(
		byte[] spv,
		Map<String, Integer> cbuffers,
		Map<String, Integer> textures,
		Map<String, Integer> samplers,
		Set<Integer> pushConstantRegisters
	) {
		if (spv.length < 20 || (spv.length & 3) != 0 || readWord(spv, 0) != 0x07230203) {
			return;
		}
		int totalWords = spv.length >>> 2;
		Map<Integer, String> names = new HashMap<>();
		Map<Integer, Integer> bindings = new HashMap<>();
		Map<Integer, Integer> storageClasses = new HashMap<>();

		int pos = 5;
		while (pos < totalWords) {
			int first = readWord(spv, pos);
			int wordCount = first >>> 16;
			int opcode = first & 0xFFFF;
			if (wordCount <= 0 || pos + wordCount > totalWords) {
				break;
			}
			if (opcode == 5 && wordCount >= 3) { // OpName
				int targetId = readWord(spv, pos + 1);
				String name = readSpvString(spv, pos + 2, pos + wordCount);
				if (!name.isEmpty()) {
					names.put(targetId, name);
				}
			} else if (opcode == 71 && wordCount >= 4) { // OpDecorate
				int targetId = readWord(spv, pos + 1);
				int decoration = readWord(spv, pos + 2);
				if (decoration == 33) { // Binding
					bindings.put(targetId, readWord(spv, pos + 3));
				}
			} else if (opcode == 59 && wordCount >= 4) { // OpVariable
				int resultId = readWord(spv, pos + 2);
				int storageClass = readWord(spv, pos + 3);
				storageClasses.put(resultId, storageClass);
			}
			pos += wordCount;
		}

		for (Map.Entry<Integer, Integer> entry : storageClasses.entrySet()) {
			int id = entry.getKey();
			int sc = entry.getValue();
			Integer binding = bindings.get(id);
			String name = names.get(id);

			if (sc == 9) { // PushConstant
				if (binding != null) {
					pushConstantRegisters.add(binding);
				}
				continue;
			}
			if (binding == null || name == null || name.isEmpty()) {
				continue;
			}
			if (sc == 2) { // Uniform (UBO)
				cbuffers.put(name, binding);
			} else if (sc == 0) { // UniformConstant (Texture / Sampler)
				textures.put(name, binding);
				samplers.put(name, binding);
			}
		}
	}

	private static String readSpvString(byte[] spv, int startWord, int endWord) {
		int startByte = startWord << 2;
		int maxByte = endWord << 2;
		int len = 0;
		while (startByte + len < maxByte && spv[startByte + len] != 0) {
			len++;
		}
		return new String(spv, startByte, len, StandardCharsets.UTF_8);
	}

	private static byte[] stripUnsupportedSpvBuiltins(byte[] spv) {
		if (spv.length < 20 || (spv.length & 3) != 0) {
			return spv;
		}
		if (readWord(spv, 0) != 0x07230203) {
			return spv;
		}
		int totalWords = spv.length >>> 2;
		int pos = 5;
		while (pos < totalWords) {
			int first = readWord(spv, pos);
			int wordCount = first >>> 16;
			int opcode = first & 0xFFFF;
			if (wordCount <= 0 || pos + wordCount > totalWords) {
				break;
			}
			if (opcode == 71 && wordCount == 4) {
				if (readWord(spv, pos + 2) == 11 && readWord(spv, pos + 3) == 1) {
					for (int i = 0; i < 4; i++) {
						writeWord(spv, pos + i, 0x00010000);
					}
				}
			} else if (opcode == 72 && wordCount == 5) {
				if (readWord(spv, pos + 3) == 11 && readWord(spv, pos + 4) == 1) {
					for (int i = 0; i < 5; i++) {
						writeWord(spv, pos + i, 0x00010000);
					}
				}
			}
			pos += wordCount;
		}
		return spv;
	}

	private static int readWord(byte[] b, int wordIndex) {
		int i = wordIndex << 2;
		return (b[i] & 0xFF)
			| ((b[i + 1] & 0xFF) << 8)
			| ((b[i + 2] & 0xFF) << 16)
			| ((b[i + 3] & 0xFF) << 24);
	}

	private static void writeWord(byte[] b, int wordIndex, int val) {
		int i = wordIndex << 2;
		b[i] = (byte) val;
		b[i + 1] = (byte) (val >>> 8);
		b[i + 2] = (byte) (val >>> 16);
		b[i + 3] = (byte) (val >>> 24);
	}

	private static void parseRegisters(
		String hlsl,
		Map<String, Integer> cbuffers,
		Map<String, Integer> textures,
		Map<String, Integer> samplers,
		Set<Integer> pushConstantRegisters
	) {
		Matcher mCb = CBUFFER_PATTERN.matcher(hlsl);
		while (mCb.find()) {
			String raw = mCb.group(1);
			int reg = Integer.parseInt(mCb.group(2));
			cbuffers.putIfAbsent(raw, reg);
			if (raw.toLowerCase(Locale.ROOT).contains("push")) {
				pushConstantRegisters.add(reg);
			}
		}
		Matcher mTex = TEXTURE_PATTERN.matcher(hlsl);
		while (mTex.find()) {
			String raw = mTex.group(1);
			int reg = Integer.parseInt(mTex.group(2));
			textures.putIfAbsent(raw, reg);
		}
		Matcher mSamp = SAMPLER_PATTERN.matcher(hlsl);
		while (mSamp.find()) {
			String raw = mSamp.group(1);
			int reg = Integer.parseInt(mSamp.group(2));
			samplers.putIfAbsent(raw, reg);
			if (raw.startsWith("_") && raw.endsWith("_sampler")) {
				samplers.putIfAbsent(raw.substring(1, raw.length() - "_sampler".length()), reg);
			}
		}
	}

	private static byte[] toBytes(java.nio.ByteBuffer buffer) {
		java.nio.ByteBuffer dup = buffer.duplicate();
		byte[] bytes = new byte[dup.remaining()];
		dup.get(bytes);
		return bytes;
	}

	private static Result compileHlsl(
		D3D11Context context,
		ShaderType type,
		String hlsl,
		String entryPoint,
		String target,
		Map<String, Integer> cbuffers,
		Map<String, Integer> textures,
		Map<String, Integer> samplers,
		Set<Integer> pushConstantRegisters
	) {
		try (Arena arena = Arena.ofConfined()) {
			byte[] srcBytes = hlsl.getBytes(StandardCharsets.UTF_8);
			MemorySegment src = arena.allocate(srcBytes.length + 1, 1);
			MemorySegment.copy(srcBytes, 0, src, JAVA_BYTE, 0, srcBytes.length);
			src.set(JAVA_BYTE, srcBytes.length, (byte) 0);

			MemorySegment entryPtr = arena.allocateFrom(entryPoint, StandardCharsets.UTF_8);
			MemorySegment targetPtr = arena.allocateFrom(target, StandardCharsets.UTF_8);

			MemorySegment outBlob = arena.allocate(ADDRESS);
			MemorySegment outErrors = arena.allocate(ADDRESS);

			SymbolLookup compiler = SymbolLookup.libraryLookup("d3dcompiler_47.dll", Arena.global());
			MethodHandle d3dCompile = Linker.nativeLinker().downcallHandle(
				compiler.find("D3DCompile").orElseThrow(),
				FunctionDescriptor.of(JAVA_INT, ADDRESS, JAVA_LONG, ADDRESS, ADDRESS, ADDRESS, ADDRESS, ADDRESS, JAVA_INT, JAVA_INT, ADDRESS, ADDRESS)
			);

			int hr = (int) d3dCompile.invokeExact(
				src, (long) srcBytes.length, MemorySegment.NULL,
				MemorySegment.NULL, MemorySegment.NULL,
				entryPtr, targetPtr,
				0x00001000, 0,
				outBlob, outErrors
			);
			if (hr < 0) {
				MemorySegment errors = outErrors.get(ADDRESS, 0).reinterpret(8);
				String msg = "D3DCompile failed HRESULT=0x" + Integer.toHexString(hr);
				if (errors.address() != 0L) {
					try {
						long esize = getBlobSize(errors);
						MemorySegment eptr = getBlobPointer(errors).reinterpret(esize);
						byte[] ebytes = eptr.toArray(JAVA_BYTE);
						msg += "\n" + new String(ebytes, StandardCharsets.UTF_8);
					} catch (Throwable ignored) {}
					D3D11Com.release(errors);
				}
				DirectGraphix.LOGGER.error("[DirectGraphix] D3DCompile failed: {}\nHLSL:\n{}", msg, hlsl);
				D3D11DebugLog.error("SHADER", msg + "\nHLSL:\n" + hlsl, null);
				throw new IllegalStateException(msg);
			}
			MemorySegment blob = outBlob.get(ADDRESS, 0).reinterpret(8);
			long size = getBlobSize(blob);
			MemorySegment ptr = getBlobPointer(blob).reinterpret(size);

			MemorySegment bytecode = Arena.global().allocate(size, 1);
			MemorySegment.copy(ptr, 0, bytecode, 0, size);

			MemorySegment outShader = arena.allocate(ADDRESS);
			if (type == ShaderType.VERTEX) {
				MethodHandle handle = D3D11Com.method(
					context.device,
					12,
					FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, JAVA_LONG, ADDRESS, ADDRESS)
				);
				hr = (int) handle.invokeExact(context.device, bytecode, size, MemorySegment.NULL, outShader);
				D3D11Com.checkHr(hr, "CreateVertexShader");
			} else {
				MethodHandle handle = D3D11Com.method(
					context.device,
					15,
					FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, JAVA_LONG, ADDRESS, ADDRESS)
				);
				hr = (int) handle.invokeExact(context.device, bytecode, size, MemorySegment.NULL, outShader);
				D3D11Com.checkHr(hr, "CreatePixelShader");
			}
			MemorySegment shader = outShader.get(ADDRESS, 0).reinterpret(8);
			D3D11Com.release(blob);
			return new Result(shader, bytecode, size, cbuffers, textures, samplers, pushConstantRegisters);
		} catch (Throwable throwable) {
			throw new IllegalStateException("compileHlsl failed", throwable);
		}
	}

	private static long getBlobSize(MemorySegment blob) {
		try {
			MethodHandle handle = D3D11Com.method(blob, 4, FunctionDescriptor.of(JAVA_LONG, ADDRESS));
			return (long) handle.invokeExact(blob);
		} catch (Throwable throwable) {
			throw new IllegalStateException("GetBufferSize failed", throwable);
		}
	}

	private static MemorySegment getBlobPointer(MemorySegment blob) {
		try {
			MethodHandle handle = D3D11Com.method(blob, 3, FunctionDescriptor.of(ADDRESS, ADDRESS));
			return (MemorySegment) handle.invokeExact(blob);
		} catch (Throwable throwable) {
			throw new IllegalStateException("GetBufferPointer failed", throwable);
		}
	}
}