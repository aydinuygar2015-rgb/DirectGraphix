package com.directx.client.d3d11;

import static java.lang.foreign.ValueLayout.ADDRESS;
import static java.lang.foreign.ValueLayout.JAVA_FLOAT;
import static java.lang.foreign.ValueLayout.JAVA_INT;

import com.directx.DirectGraphix;
import com.mojang.renderpearl.api.GpuFormat;
import com.mojang.renderpearl.api.buffers.GpuBuffer;
import com.mojang.renderpearl.api.buffers.GpuBufferSlice;
import com.mojang.renderpearl.api.commands.GpuQueryPool;
import com.mojang.renderpearl.api.commands.RenderPass;
import com.mojang.renderpearl.api.commands.RenderPassDescriptor;
import com.mojang.renderpearl.api.pipeline.IndexType;
import com.mojang.renderpearl.api.pipeline.UniformType;
import com.mojang.renderpearl.api.textures.GpuTexture;
import com.mojang.renderpearl.api.textures.GpuTextureView;
import com.mojang.renderpearl.backend.api.BackendRenderPipeline;
import com.mojang.renderpearl.backend.api.RenderPassBackend;
import com.mojang.renderpearl.util.TextureViewAndSampler;
import java.lang.foreign.Arena;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.MemorySegment;
import java.lang.invoke.MethodHandle;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;
import org.joml.Vector4fc;
import org.jspecify.annotations.Nullable;
import org.lwjgl.PointerBuffer;

public final class D3D11RenderPass implements RenderPassBackend {
	private static final int MAX_RENDER_TARGETS = 8;
	private static final int MAX_UNIFORMS = 32;
	private static final int MAX_VERTEX_BUFFERS = 8;
	private static final int DEVICE_CREATE_SHADER_RESOURCE_VIEW = 7;
	private static final int DEVICE_CREATE_RENDER_TARGET_VIEW = 9;
	private static final int DEVICE_CREATE_DEPTH_STENCIL_VIEW = 10;
	private static final int CONTEXT_VS_SET_CONSTANT_BUFFERS = 7;
	private static final int CONTEXT_PS_SET_SHADER_RESOURCES = 8;
	private static final int CONTEXT_PS_SET_SHADER = 9;
	private static final int CONTEXT_PS_SET_SAMPLERS = 10;
	private static final int CONTEXT_VS_SET_SHADER = 11;
	private static final int CONTEXT_DRAW_INDEXED = 12;
	private static final int CONTEXT_DRAW = 13;
	private static final int CONTEXT_PS_SET_CONSTANT_BUFFERS = 16;
	private static final int CONTEXT_IA_SET_INPUT_LAYOUT = 17;
	private static final int CONTEXT_IA_SET_VERTEX_BUFFERS = 18;
	private static final int CONTEXT_IA_SET_INDEX_BUFFER = 19;
	private static final int CONTEXT_DRAW_INDEXED_INSTANCED = 20;
	private static final int CONTEXT_DRAW_INSTANCED = 21;
	private static final int CONTEXT_IA_SET_PRIMITIVE_TOPOLOGY = 24;
	private static final int CONTEXT_VS_SET_SHADER_RESOURCES = 25;
	private static final int CONTEXT_VS_SET_SAMPLERS = 26;
	private static final int CONTEXT_OM_SET_RENDER_TARGETS = 33;
	private static final int CONTEXT_OM_SET_BLEND_STATE = 35;
	private static final int CONTEXT_OM_SET_DEPTH_STENCIL_STATE = 36;
	private static final int CONTEXT_DRAW_INDEXED_INSTANCED_INDIRECT = 39;
	private static final int CONTEXT_DRAW_INSTANCED_INDIRECT = 40;
	private static final int CONTEXT_RS_SET_STATE = 43;
	private static final int CONTEXT_RS_SET_VIEWPORTS = 44;
	private static final int CONTEXT_RS_SET_SCISSOR_RECTS = 45;
	private static final int CONTEXT_CLEAR_RENDER_TARGET_VIEW = 50;
	private static final int CONTEXT_CLEAR_DEPTH_STENCIL_VIEW = 53;
	private static final int D3D11_CLEAR_DEPTH = 0x1;
	private static final int D3D11_SRV_DIMENSION_BUFFER = 1;
	private static final int D3D11_RTV_DIMENSION_TEXTURE2D = 4;
	private static final int D3D11_DSV_DIMENSION_TEXTURE2D = 3;
	private static final AtomicBoolean FIRST_PASS_LOGGED = new AtomicBoolean();

	private final D3D11Context context;
	private D3D11RenderPipeline currentPipeline;
	private final @Nullable Object[] boundUniforms = new Object[MAX_UNIFORMS];
	private final boolean[] hasBoundUniform = new boolean[MAX_UNIFORMS];
	private final @Nullable GpuBufferSlice[] boundVertexBuffers = new GpuBufferSlice[MAX_VERTEX_BUFFERS];
	private final boolean[] hasBoundVertexBuffer = new boolean[MAX_VERTEX_BUFFERS];
	private MemorySegment boundIndexBuffer = MemorySegment.NULL;
	private int boundIndexFormat = 42;
	private RenderPass.@Nullable RenderArea renderArea;
	private int outputWidth;
	private int outputHeight;

	public D3D11RenderPass(D3D11Context context, RenderPassDescriptor descriptor) {
		this.context = context;
		this.begin(descriptor);
		if (FIRST_PASS_LOGGED.compareAndSet(false, true)) {
			DirectGraphix.LOGGER.info(
				"[DirectGraphix] First D3D11 render pass started: label='{}', colorAttachments={}, depthAttachment={}",
				safeLabel(descriptor),
				descriptor.colorAttachments().size(),
				descriptor.depthAttachment() != null
			);
		}
	}

	private void begin(RenderPassDescriptor descriptor) {
		List<RenderPassDescriptor.Attachment<Optional<Vector4fc>>> colorAttachments = descriptor.colorAttachments();
		if (colorAttachments.size() > MAX_RENDER_TARGETS) {
			throw new IllegalArgumentException("D3D11 supports at most " + MAX_RENDER_TARGETS + " color attachments; got " + colorAttachments.size());
		}

		this.renderArea = descriptor.renderArea();
		this.outputWidth = 0;
		this.outputHeight = 0;

		try (Arena arena = Arena.ofConfined()) {
			MemorySegment nullSrvs = arena.allocate(ADDRESS, 16);
			MethodHandle psSrv = D3D11Com.method(this.context.immediateContext, CONTEXT_PS_SET_SHADER_RESOURCES, FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, JAVA_INT, ADDRESS));
			psSrv.invokeExact(this.context.immediateContext, 0, 16, nullSrvs);

			MemorySegment renderTargetArray = colorAttachments.isEmpty()
				? MemorySegment.NULL
				: arena.allocate(ADDRESS, colorAttachments.size());
			MemorySegment depthStencilView = MemorySegment.NULL;

			for (int i = 0; i < colorAttachments.size(); i++) {
				RenderPassDescriptor.Attachment<Optional<Vector4fc>> attachment = colorAttachments.get(i);
				MemorySegment rtv = MemorySegment.NULL;
				int attachmentWidth = 0;
				int attachmentHeight = 0;
				if (attachment != null && attachment.textureView() != null) {
					GpuTextureView view = attachment.textureView();
					D3D11GpuTexture texture = requireTexture(view.texture(), "color");
					int mip = Math.max(0, view.baseMipLevel());
					this.outputWidth = view.getWidth(0);
					this.outputHeight = view.getHeight(0);
					attachmentWidth = this.outputWidth;
					attachmentHeight = this.outputHeight;

					MemorySegment rtvDesc = MemorySegment.NULL;
					if (mip > 0 && texture.getDepthOrLayers() <= 1) {
						rtvDesc = arena.allocate(20, 4);
						rtvDesc.set(JAVA_INT, 0, D3D11GpuTexture.dxgiFormat(texture.getFormat()));
						rtvDesc.set(JAVA_INT, 4, D3D11_RTV_DIMENSION_TEXTURE2D);
						rtvDesc.set(JAVA_INT, 8, mip);
					}

					MemorySegment outRtv = arena.allocate(ADDRESS);
					MethodHandle createRtv = D3D11Com.method(
						this.context.device,
						DEVICE_CREATE_RENDER_TARGET_VIEW,
						FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, ADDRESS, ADDRESS)
					);
					int hr = (int) createRtv.invokeExact(this.context.device, texture.resource(), rtvDesc, outRtv);
					D3D11Com.checkHr(hr, "ID3D11Device::CreateRenderTargetView");
					rtv = outRtv.get(ADDRESS, 0);
				}
				renderTargetArray.set(ADDRESS, (long) i * ADDRESS.byteSize(), rtv);

				if (rtv.address() != 0L && attachment != null) {
					Optional<Vector4fc> clearValue = attachment.clearValue();
					if (clearValue != null && clearValue.isPresent()) {
						clearColorInRenderArea(rtv, clearValue.get(), arena, attachmentWidth, attachmentHeight);
					}
				}
			}

			RenderPassDescriptor.Attachment<OptionalDouble> depthAttachment = descriptor.depthAttachment();
			if (depthAttachment != null && depthAttachment.textureView() != null) {
				GpuTextureView depthView = depthAttachment.textureView();
				D3D11GpuTexture texture = requireTexture(depthView.texture(), "depth");
				int mip = Math.max(0, depthView.baseMipLevel());
				if (this.outputWidth <= 0 || this.outputHeight <= 0) {
					this.outputWidth = depthView.getWidth(0);
					this.outputHeight = depthView.getHeight(0);
				}

				boolean isTypeless = (texture.usage() & GpuTexture.USAGE_TEXTURE_BINDING) != 0;
				MemorySegment dsvDesc = MemorySegment.NULL;
				if (isTypeless || (mip > 0 && texture.getDepthOrLayers() <= 1)) {
					dsvDesc = arena.allocate(20, 4);
					dsvDesc.set(JAVA_INT, 0, D3D11GpuTexture.dxgiFormat(texture.getFormat()));
					dsvDesc.set(JAVA_INT, 4, D3D11_DSV_DIMENSION_TEXTURE2D);
					dsvDesc.set(JAVA_INT, 8, 0);
					dsvDesc.set(JAVA_INT, 12, mip);
				}

				MemorySegment outDsv = arena.allocate(ADDRESS);
				MethodHandle createDsv = D3D11Com.method(
					this.context.device,
					DEVICE_CREATE_DEPTH_STENCIL_VIEW,
					FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, ADDRESS, ADDRESS)
				);
				int hr = (int) createDsv.invokeExact(this.context.device, texture.resource(), dsvDesc, outDsv);
				D3D11Com.checkHr(hr, "ID3D11Device::CreateDepthStencilView");
				depthStencilView = outDsv.get(ADDRESS, 0);

				OptionalDouble clearDepth = depthAttachment.clearValue();
				if (clearDepth != null && clearDepth.isPresent()) {
					MethodHandle clearDsv = D3D11Com.method(
						this.context.immediateContext,
						CONTEXT_CLEAR_DEPTH_STENCIL_VIEW,
						FunctionDescriptor.ofVoid(ADDRESS, ADDRESS, JAVA_INT, JAVA_FLOAT, JAVA_INT)
					);
					clearDsv.invokeExact(this.context.immediateContext, depthStencilView, D3D11_CLEAR_DEPTH, (float) clearDepth.getAsDouble(), 0);
				}
			}

			MethodHandle setRenderTargets = D3D11Com.method(
				this.context.immediateContext,
				CONTEXT_OM_SET_RENDER_TARGETS,
				FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, ADDRESS, ADDRESS)
			);
			setRenderTargets.invokeExact(
				this.context.immediateContext,
				colorAttachments.size(),
				renderTargetArray,
				depthStencilView
			);

			applyViewport(arena);
			disableScissor();
			D3D11DebugLog.beginPass(safeLabel(descriptor), colorAttachments.size(), depthAttachment != null, this.outputWidth, this.outputHeight);

			for (int i = 0; i < colorAttachments.size(); i++) {
				D3D11Com.release(renderTargetArray.get(ADDRESS, (long) i * ADDRESS.byteSize()));
			}
			D3D11Com.release(depthStencilView);
		} catch (Throwable throwable) {
			throw new IllegalStateException("Failed to begin D3D11 render pass '" + safeLabel(descriptor) + "'", throwable);
		}
	}

	private static String safeLabel(RenderPassDescriptor descriptor) {
		try {
			return descriptor.label() == null ? "unnamed" : descriptor.label().get();
		} catch (Throwable ignored) {
			return "unnamed";
		}
	}

	private static D3D11GpuTexture requireTexture(GpuTexture texture, String role) {
		if (!(texture instanceof D3D11GpuTexture d3dTexture)) {
			throw new IllegalArgumentException("D3D11 render pass received a non-D3D11 " + role + " texture: " + texture.getClass().getName());
		}
		return d3dTexture;
	}

	private void clearColor(MemorySegment rtv, Vector4fc color, Arena arena) throws Throwable {
		MemorySegment colorData = arena.allocate(16, 4);
		colorData.set(JAVA_FLOAT, 0, color.x());
		colorData.set(JAVA_FLOAT, 4, color.y());
		colorData.set(JAVA_FLOAT, 8, color.z());
		colorData.set(JAVA_FLOAT, 12, color.w());
		MethodHandle clear = D3D11Com.method(
			this.context.immediateContext,
			CONTEXT_CLEAR_RENDER_TARGET_VIEW,
			FunctionDescriptor.ofVoid(ADDRESS, ADDRESS, ADDRESS)
		);
		clear.invokeExact(this.context.immediateContext, rtv, colorData);
	}

	private void clearColorInRenderArea(MemorySegment rtv, Vector4fc color, Arena arena, int attachmentWidth, int attachmentHeight) throws Throwable {
		RenderPass.RenderArea area = this.renderArea;
		boolean partial = area != null
			&& attachmentWidth > 0
			&& attachmentHeight > 0
			&& (area.x() > 0 || area.y() > 0 || area.width() < attachmentWidth || area.height() < attachmentHeight);
		if (partial) {
			int left = Math.max(0, area.x());
			int top = Math.max(0, area.y());
			int right = Math.min(attachmentWidth, area.x() + area.width());
			int bottom = Math.min(attachmentHeight, area.y() + area.height());
			if (right <= left || bottom <= top) {
				return;
			}
			if (this.context.clearRenderTargetRegion(rtv, color.x(), color.y(), color.z(), color.w(), left, top, right - left, bottom - top)) {
				return;
			}
		}
		clearColor(rtv, color, arena);
	}

	private void applyViewport(Arena arena) throws Throwable {
		int vpWidth = this.outputWidth > 0 ? this.outputWidth : (this.renderArea != null ? this.renderArea.width() : 0);
		int vpHeight = this.outputHeight > 0 ? this.outputHeight : (this.renderArea != null ? this.renderArea.height() : 0);
		if (vpWidth <= 0 || vpHeight <= 0) {
			return;
		}
		MemorySegment viewport = arena.allocate(24, 4);
		viewport.set(JAVA_FLOAT, 0, 0.0f);
		viewport.set(JAVA_FLOAT, 4, 0.0f);
		viewport.set(JAVA_FLOAT, 8, (float) vpWidth);
		viewport.set(JAVA_FLOAT, 12, (float) vpHeight);
		viewport.set(JAVA_FLOAT, 16, 0.0f);
		viewport.set(JAVA_FLOAT, 20, 1.0f);

		MethodHandle setViewports = D3D11Com.method(
			this.context.immediateContext,
			CONTEXT_RS_SET_VIEWPORTS,
			FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, ADDRESS)
		);
		setViewports.invokeExact(this.context.immediateContext, 1, viewport);
	}

	@Override public void pushDebugGroup(Supplier<String> name) { }
	@Override public void popDebugGroup() { }

	@Override
	public void setPipeline(BackendRenderPipeline pipeline) {
		if (!(pipeline instanceof D3D11RenderPipeline d3dPipeline)) {
			throw new IllegalArgumentException("D3D11 render pass received an incompatible pipeline: " + pipeline.getClass().getName());
		}
		if (d3dPipeline.isClosed()) {
			throw new IllegalStateException("Attempted to bind a closed D3D11 pipeline");
		}
		try (Arena arena = Arena.ofConfined()) {
			MethodHandle setLayout = D3D11Com.method(this.context.immediateContext, CONTEXT_IA_SET_INPUT_LAYOUT, FunctionDescriptor.ofVoid(ADDRESS, ADDRESS));
			setLayout.invokeExact(this.context.immediateContext, d3dPipeline.inputLayout());

			MethodHandle setVs = D3D11Com.method(this.context.immediateContext, CONTEXT_VS_SET_SHADER, FunctionDescriptor.ofVoid(ADDRESS, ADDRESS, ADDRESS, JAVA_INT));
			MethodHandle setPs = D3D11Com.method(this.context.immediateContext, CONTEXT_PS_SET_SHADER, FunctionDescriptor.ofVoid(ADDRESS, ADDRESS, ADDRESS, JAVA_INT));
			setVs.invokeExact(this.context.immediateContext, d3dPipeline.vertexShader(), MemorySegment.NULL, 0);
			setPs.invokeExact(this.context.immediateContext, d3dPipeline.pixelShader(), MemorySegment.NULL, 0);

			MethodHandle setTopology = D3D11Com.method(this.context.immediateContext, CONTEXT_IA_SET_PRIMITIVE_TOPOLOGY, FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT));
			setTopology.invokeExact(this.context.immediateContext, d3dPipeline.nativeTopology());

			MemorySegment blendFactor = arena.allocate(16, 4);
			blendFactor.set(JAVA_FLOAT, 0, 1.0f);
			blendFactor.set(JAVA_FLOAT, 4, 1.0f);
			blendFactor.set(JAVA_FLOAT, 8, 1.0f);
			blendFactor.set(JAVA_FLOAT, 12, 1.0f);
			MethodHandle setBlend = D3D11Com.method(this.context.immediateContext, CONTEXT_OM_SET_BLEND_STATE, FunctionDescriptor.ofVoid(ADDRESS, ADDRESS, ADDRESS, JAVA_INT));
			setBlend.invokeExact(this.context.immediateContext, d3dPipeline.blendState(), blendFactor, 0xFFFFFFFF);

			MethodHandle setDepth = D3D11Com.method(this.context.immediateContext, CONTEXT_OM_SET_DEPTH_STENCIL_STATE, FunctionDescriptor.ofVoid(ADDRESS, ADDRESS, JAVA_INT));
			setDepth.invokeExact(this.context.immediateContext, d3dPipeline.depthStencilState(), 0);

			MethodHandle setRs = D3D11Com.method(this.context.immediateContext, CONTEXT_RS_SET_STATE, FunctionDescriptor.ofVoid(ADDRESS, ADDRESS));
			setRs.invokeExact(this.context.immediateContext, d3dPipeline.rasterizerState());

			this.currentPipeline = d3dPipeline;
			D3D11DebugLog.passDetail("SET_PIPELINE", "name='" + d3dPipeline.name() + "' topology=" + (d3dPipeline.isQuadTopology() ? "QUADS" : "NATIVE"));

			for (int i = 0; i < MAX_UNIFORMS; i++) {
				if (this.hasBoundUniform[i]) {
					applyUniform(i, this.boundUniforms[i]);
				}
			}
			for (int i = 0; i < MAX_VERTEX_BUFFERS; i++) {
				if (this.hasBoundVertexBuffer[i]) {
					applyVertexBuffer(i, this.boundVertexBuffers[i], true);
				}
			}
		} catch (Throwable throwable) {
			throw new IllegalStateException("Failed to bind D3D11 pipeline '" + d3dPipeline.name() + "'", throwable);
		}
	}

	@Override
	public void setUniform(int index, @Nullable Object value) {
		if (index >= 0 && index < MAX_UNIFORMS) {
			this.boundUniforms[index] = value;
			this.hasBoundUniform[index] = true;
		}
		if (this.currentPipeline == null) {
			return;
		}
		applyUniform(index, value);
	}

	private void applyUniform(int index, @Nullable Object value) {
		if (this.currentPipeline == null) {
			return;
		}
		try (Arena arena = Arena.ofConfined()) {
			if (value == null) {
				bindConstantBuffer(this.currentPipeline.vsCbufferSlot(index), this.currentPipeline.psCbufferSlot(index), MemorySegment.NULL, arena);
				bindSrvAndSampler(
					this.currentPipeline.vsTextureSlot(index),
					this.currentPipeline.psTextureSlot(index),
					this.currentPipeline.vsSamplerSlot(index),
					this.currentPipeline.psSamplerSlot(index),
					MemorySegment.NULL,
					MemorySegment.NULL,
					arena
				);
				return;
			}

			if (value instanceof GpuBufferSlice slice) {
				if (!(slice.buffer() instanceof D3D11GpuBuffer d3dBuf)) {
					return;
				}
				d3dBuf.checkCanBeUsed();

				if (this.currentPipeline.uniformType(index) == UniformType.TEXEL_BUFFER) {
					bindTexelBuffer(index, slice, d3dBuf, arena);
					return;
				}

				int vsSlot = this.currentPipeline.vsCbufferSlot(index);
				int psSlot = this.currentPipeline.psCbufferSlot(index);
				if (D3D11DebugLog.isDetailedPassActive()) {
					int previewBytes = (int) Math.min(64L, slice.length());
					ByteBuffer preview = previewBytes > 0 ? d3dBuf.shadowRange(slice.offset(), previewBytes) : null;
					D3D11DebugLog.passDetail(
						"SET_UNIFORM_BUF",
						"idx=" + index + " type=" + this.currentPipeline.uniformType(index)
							+ " offset=" + slice.offset() + " len=" + slice.length()
							+ " vsCb=" + vsSlot
							+ " psCb=" + psSlot
							+ " floats=" + D3D11DebugLog.dumpFloats(preview, 16)
					);
				}
				if (vsSlot < 0 && psSlot < 0) {
					return;
				}

				MemorySegment cbResource;
				if (slice.offset() == 0L) {
					cbResource = d3dBuf.resource();
				} else {
					int len = Math.toIntExact(slice.length());
					int alignedLen = (len + 15) & ~15;
					cbResource = this.context.getOrCreateSliceConstantBuffer(index, alignedLen);
					ByteBuffer sliceView = d3dBuf.shadowRange(slice.offset(), len);
					MemorySegment uploadBuf = arena.allocate(alignedLen, 16);
					MemorySegment.copy(MemorySegment.ofBuffer(sliceView), 0L, uploadBuf, 0L, len);
					this.context.updateSubresource(cbResource, 0, MemorySegment.NULL, uploadBuf, 0, 0);
				}
				bindConstantBuffer(vsSlot, psSlot, cbResource, arena);
			} else if (value instanceof TextureViewAndSampler pair) {
				MemorySegment srv = (pair.view() instanceof D3D11GpuTextureView tv) ? tv.resource() : MemorySegment.NULL;
				MemorySegment samp = (pair.sampler() instanceof D3D11GpuSampler s) ? s.resource() : MemorySegment.NULL;
				if (D3D11DebugLog.isDetailedPassActive()) {
					String texLabel = (pair.view() != null && pair.view().texture() != null) ? pair.view().texture().getLabel() : "null";
					int tw = (pair.view() != null) ? pair.view().getWidth(0) : 0;
					int th = (pair.view() != null) ? pair.view().getHeight(0) : 0;
					D3D11DebugLog.passDetail(
						"SET_UNIFORM_TEX",
						"idx=" + index + " tex='" + texLabel + "' (" + tw + "x" + th + ")"
							+ " srv=0x" + Long.toHexString(srv.address())
							+ " samp=0x" + Long.toHexString(samp.address())
							+ " psTex=" + this.currentPipeline.psTextureSlot(index)
							+ " psSamp=" + this.currentPipeline.psSamplerSlot(index)
					);
				}
				bindSrvAndSampler(
					this.currentPipeline.vsTextureSlot(index),
					this.currentPipeline.psTextureSlot(index),
					this.currentPipeline.vsSamplerSlot(index),
					this.currentPipeline.psSamplerSlot(index),
					srv,
					samp,
					arena
				);
			}
		} catch (Throwable throwable) {
			throw new IllegalStateException("Failed to bind D3D11 uniform index=" + index, throwable);
		}
	}

	private void bindTexelBuffer(int index, GpuBufferSlice slice, D3D11GpuBuffer d3dBuf, Arena arena) throws Throwable {
		int vsTexSlot = this.currentPipeline.vsTextureSlot(index);
		int psTexSlot = this.currentPipeline.psTextureSlot(index);
		if (vsTexSlot < 0 && psTexSlot < 0) {
			return;
		}
		GpuFormat fmt = this.currentPipeline.uniformFormat(index);
		int dxgiFmt = (fmt != null) ? D3D11GpuTexture.dxgiFormat(fmt) : 2;
		int elementSize = (fmt != null && fmt.blockSize() > 0) ? fmt.blockSize() : 16;
		int firstElement = Math.toIntExact(slice.offset() / elementSize);
		int numElements = Math.max(1, Math.toIntExact(slice.length() / elementSize));

		MemorySegment desc = arena.allocate(24, 4);
		desc.set(JAVA_INT, 0, dxgiFmt);
		desc.set(JAVA_INT, 4, D3D11_SRV_DIMENSION_BUFFER);
		desc.set(JAVA_INT, 8, firstElement);
		desc.set(JAVA_INT, 12, numElements);

		MemorySegment outSrv = arena.allocate(ADDRESS);
		MethodHandle createSrv = D3D11Com.method(
			this.context.device,
			DEVICE_CREATE_SHADER_RESOURCE_VIEW,
			FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, ADDRESS, ADDRESS)
		);
		int hr = (int) createSrv.invokeExact(this.context.device, d3dBuf.resource(), desc, outSrv);
		if (hr < 0) {
			return;
		}
		MemorySegment srv = outSrv.get(ADDRESS, 0);
		try {
			MemorySegment srvArr = arena.allocate(ADDRESS);
			srvArr.set(ADDRESS, 0, srv);
			if (vsTexSlot >= 0 && vsTexSlot < 128) {
				MethodHandle vsSrv = D3D11Com.method(this.context.immediateContext, CONTEXT_VS_SET_SHADER_RESOURCES, FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, JAVA_INT, ADDRESS));
				vsSrv.invokeExact(this.context.immediateContext, vsTexSlot, 1, srvArr);
			}
			if (psTexSlot >= 0 && psTexSlot < 128) {
				MethodHandle psSrv = D3D11Com.method(this.context.immediateContext, CONTEXT_PS_SET_SHADER_RESOURCES, FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, JAVA_INT, ADDRESS));
				psSrv.invokeExact(this.context.immediateContext, psTexSlot, 1, srvArr);
			}
		} finally {
			D3D11Com.release(srv);
		}
	}

	private void bindConstantBuffer(int vsSlot, int psSlot, MemorySegment buffer, Arena arena) throws Throwable {
		MemorySegment arr = arena.allocate(ADDRESS);
		arr.set(ADDRESS, 0, buffer);
		if (vsSlot >= 0 && vsSlot < 14) {
			MethodHandle vsCb = D3D11Com.method(this.context.immediateContext, CONTEXT_VS_SET_CONSTANT_BUFFERS, FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, JAVA_INT, ADDRESS));
			vsCb.invokeExact(this.context.immediateContext, vsSlot, 1, arr);
		}
		if (psSlot >= 0 && psSlot < 14) {
			MethodHandle psCb = D3D11Com.method(this.context.immediateContext, CONTEXT_PS_SET_CONSTANT_BUFFERS, FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, JAVA_INT, ADDRESS));
			psCb.invokeExact(this.context.immediateContext, psSlot, 1, arr);
		}
	}

	private void bindSrvAndSampler(int vsTexSlot, int psTexSlot, int vsSampSlot, int psSampSlot, MemorySegment srv, MemorySegment sampler, Arena arena) throws Throwable {
		MemorySegment srvArr = arena.allocate(ADDRESS);
		srvArr.set(ADDRESS, 0, srv);
		if (vsTexSlot >= 0 && vsTexSlot < 128) {
			MethodHandle vsSrv = D3D11Com.method(this.context.immediateContext, CONTEXT_VS_SET_SHADER_RESOURCES, FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, JAVA_INT, ADDRESS));
			vsSrv.invokeExact(this.context.immediateContext, vsTexSlot, 1, srvArr);
		}
		if (psTexSlot >= 0 && psTexSlot < 128) {
			MethodHandle psSrv = D3D11Com.method(this.context.immediateContext, CONTEXT_PS_SET_SHADER_RESOURCES, FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, JAVA_INT, ADDRESS));
			psSrv.invokeExact(this.context.immediateContext, psTexSlot, 1, srvArr);
		}

		MemorySegment sampArr = arena.allocate(ADDRESS);
		sampArr.set(ADDRESS, 0, sampler);
		if (vsSampSlot >= 0 && vsSampSlot < 16) {
			MethodHandle vsSamp = D3D11Com.method(this.context.immediateContext, CONTEXT_VS_SET_SAMPLERS, FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, JAVA_INT, ADDRESS));
			vsSamp.invokeExact(this.context.immediateContext, vsSampSlot, 1, sampArr);
		}
		if (psSampSlot >= 0 && psSampSlot < 16) {
			MethodHandle psSamp = D3D11Com.method(this.context.immediateContext, CONTEXT_PS_SET_SAMPLERS, FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, JAVA_INT, ADDRESS));
			psSamp.invokeExact(this.context.immediateContext, psSampSlot, 1, sampArr);
		}
	}

	@Override
	public void pushConstants(ByteBuffer data) {
		if (this.currentPipeline == null || data == null || !data.hasRemaining()) {
			return;
		}
		int vsSlot = this.currentPipeline.vsPushConstantSlot();
		int psSlot = this.currentPipeline.psPushConstantSlot();
		if (vsSlot < 0 && psSlot < 0) {
			return;
		}
		try (Arena arena = Arena.ofConfined()) {
			ByteBuffer dup = data.duplicate();
			int len = dup.remaining();
			int alignedLen = (len + 15) & ~15;
			MemorySegment cb = this.context.getOrCreateSliceConstantBuffer(32, alignedLen);
			MemorySegment upload = arena.allocate(alignedLen, 16);
			if (dup.isDirect()) {
				MemorySegment.copy(MemorySegment.ofBuffer(dup), 0L, upload, 0L, len);
			} else {
				byte[] bytes = new byte[len];
				dup.get(bytes);
				MemorySegment.copy(MemorySegment.ofArray(bytes), 0L, upload, 0L, len);
			}
			this.context.updateSubresource(cb, 0, MemorySegment.NULL, upload, 0, 0);
			bindConstantBuffer(vsSlot, psSlot, cb, arena);
		} catch (Throwable throwable) {
			throw new IllegalStateException("Failed to push D3D11 constants", throwable);
		}
	}

	@Override
	public void enableScissor(int x, int y, int w, int h) {
		try (Arena arena = Arena.ofConfined()) {
			MemorySegment rect = arena.allocate(16, 4);
			rect.set(JAVA_INT, 0, x);
			rect.set(JAVA_INT, 4, y);
			rect.set(JAVA_INT, 8, x + Math.max(0, w));
			rect.set(JAVA_INT, 12, y + Math.max(0, h));
			MethodHandle handle = D3D11Com.method(this.context.immediateContext, CONTEXT_RS_SET_SCISSOR_RECTS, FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, ADDRESS));
			handle.invokeExact(this.context.immediateContext, 1, rect);
		} catch (Throwable t) {
			throw new IllegalStateException("Failed to set D3D11 scissor rectangle", t);
		}
	}

	@Override
	public void disableScissor() {
		if (this.renderArea != null) {
			enableScissor(this.renderArea.x(), this.renderArea.y(), this.renderArea.width(), this.renderArea.height());
		} else {
			enableScissor(0, 0, Math.max(1, this.outputWidth), Math.max(1, this.outputHeight));
		}
	}

	@Override
	public void setVertexBuffer(int index, @Nullable GpuBufferSlice slice) {
		if (index >= 0 && index < MAX_VERTEX_BUFFERS) {
			this.boundVertexBuffers[index] = slice;
			this.hasBoundVertexBuffer[index] = true;
		}
		if (this.currentPipeline == null) {
			return;
		}
		applyVertexBuffer(index, slice, false);
	}

	private void applyVertexBuffer(int index, @Nullable GpuBufferSlice slice, boolean ignoreUnusedSlot) {
		if (this.currentPipeline == null) {
			return;
		}
		try (Arena arena = Arena.ofConfined()) {
			MemorySegment buffers = arena.allocate(ADDRESS);
			MemorySegment strides = arena.allocate(JAVA_INT);
			MemorySegment offsets = arena.allocate(JAVA_INT);
			if (slice == null) {
				buffers.set(ADDRESS, 0, MemorySegment.NULL);
				strides.set(JAVA_INT, 0, 0);
				offsets.set(JAVA_INT, 0, 0);
			} else {
				if (!(slice.buffer() instanceof D3D11GpuBuffer buffer)) {
					throw new IllegalArgumentException("Vertex buffer is not a D3D11 buffer");
				}
				buffer.checkCanBeUsed();
				int stride = this.currentPipeline.vertexStride(index);
				if (stride <= 0) {
					if (ignoreUnusedSlot) {
						return;
					}
					throw new IllegalArgumentException("Pipeline '" + this.currentPipeline.name() + "' has no vertex-buffer slot " + index);
				}
				buffers.set(ADDRESS, 0, buffer.resource());
				strides.set(JAVA_INT, 0, stride);
				offsets.set(JAVA_INT, 0, Math.toIntExact(slice.offset()));
			}
			MethodHandle handle = D3D11Com.method(this.context.immediateContext, CONTEXT_IA_SET_VERTEX_BUFFERS, FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, JAVA_INT, ADDRESS, ADDRESS, ADDRESS));
			handle.invokeExact(this.context.immediateContext, index, 1, buffers, strides, offsets);
			if (D3D11DebugLog.isDetailedPassActive() && slice != null && slice.buffer() instanceof D3D11GpuBuffer vbuf) {
				int stride = this.currentPipeline.vertexStride(index);
				String vertexDump = " <GPU-only buffer>";
				try {
					int previewBytes = (int) Math.min(slice.length(), Math.max(stride * 4L, 64L));
					ByteBuffer vpreview = previewBytes > 0 ? vbuf.shadowRange(slice.offset(), previewBytes) : null;
					vertexDump = D3D11DebugLog.dumpVertices(vpreview, stride, 4);
				} catch (Throwable ignored) {
				}
				D3D11DebugLog.passDetail(
					"SET_VB",
					"slot=" + index + " offset=" + slice.offset() + " len=" + slice.length() + " stride=" + stride
						+ vertexDump
				);
			}
		} catch (Throwable t) {
			throw new IllegalStateException("Failed to bind D3D11 vertex buffer at slot " + index, t);
		}
	}

	@Override
	public void setIndexBuffer(GpuBuffer gpuBuffer, IndexType type) {
		if (!(gpuBuffer instanceof D3D11GpuBuffer buffer)) {
			throw new IllegalArgumentException("Index buffer is not a D3D11 buffer");
		}
		buffer.checkCanBeUsed();
		int dxgiFmt = (type == IndexType.SHORT) ? 57 : 42;
		D3D11DebugLog.passDetail("SET_IB", "type=" + type + " resource=0x" + Long.toHexString(buffer.resource().address()));
		bindNativeIndexBuffer(buffer.resource(), dxgiFmt);
	}

	private void bindNativeIndexBuffer(MemorySegment resource, int dxgiFmt) {
		try {
			MethodHandle handle = D3D11Com.method(this.context.immediateContext, CONTEXT_IA_SET_INDEX_BUFFER, FunctionDescriptor.ofVoid(ADDRESS, ADDRESS, JAVA_INT, JAVA_INT));
			handle.invokeExact(this.context.immediateContext, resource, dxgiFmt, 0);
			this.boundIndexBuffer = resource;
			this.boundIndexFormat = dxgiFmt;
		} catch (Throwable t) {
			throw new IllegalStateException("Failed to bind D3D11 index buffer", t);
		}
	}

	@Override
	public void drawIndexed(int indexCount, int instanceCount, int firstIndex, int vertexOffset, int firstInstance) {
		if (this.currentPipeline == null) {
			throw new IllegalStateException("drawIndexed called without a D3D11 pipeline");
		}
		if (this.boundIndexBuffer.address() == 0L) {
			throw new IllegalStateException("drawIndexed called without an index buffer");
		}
		if (indexCount <= 0 || instanceCount <= 0) {
			return;
		}
		D3D11DebugLog.passDetail("DRAW_INDEXED", "indexCount=" + indexCount + " instanceCount=" + instanceCount + " firstIndex=" + firstIndex + " vertexOffset=" + vertexOffset + " firstInstance=" + firstInstance);
		try {
			if (instanceCount == 1 && firstInstance == 0) {
				MethodHandle h = D3D11Com.method(this.context.immediateContext, CONTEXT_DRAW_INDEXED, FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, JAVA_INT, JAVA_INT));
				h.invokeExact(this.context.immediateContext, indexCount, firstIndex, vertexOffset);
			} else {
				MethodHandle h = D3D11Com.method(this.context.immediateContext, CONTEXT_DRAW_INDEXED_INSTANCED, FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, JAVA_INT, JAVA_INT, JAVA_INT, JAVA_INT));
				h.invokeExact(this.context.immediateContext, indexCount, instanceCount, firstIndex, vertexOffset, firstInstance);
			}
		} catch (Throwable t) {
			throw new IllegalStateException("ID3D11DeviceContext::DrawIndexed failed", t);
		}
	}

	@Override
	public void multiDrawIndexed(IntBuffer drawParameters, int instanceCount, int firstInstance, int drawCount) {
		for (int i = 0; i < drawCount && (i * 3 + 2) < drawParameters.remaining(); i++) {
			int base = drawParameters.position() + i * 3;
			drawIndexed(drawParameters.get(base), instanceCount, drawParameters.get(base + 1), drawParameters.get(base + 2), firstInstance);
		}
	}

	@Override
	public void multiDrawIndexed(PointerBuffer firstIndexOffsets, IntBuffer indexCounts, IntBuffer vertexOffsets, int drawCount) {
		int indexByteSize = (this.boundIndexFormat == 57) ? 2 : 4;
		for (int i = 0; i < drawCount; i++) {
			long byteOffset = firstIndexOffsets.get(firstIndexOffsets.position() + i);
			int firstIndex = (int) (byteOffset / indexByteSize);
			int count = indexCounts.get(indexCounts.position() + i);
			int vOffset = (vertexOffsets != null) ? vertexOffsets.get(vertexOffsets.position() + i) : 0;
			drawIndexed(count, 1, firstIndex, vOffset, 0);
		}
	}

	@Override
	public void drawIndexedIndirect(GpuBufferSlice indirect, int drawCount) {
		if (this.currentPipeline == null) {
			throw new IllegalStateException("drawIndexedIndirect called without a D3D11 pipeline");
		}
		if (this.boundIndexBuffer.address() == 0L) {
			throw new IllegalStateException("drawIndexedIndirect called without an index buffer");
		}
		if (drawCount <= 0) {
			return;
		}
		if (!(indirect.buffer() instanceof D3D11GpuBuffer indirectBuffer)) {
			throw new IllegalArgumentException("Indirect buffer is not a D3D11 buffer");
		}
		indirectBuffer.checkCanBeUsed();
		try {
			MethodHandle h = D3D11Com.method(
				this.context.immediateContext,
				CONTEXT_DRAW_INDEXED_INSTANCED_INDIRECT,
				FunctionDescriptor.ofVoid(ADDRESS, ADDRESS, JAVA_INT)
			);
			long baseOffset = indirect.offset();
			for (int i = 0; i < drawCount; i++) {
				int argOffset = Math.toIntExact(baseOffset + (long) i * 20L);
				h.invokeExact(this.context.immediateContext, indirectBuffer.resource(), argOffset);
			}
		} catch (Throwable t) {
			throw new IllegalStateException("ID3D11DeviceContext::DrawIndexedInstancedIndirect failed", t);
		}
	}

	@Override
	public void draw(int vertexCount, int instanceCount, int firstVertex, int firstInstance) {
		if (this.currentPipeline == null) {
			throw new IllegalStateException("draw called without a D3D11 pipeline");
		}
		if (vertexCount <= 0 || instanceCount <= 0) {
			return;
		}
		D3D11DebugLog.passDetail("DRAW", "vertexCount=" + vertexCount + " instanceCount=" + instanceCount + " firstVertex=" + firstVertex + " firstInstance=" + firstInstance);
		if (this.currentPipeline.isQuadTopology()) {
			int quadCount = vertexCount / 4;
			if (quadCount <= 0) {
				return;
			}
			MemorySegment prevIb = this.boundIndexBuffer;
			int prevFmt = this.boundIndexFormat;
			MemorySegment quadIb = this.context.getOrCreateQuadIndexBuffer(quadCount);
			bindNativeIndexBuffer(quadIb, 42);
			drawIndexed(quadCount * 6, instanceCount, 0, firstVertex, firstInstance);
			if (prevIb.address() != 0L) {
				bindNativeIndexBuffer(prevIb, prevFmt);
			}
			return;
		}
		try {
			if (instanceCount == 1 && firstInstance == 0) {
				MethodHandle h = D3D11Com.method(this.context.immediateContext, CONTEXT_DRAW, FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, JAVA_INT));
				h.invokeExact(this.context.immediateContext, vertexCount, firstVertex);
			} else {
				MethodHandle h = D3D11Com.method(this.context.immediateContext, CONTEXT_DRAW_INSTANCED, FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, JAVA_INT, JAVA_INT, JAVA_INT));
				h.invokeExact(this.context.immediateContext, vertexCount, instanceCount, firstVertex, firstInstance);
			}
		} catch (Throwable t) {
			throw new IllegalStateException("ID3D11DeviceContext::Draw failed", t);
		}
	}

	@Override
	public void multiDraw(IntBuffer drawParameters, int instanceCount, int firstInstance, int drawCount) {
		for (int i = 0; i < drawCount && (i * 2 + 1) < drawParameters.remaining(); i++) {
			int base = drawParameters.position() + i * 2;
			draw(drawParameters.get(base), instanceCount, drawParameters.get(base + 1), firstInstance);
		}
	}

	@Override
	public void multiDraw(IntBuffer firstVertices, IntBuffer vertexCounts, int drawCount) {
		for (int i = 0; i < drawCount; i++) {
			draw(vertexCounts.get(vertexCounts.position() + i), 1, firstVertices.get(firstVertices.position() + i), 0);
		}
	}

	@Override
	public void drawIndirect(GpuBufferSlice indirect, int drawCount) {
		if (this.currentPipeline == null) {
			throw new IllegalStateException("drawIndirect called without a D3D11 pipeline");
		}
		if (drawCount <= 0) {
			return;
		}
		if (!(indirect.buffer() instanceof D3D11GpuBuffer indirectBuffer)) {
			throw new IllegalArgumentException("Indirect buffer is not a D3D11 buffer");
		}
		indirectBuffer.checkCanBeUsed();
		try {
			MethodHandle h = D3D11Com.method(
				this.context.immediateContext,
				CONTEXT_DRAW_INSTANCED_INDIRECT,
				FunctionDescriptor.ofVoid(ADDRESS, ADDRESS, JAVA_INT)
			);
			long baseOffset = indirect.offset();
			for (int i = 0; i < drawCount; i++) {
				int argOffset = Math.toIntExact(baseOffset + (long) i * 16L);
				h.invokeExact(this.context.immediateContext, indirectBuffer.resource(), argOffset);
			}
		} catch (Throwable t) {
			throw new IllegalStateException("ID3D11DeviceContext::DrawInstancedIndirect failed", t);
		}
	}

	@Override
	public void writeTimestamp(GpuQueryPool pool, int index) {
	}
}