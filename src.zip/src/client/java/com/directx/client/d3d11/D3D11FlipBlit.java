package com.directx.client.d3d11;

import static java.lang.foreign.ValueLayout.ADDRESS;
import static java.lang.foreign.ValueLayout.JAVA_FLOAT;
import static java.lang.foreign.ValueLayout.JAVA_INT;

import com.directx.DirectGraphix;
import com.mojang.renderpearl.api.pipeline.ShaderType;
import java.lang.foreign.Arena;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.MemorySegment;
import java.lang.invoke.MethodHandle;

/**
 * Ana render target'i back buffer'a DIKEY CEVIREREK kopyalar.
 *
 * Neden gerekli: Vertex shader'larda Y'yi OpenGL/Vulkan ile ayni satir duzenine getirmek icin ters ceviriyoruz
 * (D3D11'de NDC y=+1 ust satirdir, GL/Vulkan'da NDC y=-1 satir 0'dir). Bu yuzden ana hedefin satir 0'i ekranin
 * ALTI olur. OpenGL ve Vulkan backend'leri de ekrana basarken dikey cevirir; burada ayni isi kucuk bir shader yapar.
 */
final class D3D11FlipBlit {
	private static final String HLSL =
		"cbuffer BlitInfo : register(b0)\n"
		+ "{\n"
		+ "    int copyHeight;\n"
		+ "    int3 padding;\n"
		+ "};\n"
		+ "Texture2D<float4> Src : register(t0);\n"
		+ "struct VSOut { float4 pos : SV_Position; };\n"
		+ "VSOut vs_main(uint id : SV_VertexID)\n"
		+ "{\n"
		+ "    float2 p = float2((id << 1) & 2, id & 2);\n"
		+ "    VSOut o;\n"
		+ "    o.pos = float4(p.x * 2.0 - 1.0, 1.0 - p.y * 2.0, 0.0, 1.0);\n"
		+ "    return o;\n"
		+ "}\n"
		+ "float4 ps_main(VSOut i) : SV_Target\n"
		+ "{\n"
		+ "    int2 px = int2(i.pos.xy);\n"
		+ "    return Src.Load(int3(px.x, copyHeight - 1 - px.y, 0));\n"
		+ "}\n";

	private final D3D11Context context;
	private final MemorySegment vertexShader;
	private final MemorySegment pixelShader;
	private final MemorySegment constantBuffer;
	private int lastCopyHeight = -1;
	private boolean warned;

	private final MethodHandle omSetRenderTargets;
	private final MethodHandle rsSetViewports;
	private final MethodHandle rsSetScissorRects;
	private final MethodHandle rsSetState;
	private final MethodHandle omSetBlendState;
	private final MethodHandle omSetDepthStencilState;
	private final MethodHandle iaSetInputLayout;
	private final MethodHandle iaSetPrimitiveTopology;
	private final MethodHandle vsSetShader;
	private final MethodHandle psSetShader;
	private final MethodHandle psSetConstantBuffers;
	private final MethodHandle psSetShaderResources;
	private final MethodHandle draw;

	private D3D11FlipBlit(D3D11Context context, MemorySegment vertexShader, MemorySegment pixelShader, MemorySegment constantBuffer) {
		this.context = context;
		this.vertexShader = vertexShader;
		this.pixelShader = pixelShader;
		this.constantBuffer = constantBuffer;

		MemorySegment ctx = context.immediateContext;
		this.omSetRenderTargets = D3D11Com.method(ctx, 33, FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, ADDRESS, ADDRESS));
		this.rsSetViewports = D3D11Com.method(ctx, 44, FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, ADDRESS));
		this.rsSetScissorRects = D3D11Com.method(ctx, 45, FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, ADDRESS));
		this.rsSetState = D3D11Com.method(ctx, 43, FunctionDescriptor.ofVoid(ADDRESS, ADDRESS));
		this.omSetBlendState = D3D11Com.method(ctx, 35, FunctionDescriptor.ofVoid(ADDRESS, ADDRESS, ADDRESS, JAVA_INT));
		this.omSetDepthStencilState = D3D11Com.method(ctx, 36, FunctionDescriptor.ofVoid(ADDRESS, ADDRESS, JAVA_INT));
		this.iaSetInputLayout = D3D11Com.method(ctx, 17, FunctionDescriptor.ofVoid(ADDRESS, ADDRESS));
		this.iaSetPrimitiveTopology = D3D11Com.method(ctx, 24, FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT));
		this.vsSetShader = D3D11Com.method(ctx, 11, FunctionDescriptor.ofVoid(ADDRESS, ADDRESS, ADDRESS, JAVA_INT));
		this.psSetShader = D3D11Com.method(ctx, 9, FunctionDescriptor.ofVoid(ADDRESS, ADDRESS, ADDRESS, JAVA_INT));
		this.psSetConstantBuffers = D3D11Com.method(ctx, 16, FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, JAVA_INT, ADDRESS));
		this.psSetShaderResources = D3D11Com.method(ctx, 8, FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, JAVA_INT, ADDRESS));
		this.draw = D3D11Com.method(ctx, 13, FunctionDescriptor.ofVoid(ADDRESS, JAVA_INT, JAVA_INT));
	}

	/** Shader'lari derleyip olusturur. Herhangi bir hata olursa null doner (cagiran satir satir kopyalamaya duser). */
	static D3D11FlipBlit tryCreate(D3D11Context context) {
		try {
			D3D11Shader.Result vs = D3D11Shader.compileRaw(context, ShaderType.VERTEX, HLSL, "vs_main");
			D3D11Shader.Result ps = D3D11Shader.compileRaw(context, ShaderType.FRAGMENT, HLSL, "ps_main");

			MemorySegment cb;
			try (Arena arena = Arena.ofConfined()) {
				// D3D11_BUFFER_DESC: ByteWidth, Usage(DEFAULT), BindFlags(CONSTANT_BUFFER), CPUAccessFlags, MiscFlags, StructureByteStride
				MemorySegment desc = arena.allocate(24, 4);
				desc.set(JAVA_INT, 0, 16);
				desc.set(JAVA_INT, 4, 0);
				desc.set(JAVA_INT, 8, 0x4);
				desc.set(JAVA_INT, 12, 0);
				desc.set(JAVA_INT, 16, 0);
				desc.set(JAVA_INT, 20, 0);
				MemorySegment out = arena.allocate(ADDRESS);
				D3D11Com.checkHr(context.createBuffer(desc, MemorySegment.NULL, out), "CreateBuffer(flip blit constants)");
				cb = out.get(ADDRESS, 0).reinterpret(8);
			}
			DirectGraphix.LOGGER.info("[DirectGraphix] Present flip-blit shader ready");
			return new D3D11FlipBlit(context, vs.shader(), ps.shader(), cb);
		} catch (Throwable throwable) {
			DirectGraphix.LOGGER.warn("[DirectGraphix] Present flip-blit shader could not be created, using row copy fallback", throwable);
			return null;
		}
	}

	/** @return true basariliysa; false ise cagiran yedek yontemi (satir satir kopyalama) kullanmali. */
	boolean blit(MemorySegment sourceSrv, MemorySegment targetRtv, int width, int height) {
		MemorySegment ctx = this.context.immediateContext;
		try (Arena arena = Arena.ofConfined()) {
			if (height != this.lastCopyHeight) {
				MemorySegment data = arena.allocate(16, 16);
				data.set(JAVA_INT, 0, height);
				this.context.updateSubresource(this.constantBuffer, 0, MemorySegment.NULL, data, 0, 0);
				this.lastCopyHeight = height;
			}

			MemorySegment rtvArray = arena.allocate(ADDRESS);
			rtvArray.set(ADDRESS, 0, targetRtv);
			this.omSetRenderTargets.invokeExact(ctx, 1, rtvArray, MemorySegment.NULL);

			MemorySegment viewport = arena.allocate(24, 4);
			viewport.set(JAVA_FLOAT, 0, 0.0f);
			viewport.set(JAVA_FLOAT, 4, 0.0f);
			viewport.set(JAVA_FLOAT, 8, (float) width);
			viewport.set(JAVA_FLOAT, 12, (float) height);
			viewport.set(JAVA_FLOAT, 16, 0.0f);
			viewport.set(JAVA_FLOAT, 20, 1.0f);
			this.rsSetViewports.invokeExact(ctx, 1, viewport);

			MemorySegment scissor = arena.allocate(16, 4);
			scissor.set(JAVA_INT, 0, 0);
			scissor.set(JAVA_INT, 4, 0);
			scissor.set(JAVA_INT, 8, width);
			scissor.set(JAVA_INT, 12, height);
			this.rsSetScissorRects.invokeExact(ctx, 1, scissor);

			MemorySegment blendFactor = arena.allocate(16, 4);
			blendFactor.set(JAVA_FLOAT, 0, 1.0f);
			blendFactor.set(JAVA_FLOAT, 4, 1.0f);
			blendFactor.set(JAVA_FLOAT, 8, 1.0f);
			blendFactor.set(JAVA_FLOAT, 12, 1.0f);

			this.rsSetState.invokeExact(ctx, MemorySegment.NULL);
			this.omSetBlendState.invokeExact(ctx, MemorySegment.NULL, blendFactor, 0xFFFFFFFF);
			this.omSetDepthStencilState.invokeExact(ctx, MemorySegment.NULL, 0);
			this.iaSetInputLayout.invokeExact(ctx, MemorySegment.NULL);
			this.iaSetPrimitiveTopology.invokeExact(ctx, 4); // D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST
			this.vsSetShader.invokeExact(ctx, this.vertexShader, MemorySegment.NULL, 0);
			this.psSetShader.invokeExact(ctx, this.pixelShader, MemorySegment.NULL, 0);

			MemorySegment cbArray = arena.allocate(ADDRESS);
			cbArray.set(ADDRESS, 0, this.constantBuffer);
			this.psSetConstantBuffers.invokeExact(ctx, 0, 1, cbArray);

			MemorySegment srvArray = arena.allocate(ADDRESS);
			srvArray.set(ADDRESS, 0, sourceSrv);
			this.psSetShaderResources.invokeExact(ctx, 0, 1, srvArray);

			this.draw.invokeExact(ctx, 3, 0);

			srvArray.set(ADDRESS, 0, MemorySegment.NULL);
			this.psSetShaderResources.invokeExact(ctx, 0, 1, srvArray);
			return true;
		} catch (Throwable throwable) {
			if (!this.warned) {
				this.warned = true;
				DirectGraphix.LOGGER.warn("[DirectGraphix] Present flip-blit failed, using row copy fallback", throwable);
			}
			return false;
		}
	}

	void close() {
		D3D11Com.release(this.vertexShader);
		D3D11Com.release(this.pixelShader);
		D3D11Com.release(this.constantBuffer);
	}
}
