package com.directx.client.d3d11;

import com.mojang.renderpearl.api.buffers.GpuBuffer;
import com.mojang.renderpearl.api.buffers.GpuBufferSlice;
import com.mojang.renderpearl.api.buffers.TransientMemory;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

/**
 * CPU-visible transient uploads for the D3D11 backend.
 *
 * The second argument of uploadStaging/uploadGpu is an alignment, not a byte
 * count. The old implementation treated it as the allocation size; calls such
 * as uploadStaging(pixels, 1, USAGE_COPY_SRC) therefore returned a 1-byte slice.
 */
public final class D3D11TransientMemory implements TransientMemory {
    private final D3D11Context context;

    public D3D11TransientMemory(D3D11Context context) {
        this.context = context;
    }

    private static long alignUp(long value, long alignment) {
        long a = Math.max(1L, alignment);
        long remainder = value % a;
        if (remainder == 0L) {
            return value;
        }
        return Math.addExact(value, a - remainder);
    }

    private static int checkedCapacity(long size) {
        if (size < 0L || size > Integer.MAX_VALUE - 16L) {
            throw new IllegalArgumentException("Transient allocation is too large: " + size);
        }
        return (int) Math.max(1L, size);
    }

    private GpuBufferSlice makeSlice(long size, int usage) {
        long allocationSize = Math.max(1L, size);
        D3D11GpuBuffer buffer = D3D11GpuBuffer.create(
            this.context,
            "directgraphix-transient-gpu",
            usage | GpuBuffer.USAGE_COPY_DST,
            allocationSize,
            null
        );
        return buffer.slice(0L, allocationSize);
    }

    @Override
    public ByteBuffer allocateCpu(long size, long alignment) {
        return ByteBuffer.allocateDirect(checkedCapacity(size));
    }

    @Override
    public ByteBuffer allocateCpu(long size, long alignment, long padding, long something) {
        return ByteBuffer.allocateDirect(checkedCapacity(Math.addExact(size, padding)));
    }

    @Override
    public GpuBufferSlice.MappedView allocateStaging(long size, long alignment, int usage) {
        return allocateStaging(size, alignment, usage, size, 1L);
    }

    @Override
    public GpuBufferSlice.MappedView allocateStaging(long size, long alignment, int usage, long minimumAllocation, long elementSize) {
        long allocationSize = Math.max(Math.max(1L, size), minimumAllocation);
        checkedCapacity(allocationSize);
        D3D11GpuBuffer buffer = D3D11GpuBuffer.create(
            this.context,
            "directgraphix-staging-upload",
            usage | GpuBuffer.USAGE_MAP_WRITE,
            allocationSize,
            null
        );
        return buffer.map(0L, allocationSize, false, true);
    }

    @Override
    public GpuBufferSlice allocateGpu(long size, long alignment, int usage) {
        return allocateGpu(size, alignment, usage, size, 1L);
    }

    @Override
    public GpuBufferSlice allocateGpu(long size, long alignment, int usage, long minimumAllocation, long elementSize) {
        return makeSlice(Math.max(size, minimumAllocation), usage);
    }

    @Override
    public GpuBufferSlice.MappedView allocateGpuMapped(long size, long alignment, int usage) {
        return allocateGpuMapped(size, alignment, usage, size, 1L);
    }

    @Override
    public GpuBufferSlice.MappedView allocateGpuMapped(long size, long alignment, int usage, long minimumAllocation, long elementSize) {
        long allocationSize = Math.max(Math.max(1L, size), minimumAllocation);
        checkedCapacity(allocationSize);
        D3D11GpuBuffer buffer = D3D11GpuBuffer.create(
            this.context,
            "directgraphix-gpu-upload",
            usage | GpuBuffer.USAGE_MAP_WRITE,
            allocationSize,
            null
        );
        return buffer.map(0L, allocationSize, false, true);
    }

    @Override
    public GpuBufferSlice uploadStaging(ByteBuffer data, long alignment, int usage) {
        return uploadStaging(List.of(data), alignment, usage, data.remaining(), 1L);
    }

    @Override
    public GpuBufferSlice uploadStaging(ByteBuffer data, long alignment, int usage, long minimumAllocation, long elementSize) {
        return uploadStaging(List.of(data), alignment, usage, minimumAllocation, elementSize);
    }

    @Override
    public GpuBufferSlice uploadStaging(List<ByteBuffer> data, long alignment, int usage) {
        long total = totalSize(data, alignment);
        return uploadStaging(data, alignment, usage, total, 1L);
    }

    @Override
    public GpuBufferSlice uploadStaging(List<ByteBuffer> data, long alignment, int usage, long minimumAllocation, long elementSize) {
        long totalSize = totalSize(data, alignment);
        long allocationSize = Math.max(totalSize, minimumAllocation);
        try (GpuBufferSlice.MappedView mapped = allocateStaging(allocationSize, alignment, usage, allocationSize, elementSize)) {
            copyIntoMapped(data, alignment, mapped.data());
            return mapped.slice();
        }
    }

    @Override
    public GpuBufferSlice uploadGpu(ByteBuffer data, long alignment, int usage) {
        return uploadGpu(List.of(data), alignment, usage, data.remaining(), 1L);
    }

    @Override
    public GpuBufferSlice uploadGpu(ByteBuffer data, long alignment, int usage, long minimumAllocation, long elementSize) {
        return uploadGpu(List.of(data), alignment, usage, minimumAllocation, elementSize);
    }

    @Override
    public GpuBufferSlice uploadGpu(List<ByteBuffer> data, long alignment, int usage) {
        long total = totalSize(data, alignment);
        return uploadGpu(data, alignment, usage, total, 1L);
    }

    @Override
    public GpuBufferSlice uploadGpu(List<ByteBuffer> data, long alignment, int usage, long minimumAllocation, long elementSize) {
        long totalSize = totalSize(data, alignment);
        long allocationSize = Math.max(totalSize, minimumAllocation);
        try (GpuBufferSlice.MappedView mapped = allocateGpuMapped(allocationSize, alignment, usage, allocationSize, elementSize)) {
            copyIntoMapped(data, alignment, mapped.data());
            return mapped.slice();
        }
    }

    @Override
    public List<GpuBufferSlice> multiUploadStaging(List<ByteBuffer> data, long alignment, int usage) {
        List<GpuBufferSlice> result = new ArrayList<>(data.size());
        for (ByteBuffer buffer : data) {
            result.add(uploadStaging(buffer, alignment, usage));
        }
        return result;
    }

    @Override
    public List<GpuBufferSlice> multiUploadGpu(List<ByteBuffer> data, long alignment, int usage) {
        List<GpuBufferSlice> result = new ArrayList<>(data.size());
        for (ByteBuffer buffer : data) {
            result.add(uploadGpu(buffer, alignment, usage));
        }
        return result;
    }

    private static long totalSize(List<ByteBuffer> data, long alignment) {
        long offset = 0L;
        for (ByteBuffer buffer : data) {
            offset = alignUp(offset, alignment);
            offset = Math.addExact(offset, buffer.remaining());
        }
        return offset;
    }

    private static void copyIntoMapped(List<ByteBuffer> sources, long alignment, ByteBuffer destination) {
        long offset = 0L;
        for (ByteBuffer source : sources) {
            offset = alignUp(offset, alignment);
            ByteBuffer src = source.duplicate();
            int length = src.remaining();
            if (offset + length > destination.capacity()) {
                throw new IllegalArgumentException(
                    "Transient upload exceeds mapped allocation: end=" + (offset + length)
                        + ", capacity=" + destination.capacity()
                );
            }
            ByteBuffer dst = destination.duplicate();
            dst.position(Math.toIntExact(offset));
            dst.put(src);
            offset += length;
        }
    }
}
