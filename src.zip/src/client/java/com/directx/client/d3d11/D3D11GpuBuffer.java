package com.directx.client.d3d11;

import static java.lang.foreign.ValueLayout.ADDRESS;
import static java.lang.foreign.ValueLayout.JAVA_INT;

import com.mojang.renderpearl.api.buffers.GpuBuffer;
import com.mojang.renderpearl.api.buffers.GpuBufferSlice;
import com.mojang.renderpearl.backend.common.BaseGpuBuffer;
import java.lang.foreign.Arena;
import java.lang.foreign.MemorySegment;
import java.nio.ByteBuffer;
import org.jspecify.annotations.Nullable;
import org.lwjgl.system.MemoryUtil;

/**
 * D3D11 buffer'i. GPU tarafinda DEFAULT usage bir ID3D11Buffer, map edilebilir buffer'larda ek olarak
 * CPU'da bir golge kopya tutar. map() golge kopyayi verir, degisen kisim isaretlenir ve buffer
 * kullanilmadan hemen once (checkCanBeUsed) GPU'ya yuklenir.
 */
public class D3D11GpuBuffer extends BaseGpuBuffer {
	private static final int BIND_VERTEX_BUFFER = 0x1;
	private static final int BIND_INDEX_BUFFER = 0x2;
	private static final int BIND_CONSTANT_BUFFER = 0x4;
	private static final int BIND_SHADER_RESOURCE = 0x8;
	private static final int MISC_DRAWINDIRECT_ARGS = 0x10;

	private final D3D11Context context;
	private final MemorySegment resource;
	private final int byteWidth;
	private final boolean constantBuffer;
	private final @Nullable ByteBuffer shadow;
	private boolean closed;
	private int mappingRefCount;
	private long dirtyStart = Long.MAX_VALUE;
	private long dirtyEnd = 0L;

	private D3D11GpuBuffer(
		D3D11Context context,
		int usage,
		long size,
		MemorySegment resource,
		int byteWidth,
		boolean constantBuffer,
		@Nullable ByteBuffer shadow
	) {
		super(usage, size);
		this.context = context;
		this.resource = resource;
		this.byteWidth = byteWidth;
		this.constantBuffer = constantBuffer;
		this.shadow = shadow;
	}

	public static D3D11GpuBuffer create(
		D3D11Context context,
		@Nullable String label,
		int usage,
		long size,
		@Nullable ByteBuffer initialData
	) {
		if (size <= 0L || size > Integer.MAX_VALUE - 16L) {
			throw new IllegalArgumentException("Unsupported buffer size " + size + " for buffer '" + label + "'");
		}

		// D3D11'de constant buffer boyutu 16 baytin kati olmali, hepsini 16'ya yuvarliyoruz.
		int byteWidth = (int) ((size + 15L) & ~15L);

		int bindFlags = 0;
		int miscFlags = 0;
		if ((usage & GpuBuffer.USAGE_VERTEX) != 0) {
			bindFlags |= BIND_VERTEX_BUFFER;
		}
		if ((usage & GpuBuffer.USAGE_INDEX) != 0) {
			bindFlags |= BIND_INDEX_BUFFER;
		}
		if ((usage & GpuBuffer.USAGE_UNIFORM) != 0) {
			bindFlags |= BIND_CONSTANT_BUFFER;
		}
		if ((usage & GpuBuffer.USAGE_UNIFORM_TEXEL_BUFFER) != 0) {
			bindFlags |= BIND_SHADER_RESOURCE;
		}
		if ((usage & GpuBuffer.USAGE_INDIRECT_PARAMETERS) != 0) {
			miscFlags |= MISC_DRAWINDIRECT_ARGS;
		}

		int initialLength = 0;
		if (initialData != null) {
			initialLength = initialData.remaining();
			if (initialLength > size) {
				throw new IllegalArgumentException("Initial data (" + initialLength + " bytes) is larger than buffer size (" + size + ")");
			}
		}

		MemorySegment resource;
		try (Arena arena = Arena.ofConfined()) {
			// D3D11_BUFFER_DESC: ByteWidth, Usage(DEFAULT=0), BindFlags, CPUAccessFlags, MiscFlags, StructureByteStride
			MemorySegment desc = arena.allocate(24, 4);
			desc.set(JAVA_INT, 0, byteWidth);
			desc.set(JAVA_INT, 4, 0);
			desc.set(JAVA_INT, 8, bindFlags);
			desc.set(JAVA_INT, 12, 0);
			desc.set(JAVA_INT, 16, miscFlags);
			desc.set(JAVA_INT, 20, 0);

			MemorySegment initial = MemorySegment.NULL;
			if (initialData != null) {
				MemorySegment sourceCopy = arena.allocate(byteWidth, 16);
				MemorySegment.copy(MemorySegment.ofBuffer(initialData), 0L, sourceCopy, 0L, initialLength);
				// D3D11_SUBRESOURCE_DATA: pSysMem, SysMemPitch, SysMemSlicePitch
				initial = arena.allocate(16, 8);
				initial.set(ADDRESS, 0, sourceCopy);
				initial.set(JAVA_INT, 8, 0);
				initial.set(JAVA_INT, 12, 0);
			}

			MemorySegment out = arena.allocate(ADDRESS);
			int hr = context.createBuffer(desc, initial, out);
			if (hr < 0) {
				throw new IllegalStateException(
					"CreateBuffer failed for '" + label + "' (usage=" + usage + ", size=" + size + "), HRESULT = 0x" + Integer.toHexString(hr)
				);
			}

			resource = out.get(ADDRESS, 0).reinterpret(Math.max(8, byteWidth));
		}

		ByteBuffer shadow = null;
		if ((usage & (GpuBuffer.USAGE_MAP_READ | GpuBuffer.USAGE_MAP_WRITE | GpuBuffer.USAGE_UNIFORM | GpuBuffer.USAGE_COPY_SRC)) != 0) {
			shadow = MemoryUtil.memCalloc(byteWidth);
			if (initialData != null) {
				shadow.put(0, initialData, initialData.position(), initialLength);
			}
		}

		return new D3D11GpuBuffer(context, usage, size, resource, byteWidth, (usage & GpuBuffer.USAGE_UNIFORM) != 0, shadow);
	}

	public MemorySegment resource() {
		return this.resource;
	}

	/** Returns a bounded view into this buffer's CPU shadow for immediate native uploads. */
	public ByteBuffer shadowRange(long offset, int length) {
		if (this.closed) {
			throw new IllegalStateException("Buffer already closed");
		}
		if (this.shadow == null) {
			throw new IllegalStateException("Buffer has no CPU shadow; create it with USAGE_MAP_WRITE");
		}
		if (offset < 0L || length < 0 || offset + length > this.size()) {
			throw new IllegalArgumentException("Shadow range " + offset + "+" + length + " exceeds buffer size " + this.size());
		}
		return MemoryUtil.memSlice(this.shadow, Math.toIntExact(offset), length);
	}

	@Override
	public boolean isClosed() {
		return this.closed;
	}

	/** Frontend her kullanimdan once bunu cagirir, burada bekleyen degisiklikleri GPU'ya yukleriz. */
	@Override
	public void checkCanBeUsed() {
		this.flush();
	}

	@Override
	public GpuBufferSlice.MappedView map(long offset, long length, boolean read, boolean write) {
		if (this.closed) {
			throw new IllegalStateException("Buffer already closed");
		}

		if (!read && !write) {
			throw new IllegalArgumentException("At least read or write must be true");
		}

		if (read && (this.usage() & GpuBuffer.USAGE_MAP_READ) == 0) {
			throw new IllegalStateException("Buffer is not readable");
		}

		if (write && (this.usage() & GpuBuffer.USAGE_MAP_WRITE) == 0) {
			throw new IllegalStateException("Buffer is not writable");
		}

		if (this.shadow == null) {
			throw new IllegalStateException("Buffer is not mappable");
		}

		if (offset < 0L || length < 0L || offset + length > this.size()) {
			throw new IllegalArgumentException(
				"Cannot map " + length + " bytes at offset " + offset + " from a buffer of size " + this.size()
			);
		}

		this.mappingRefCount++;
		ByteBuffer data = MemoryUtil.memSlice(this.shadow, (int) offset, (int) length);
		Runnable onClose = new Runnable() {
			private boolean done;

			@Override
			public void run() {
				if (!this.done) {
					this.done = true;
					D3D11GpuBuffer.this.unmap(offset, length, write);
				}
			}
		};
		return new GpuBufferSlice.MappedView(this.slice(offset, length), data, onClose);
	}

	private void unmap(long offset, long length, boolean wrote) {
		this.mappingRefCount--;
		if (wrote) {
			this.markDirty(offset, offset + length);
		}
	}

	private void markDirty(long start, long end) {
		if (start < this.dirtyStart) {
			this.dirtyStart = start;
		}
		if (end > this.dirtyEnd) {
			this.dirtyEnd = end;
		}
	}

	/** CommandEncoder.writeToBuffer icin: veriyi buffer'in offset konumuna yazar. */
	public void writeData(long offset, ByteBuffer data) {
		int length = data.remaining();
		if (length == 0) {
			return;
		}

		if (offset < 0L || offset + length > this.size()) {
			throw new IllegalArgumentException("Write of " + length + " bytes at offset " + offset + " exceeds buffer size " + this.size());
		}

		if (this.shadow != null) {
			MemoryUtil.memSlice(this.shadow, (int) offset, length).put(data.duplicate());
			this.markDirty(offset, offset + length);
			return;
		}

		if (this.constantBuffer) {
			throw new IllegalStateException("Partial write to a constant buffer without CPU shadow is not supported");
		}

		ByteBuffer temp = MemoryUtil.memAlloc(length);
		try {
			temp.put(data.duplicate()).flip();
			this.uploadRange(offset, offset + length, MemoryUtil.memAddress(temp));
		} finally {
			MemoryUtil.memFree(temp);
		}
	}

	/** Bekleyen golge kopya degisikliklerini GPU'ya yukler. */
	public void flush() {
		if (this.shadow == null || this.dirtyStart >= this.dirtyEnd) {
			return;
		}

		long start = this.dirtyStart;
		long end = this.dirtyEnd;
		if (this.constantBuffer) {
			// Constant buffer'lara parcali guncelleme yapilamaz, hepsini yukle.
			start = 0L;
			end = this.byteWidth;
		}

		this.uploadRange(start, end, MemoryUtil.memAddress(this.shadow) + start);
		this.dirtyStart = Long.MAX_VALUE;
		this.dirtyEnd = 0L;
	}

	private void uploadRange(long start, long end, long sourceAddress) {
		try (Arena arena = Arena.ofConfined()) {
			MemorySegment box = MemorySegment.NULL;
			if (!this.constantBuffer) {
				// D3D11_BOX: left, top, front, right, bottom, back
				box = arena.allocate(24, 4);
				box.set(JAVA_INT, 0, (int) start);
				box.set(JAVA_INT, 4, 0);
				box.set(JAVA_INT, 8, 0);
				box.set(JAVA_INT, 12, (int) end);
				box.set(JAVA_INT, 16, 1);
				box.set(JAVA_INT, 20, 1);
			}

			this.context.updateSubresource(this.resource, 0, box, MemorySegment.ofAddress(sourceAddress), 0, 0);
		}
	}

	@Override
	public void close() {
		if (this.closed) {
			return;
		}

		if (this.mappingRefCount != 0) {
			throw new IllegalStateException("Attempt to close a mapped buffer");
		}

		this.closed = true;
		D3D11Com.release(this.resource);
		if (this.shadow != null) {
			MemoryUtil.memFree(this.shadow);
		}
	}
}