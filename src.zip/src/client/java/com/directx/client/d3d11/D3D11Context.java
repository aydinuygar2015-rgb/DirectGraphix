package com.directx.client.d3d11;

import static java.lang.foreign.ValueLayout.ADDRESS;
import static java.lang.foreign.ValueLayout.JAVA_BYTE;
import static java.lang.foreign.ValueLayout.JAVA_FLOAT;
import static java.lang.foreign.ValueLayout.JAVA_INT;
import static java.lang.foreign.ValueLayout.JAVA_LONG;
import static java.lang.foreign.ValueLayout.JAVA_SHORT;

import java.lang.foreign.Arena;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.Linker;
import java.lang.foreign.MemorySegment;
import java.lang.foreign.SymbolLookup;
import java.lang.invoke.MethodHandle;
import java.nio.charset.StandardCharsets;

public final class D3D11Context implements AutoCloseable {
	private static final int E_INVALIDARG = 0x80070057;
	private static final int DEVICE_CREATE_BUFFER = 3;
	private static final int CONTEXT_UPDATE_SUBRESOURCE = 48;

	public final MemorySegment device;
	public final MemorySegment immediateContext;
	public final String adapterName;
	public final int vendorId;
	public final int deviceId;
	public final long dedicatedVideoMemory;
	public final int featureLevel;

	private final MethodHandle createBufferHandle;
	private final MethodHandle updateSubresourceHandle;
	private boolean closed;

	private MemorySegment context1 = MemorySegment.NULL;
	private boolean context1Queried;

	private MemorySegment quadIndexBuffer = MemorySegment.NULL;
	private int quadIndexCapacity = 0;

	private final MemorySegment[] sliceBuffers = new MemorySegment[33];
	private final int[] sliceBufferSizes = new int[33];

	private D3D11Context(
		MemorySegment device,
		MemorySegment immediateContext,
		String adapterName,
		int vendorId,
		int deviceId,
		long dedicatedVideoMemory,
		int featureLevel
	) {
		this.device = device;
		this.immediateContext = immediateContext;
		this.adapterName = adapterName;
		this.vendorId = vendorId;
		this.deviceId = deviceId;
		this.dedicatedVideoMemory = dedicatedVideoMemory;
		this.featureLevel = featureLevel;

		for (int i = 0; i < this.sliceBuffers.length; i++) {
			this.sliceBuffers[i] = MemorySegment.NULL;
		}

		this.createBufferHandle = D3D11Com.method(
			device,
			DEVICE_CREATE_BUFFER,
			FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, ADDRESS, ADDRESS)
		);
		this.updateSubresourceHandle = D3D11Com.method(
			immediateContext,
			CONTEXT_UPDATE_SUBRESOURCE,
			FunctionDescriptor.ofVoid(ADDRESS, ADDRESS, JAVA_INT, ADDRESS, ADDRESS, JAVA_INT, JAVA_INT)
		);
	}

	public String featureLevelName() {
		return switch (this.featureLevel) {
			case 0xb100 -> "11_1";
			case 0xb000 -> "11_0";
			case 0xa100 -> "10_1";
			case 0xa000 -> "10_0";
			default -> "0x" + Integer.toHexString(this.featureLevel);
		};
	}

	public int createBuffer(MemorySegment desc, MemorySegment initialData, MemorySegment outBuffer) {
		try {
			return (int) this.createBufferHandle.invokeExact(this.device, desc, initialData, outBuffer);
		} catch (Throwable throwable) {
			throw new IllegalStateException("CreateBuffer call failed", throwable);
		}
	}

	public void updateSubresource(MemorySegment resource, int subresource, MemorySegment box, MemorySegment sourceData, int srcRowPitch, int srcDepthPitch) {
		try {
			this.updateSubresourceHandle.invokeExact(this.immediateContext, resource, subresource, box, sourceData, srcRowPitch, srcDepthPitch);
		} catch (Throwable throwable) {
			throw new IllegalStateException("UpdateSubresource call failed", throwable);
		}
	}

	private synchronized MemorySegment context1() {
		if (!this.context1Queried) {
			this.context1Queried = true;
			try (Arena arena = Arena.ofConfined()) {
				MemorySegment iid = arena.allocate(16, 4);
				iid.set(JAVA_INT, 0, 0xbb2c6faa);
				iid.set(JAVA_SHORT, 4, (short) 0xb5fb);
				iid.set(JAVA_SHORT, 6, (short) 0x4082);
				byte[] data4 = {(byte) 0x8e, 0x6b, 0x38, (byte) 0x8b, (byte) 0x8c, (byte) 0xfa, (byte) 0x90, (byte) 0xe1};
				MemorySegment.copy(data4, 0, iid, JAVA_BYTE, 8, 8);

				MemorySegment out = arena.allocate(ADDRESS);
				MethodHandle queryInterface = D3D11Com.method(this.immediateContext, 0, FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, ADDRESS));
				int hr = (int) queryInterface.invokeExact(this.immediateContext, iid, out);
				if (hr >= 0) {
					this.context1 = out.get(ADDRESS, 0).reinterpret(8);
				}
			} catch (Throwable throwable) {
				this.context1 = MemorySegment.NULL;
			}
		}
		return this.context1;
	}

	public boolean clearRenderTargetRegion(MemorySegment rtv, float r, float g, float b, float a, int x, int y, int width, int height) {
		MemorySegment c1 = this.context1();
		if (c1.address() == 0L || width <= 0 || height <= 0) {
			return false;
		}
		try (Arena arena = Arena.ofConfined()) {
			MemorySegment color = arena.allocate(16, 4);
			color.set(JAVA_FLOAT, 0, r);
			color.set(JAVA_FLOAT, 4, g);
			color.set(JAVA_FLOAT, 8, b);
			color.set(JAVA_FLOAT, 12, a);

			MemorySegment rect = arena.allocate(16, 4);
			rect.set(JAVA_INT, 0, x);
			rect.set(JAVA_INT, 4, y);
			rect.set(JAVA_INT, 8, x + width);
			rect.set(JAVA_INT, 12, y + height);

			MethodHandle clearView = D3D11Com.method(c1, 132, FunctionDescriptor.ofVoid(ADDRESS, ADDRESS, ADDRESS, ADDRESS, JAVA_INT));
			clearView.invokeExact(c1, rtv, color, rect, 1);
			return true;
		} catch (Throwable throwable) {
			return false;
		}
	}

	public MemorySegment getOrCreateQuadIndexBuffer(int quadCount) {
		if (quadCount <= this.quadIndexCapacity && this.quadIndexBuffer.address() != 0L) {
			return this.quadIndexBuffer;
		}
		int newCapacity = Math.max(256, Integer.highestOneBit(quadCount) << 1);
		int indexCount = newCapacity * 6;
		int byteWidth = indexCount * 4;

		if (this.quadIndexBuffer.address() != 0L) {
			D3D11Com.release(this.quadIndexBuffer);
			this.quadIndexBuffer = MemorySegment.NULL;
		}

		try (Arena arena = Arena.ofConfined()) {
			MemorySegment desc = arena.allocate(24, 4);
			desc.set(JAVA_INT, 0, byteWidth);
			desc.set(JAVA_INT, 4, 0);
			desc.set(JAVA_INT, 8, 0x2);
			desc.set(JAVA_INT, 12, 0);
			desc.set(JAVA_INT, 16, 0);
			desc.set(JAVA_INT, 20, 0);

			MemorySegment data = arena.allocate(byteWidth, 4);
			for (int q = 0; q < newCapacity; q++) {
				int v = q * 4;
				long off = (long) q * 24L;
				data.set(JAVA_INT, off + 0, v);
				data.set(JAVA_INT, off + 4, v + 1);
				data.set(JAVA_INT, off + 8, v + 2);
				data.set(JAVA_INT, off + 12, v + 2);
				data.set(JAVA_INT, off + 16, v + 3);
				data.set(JAVA_INT, off + 20, v);
			}

			MemorySegment initial = arena.allocate(16, 8);
			initial.set(ADDRESS, 0, data);
			initial.set(JAVA_INT, 8, 0);
			initial.set(JAVA_INT, 12, 0);

			MemorySegment out = arena.allocate(ADDRESS);
			D3D11Com.checkHr(this.createBuffer(desc, initial, out), "CreateQuadIndexBuffer");
			this.quadIndexBuffer = out.get(ADDRESS, 0).reinterpret(8);
			this.quadIndexCapacity = newCapacity;
			return this.quadIndexBuffer;
		}
	}

	public MemorySegment getOrCreateSliceConstantBuffer(int slot, int requiredBytes) {
		int alignedBytes = (requiredBytes + 15) & ~15;
		int idx = Math.max(0, Math.min(slot, this.sliceBuffers.length - 1));
		if (this.sliceBuffers[idx].address() != 0L && this.sliceBufferSizes[idx] == alignedBytes) {
			return this.sliceBuffers[idx];
		}
		if (this.sliceBuffers[idx].address() != 0L) {
			D3D11Com.release(this.sliceBuffers[idx]);
			this.sliceBuffers[idx] = MemorySegment.NULL;
		}
		try (Arena arena = Arena.ofConfined()) {
			MemorySegment desc = arena.allocate(24, 4);
			desc.set(JAVA_INT, 0, alignedBytes);
			desc.set(JAVA_INT, 4, 0);
			desc.set(JAVA_INT, 8, 0x4);
			desc.set(JAVA_INT, 12, 0);
			desc.set(JAVA_INT, 16, 0);
			desc.set(JAVA_INT, 20, 0);

			MemorySegment out = arena.allocate(ADDRESS);
			D3D11Com.checkHr(this.createBuffer(desc, MemorySegment.NULL, out), "CreateSliceConstantBuffer");
			this.sliceBuffers[idx] = out.get(ADDRESS, 0).reinterpret(8);
			this.sliceBufferSizes[idx] = alignedBytes;
			return this.sliceBuffers[idx];
		}
	}

	public static D3D11Context create() throws Throwable {
		Linker linker = Linker.nativeLinker();

		try (Arena arena = Arena.ofConfined()) {
			SymbolLookup d3d11 = SymbolLookup.libraryLookup("d3d11.dll", Arena.global());
			MethodHandle create = linker.downcallHandle(
				d3d11.find("D3D11CreateDevice").orElseThrow(),
				FunctionDescriptor.of(
					JAVA_INT,
					ADDRESS, JAVA_INT, ADDRESS, JAVA_INT, ADDRESS, JAVA_INT, JAVA_INT, ADDRESS, ADDRESS, ADDRESS
				)
			);

			MemorySegment outDevice = arena.allocate(ADDRESS);
			MemorySegment outLevel = arena.allocate(JAVA_INT);
			MemorySegment outContext = arena.allocate(ADDRESS);

			MemorySegment levelsWith111 = arena.allocateFrom(JAVA_INT, 0xb100, 0xb000, 0xa100, 0xa000);
			MemorySegment levelsWithout111 = arena.allocateFrom(JAVA_INT, 0xb000, 0xa100, 0xa000);

			int hr = (int) create.invoke(
				MemorySegment.NULL, 1, MemorySegment.NULL, 0, levelsWith111, 4, 7, outDevice, outLevel, outContext
			);
			if (hr == E_INVALIDARG) {
				hr = (int) create.invoke(
					MemorySegment.NULL, 1, MemorySegment.NULL, 0, levelsWithout111, 3, 7, outDevice, outLevel, outContext
				);
			}
			D3D11Com.checkHr(hr, "D3D11CreateDevice");

			MemorySegment device = outDevice.get(ADDRESS, 0).reinterpret(8);
			MemorySegment context = outContext.get(ADDRESS, 0).reinterpret(8);
			int featureLevel = outLevel.get(JAVA_INT, 0);

			MemorySegment dxgiDevice = MemorySegment.NULL;
			MemorySegment adapter = MemorySegment.NULL;
			boolean success = false;

			try {
				MemorySegment iid = arena.allocate(16, 4);
				iid.set(JAVA_INT, 0, 0x54ec77fa);
				iid.set(JAVA_SHORT, 4, (short) 0x1377);
				iid.set(JAVA_SHORT, 6, (short) 0x44e6);
				byte[] data4 = {(byte) 0x8c, 0x32, (byte) 0x88, (byte) 0xfd, 0x5f, 0x44, (byte) 0xc8, 0x4c};
				MemorySegment.copy(data4, 0, iid, JAVA_BYTE, 8, 8);

				MemorySegment outDxgiDevice = arena.allocate(ADDRESS);
				MethodHandle queryInterface = D3D11Com.method(device, 0, FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, ADDRESS));
				D3D11Com.checkHr((int) queryInterface.invoke(device, iid, outDxgiDevice), "QueryInterface(IDXGIDevice)");
				dxgiDevice = outDxgiDevice.get(ADDRESS, 0).reinterpret(8);

				MemorySegment outAdapter = arena.allocate(ADDRESS);
				MethodHandle getAdapter = D3D11Com.method(dxgiDevice, 7, FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS));
				D3D11Com.checkHr((int) getAdapter.invoke(dxgiDevice, outAdapter), "IDXGIDevice::GetAdapter");
				adapter = outAdapter.get(ADDRESS, 0).reinterpret(8);

				MemorySegment desc = arena.allocate(304, 8);
				MethodHandle getDesc = D3D11Com.method(adapter, 8, FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS));
				D3D11Com.checkHr((int) getDesc.invoke(adapter, desc), "IDXGIAdapter::GetDesc");

				String name = desc.getString(0, StandardCharsets.UTF_16LE);
				int vendorId = desc.get(JAVA_INT, 256);
				int deviceId = desc.get(JAVA_INT, 260);
				long dedicatedVideoMemory = desc.get(JAVA_LONG, 272);

				D3D11Context result = new D3D11Context(device, context, name, vendorId, deviceId, dedicatedVideoMemory, featureLevel);
				D3D11DebugLog.info(
					"DEVICE",
					String.format(
						"Adapter='%s' vendor=0x%x device=0x%x vram=%dMB featureLevel=%s",
						name, vendorId, deviceId, dedicatedVideoMemory / (1024L * 1024L), result.featureLevelName()
					)
				);
				success = true;
				return result;
			} finally {
				D3D11Com.release(adapter);
				D3D11Com.release(dxgiDevice);
				if (!success) {
					D3D11Com.release(context);
					D3D11Com.release(device);
				}
			}
		}
	}

	@Override
	public void close() {
		if (!this.closed) {
			this.closed = true;
			D3D11Com.release(this.quadIndexBuffer);
			D3D11Com.release(this.context1);
			for (MemorySegment sb : this.sliceBuffers) {
				D3D11Com.release(sb);
			}
			D3D11Com.release(this.immediateContext);
			D3D11Com.release(this.device);
			D3D11DebugLog.close();
		}
	}
}