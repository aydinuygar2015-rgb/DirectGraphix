package com.directx.client.d3d11;

import static java.lang.foreign.ValueLayout.ADDRESS;
import static java.lang.foreign.ValueLayout.JAVA_FLOAT;
import static java.lang.foreign.ValueLayout.JAVA_INT;
import static java.lang.foreign.ValueLayout.JAVA_LONG;

import com.directx.DirectGraphix;
import com.mojang.renderpearl.api.GpuFormat;
import com.mojang.renderpearl.api.pipeline.BindGroupLayout;
import com.mojang.renderpearl.api.pipeline.BlendEquation;
import com.mojang.renderpearl.api.pipeline.BlendFactor;
import com.mojang.renderpearl.api.pipeline.BlendFunction;
import com.mojang.renderpearl.api.pipeline.BlendOp;
import com.mojang.renderpearl.api.pipeline.ColorTargetState;
import com.mojang.renderpearl.api.pipeline.CompareOp;
import com.mojang.renderpearl.api.pipeline.DepthStencilState;
import com.mojang.renderpearl.api.pipeline.PolygonMode;
import com.mojang.renderpearl.api.pipeline.PrimitiveTopology;
import com.mojang.renderpearl.api.pipeline.UniformType;
import com.mojang.renderpearl.backend.api.BackendRenderPipeline;
import com.mojang.renderpearl.backend.api.BackendRenderPipeline.CreateInfo;
import com.mojang.renderpearl.backend.api.BackendRenderPipeline.CreateInfo.AttribBinding;
import java.lang.foreign.Arena;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.MemorySegment;
import java.lang.invoke.MethodHandle;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import org.jspecify.annotations.Nullable;

public final class D3D11RenderPipeline implements BackendRenderPipeline {
	private final D3D11Context context;
	private final MemorySegment vertexShader;
	private final MemorySegment pixelShader;
	private final MemorySegment inputLayout;
	private final MemorySegment blendState;
	private final MemorySegment depthStencilState;
	private final MemorySegment rasterizerState;
	private final CreateInfo createInfo;
	private final UniformType[] uniformTypes;
	private final @Nullable GpuFormat[] uniformFormats;
	private final int[] vsCbufferSlots;
	private final int[] psCbufferSlots;
	private final int[] vsTextureSlots;
	private final int[] psTextureSlots;
	private final int[] vsSamplerSlots;
	private final int[] psSamplerSlots;
	private final int vsPushConstantSlot;
	private final int psPushConstantSlot;
	private boolean closed;

	public D3D11RenderPipeline(
		D3D11Context context,
		D3D11Shader.Result vertexResult,
		D3D11Shader.Result pixelResult,
		CreateInfo createInfo
	) {
		this.context = context;
		this.vertexShader = vertexResult.shader();
		this.pixelShader = pixelResult.shader();
		this.createInfo = createInfo;
		this.inputLayout = createInputLayout(context, createInfo, vertexResult.bytecode(), vertexResult.bytecodeSize());
		this.blendState = createBlendState(context, createInfo);
		this.depthStencilState = createDepthStencilState(context, createInfo);
		this.rasterizerState = createRasterizerState(context, createInfo);

		List<BindGroupLayout.UniformDescription> uniforms = createInfo == null ? List.of() : createInfo.uniforms();
		int uCount = uniforms.size();
		this.uniformTypes = new UniformType[uCount];
		this.uniformFormats = new GpuFormat[uCount];
		this.vsCbufferSlots = new int[uCount];
		this.psCbufferSlots = new int[uCount];
		this.vsTextureSlots = new int[uCount];
		this.psTextureSlots = new int[uCount];
		this.vsSamplerSlots = new int[uCount];
		this.psSamplerSlots = new int[uCount];

		Set<String> declaredUniformNames = new HashSet<>();
		for (int i = 0; i < uCount; i++) {
			BindGroupLayout.UniformDescription desc = uniforms.get(i);
			String name = desc.name();
			declaredUniformNames.add(name);
			this.uniformTypes[i] = desc.type();
			this.uniformFormats[i] = desc.gpuFormat();

			this.vsCbufferSlots[i] = vertexResult.cbufferRegisters().getOrDefault(name, -1);
			this.psCbufferSlots[i] = pixelResult.cbufferRegisters().getOrDefault(name, -1);

			this.vsTextureSlots[i] = vertexResult.textureRegisters().getOrDefault(name, -1);
			this.psTextureSlots[i] = pixelResult.textureRegisters().getOrDefault(name, -1);

			this.vsSamplerSlots[i] = resolveSamplerSlot(vertexResult.samplerRegisters(), name, this.vsTextureSlots[i]);
			this.psSamplerSlots[i] = resolveSamplerSlot(pixelResult.samplerRegisters(), name, this.psTextureSlots[i]);
		}

		this.vsPushConstantSlot = findPushConstantSlot(vertexResult.cbufferRegisters(), declaredUniformNames);
		this.psPushConstantSlot = findPushConstantSlot(pixelResult.cbufferRegisters(), declaredUniformNames);

		List<String> attribLogs = new ArrayList<>();
		if (createInfo != null) {
			for (AttribBinding b : createInfo.attribBindings()) {
				attribLogs.add("loc=" + b.location() + " slot=" + b.bufferSlot() + " offset=" + b.offset() + " fmt=" + b.format());
			}
		}
		List<String> uniformLogs = new ArrayList<>();
		for (int i = 0; i < uCount; i++) {
			BindGroupLayout.UniformDescription desc = uniforms.get(i);
			uniformLogs.add(
				"idx=" + i + " name='" + desc.name() + "' type=" + desc.type()
					+ " cb(vs=" + this.vsCbufferSlots[i] + ",ps=" + this.psCbufferSlots[i] + ")"
					+ " tex(vs=" + this.vsTextureSlots[i] + ",ps=" + this.psTextureSlots[i] + ")"
					+ " samp(vs=" + this.vsSamplerSlots[i] + ",ps=" + this.psSamplerSlots[i] + ")"
			);
		}
		int[] strides = new int[4];
		for (int s = 0; s < strides.length; s++) {
			strides[s] = vertexStride(s);
		}
		D3D11DebugLog.pipeline(
			name(),
			createInfo == null ? "UNKNOWN" : createInfo.primitiveTopology().name(),
			strides,
			attribLogs,
			uniformLogs,
			this.vsPushConstantSlot,
			this.psPushConstantSlot
		);
	}

	private static int resolveSamplerSlot(Map<String, Integer> samplerRegisters, String name, int fallbackTextureSlot) {
		Integer exact = samplerRegisters.get(name);
		if (exact != null) {
			return exact;
		}
		Integer spirvCrossUnderscore = samplerRegisters.get("_" + name + "_sampler");
		if (spirvCrossUnderscore != null) {
			return spirvCrossUnderscore;
		}
		Integer spirvCrossSuffix = samplerRegisters.get(name + "Sampler");
		if (spirvCrossSuffix != null) {
			return spirvCrossSuffix;
		}
		for (Map.Entry<String, Integer> entry : samplerRegisters.entrySet()) {
			if (entry.getKey().contains(name)) {
				return entry.getValue();
			}
		}
		return fallbackTextureSlot;
	}

	private static int findPushConstantSlot(Map<String, Integer> cbufferRegisters, Set<String> declaredUniformNames) {
		for (Map.Entry<String, Integer> entry : cbufferRegisters.entrySet()) {
			if (!declaredUniformNames.contains(entry.getKey())) {
				return entry.getValue();
			}
		}
		return -1;
	}

	public MemorySegment vertexShader() { return this.vertexShader; }
	public MemorySegment pixelShader() { return this.pixelShader; }
	public MemorySegment inputLayout() { return this.inputLayout; }
	public MemorySegment blendState() { return this.blendState; }
	public MemorySegment depthStencilState() { return this.depthStencilState; }
	public MemorySegment rasterizerState() { return this.rasterizerState; }
	public String name() { return this.createInfo == null ? "unnamed" : this.createInfo.name(); }
	public int vsPushConstantSlot() { return this.vsPushConstantSlot; }
	public int psPushConstantSlot() { return this.psPushConstantSlot; }

	public UniformType uniformType(int uniformIndex) {
		if (uniformIndex >= 0 && uniformIndex < this.uniformTypes.length) {
			return this.uniformTypes[uniformIndex];
		}
		return UniformType.UNIFORM_BUFFER;
	}

	public @Nullable GpuFormat uniformFormat(int uniformIndex) {
		if (uniformIndex >= 0 && uniformIndex < this.uniformFormats.length) {
			return this.uniformFormats[uniformIndex];
		}
		return null;
	}

	public int vsCbufferSlot(int uniformIndex) {
		return uniformIndex >= 0 && uniformIndex < this.vsCbufferSlots.length ? this.vsCbufferSlots[uniformIndex] : -1;
	}

	public int psCbufferSlot(int uniformIndex) {
		return uniformIndex >= 0 && uniformIndex < this.psCbufferSlots.length ? this.psCbufferSlots[uniformIndex] : -1;
	}

	public int vsTextureSlot(int uniformIndex) {
		return uniformIndex >= 0 && uniformIndex < this.vsTextureSlots.length ? this.vsTextureSlots[uniformIndex] : -1;
	}

	public int psTextureSlot(int uniformIndex) {
		return uniformIndex >= 0 && uniformIndex < this.psTextureSlots.length ? this.psTextureSlots[uniformIndex] : -1;
	}

	public int vsSamplerSlot(int uniformIndex) {
		return uniformIndex >= 0 && uniformIndex < this.vsSamplerSlots.length ? this.vsSamplerSlots[uniformIndex] : -1;
	}

	public int psSamplerSlot(int uniformIndex) {
		return uniformIndex >= 0 && uniformIndex < this.psSamplerSlots.length ? this.psSamplerSlots[uniformIndex] : -1;
	}

	public boolean isQuadTopology() {
		return this.createInfo != null && this.createInfo.primitiveTopology() == PrimitiveTopology.QUADS;
	}

	public int vertexStride(int slot) {
		if (this.createInfo == null) return 0;
		return this.createInfo.vertexBuffers().stream()
			.filter(binding -> binding.bufferSlot() == slot)
			.mapToInt(BackendRenderPipeline.CreateInfo.VertexBuffer::stride)
			.findFirst().orElse(0);
	}

	public int nativeTopology() {
		if (this.createInfo == null) return 4;
		PrimitiveTopology topology = this.createInfo.primitiveTopology();
		return switch (topology) {
			case POINTS -> 1;
			case LINES, DEBUG_LINES -> 2;
			case DEBUG_LINE_STRIP -> 3;
			case TRIANGLE_STRIP -> 5;
			case TRIANGLES -> 4;
			case TRIANGLE_FAN -> 4;
			case QUADS -> 4;
		};
	}

	private static MemorySegment createInputLayout(D3D11Context context, CreateInfo createInfo, MemorySegment bytecode, long bytecodeSize) {
		if (createInfo == null || createInfo.attribBindings().isEmpty() || bytecode == null || bytecode.address() == 0L || bytecodeSize == 0) {
			return MemorySegment.NULL;
		}
		try (Arena arena = Arena.ofConfined()) {
			int count = createInfo.attribBindings().size();
			MemorySegment descs = arena.allocate(32L * count, 8);
			MemorySegment semanticName = arena.allocateFrom("TEXCOORD", StandardCharsets.UTF_8);

			for (int i = 0; i < count; i++) {
				AttribBinding b = createInfo.attribBindings().get(i);
				int stepRate = createInfo.vertexBuffers().stream()
					.filter(vb -> vb.bufferSlot() == b.bufferSlot())
					.mapToInt(BackendRenderPipeline.CreateInfo.VertexBuffer::stepRate)
					.findFirst()
					.orElse(0);

				long off = 32L * i;
				descs.set(ADDRESS, off + 0, semanticName);
				descs.set(JAVA_INT, off + 8, b.location());
				descs.set(JAVA_INT, off + 12, D3D11GpuTexture.dxgiFormat(b.format()));
				descs.set(JAVA_INT, off + 16, b.bufferSlot());
				descs.set(JAVA_INT, off + 20, b.offset());
				descs.set(JAVA_INT, off + 24, stepRate > 0 ? 1 : 0);
				descs.set(JAVA_INT, off + 28, stepRate);
			}

			MemorySegment outLayout = arena.allocate(ADDRESS);
			MethodHandle handle = D3D11Com.method(
				context.device,
				11,
				FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, JAVA_INT, ADDRESS, JAVA_LONG, ADDRESS)
			);
			int hr = (int) handle.invokeExact(context.device, descs, count, bytecode, bytecodeSize, outLayout);
			if (hr < 0) {
				DirectGraphix.LOGGER.error("[DirectGraphix] CreateInputLayout failed for '{}' HRESULT=0x{}", createInfo.name(), Integer.toHexString(hr));
				D3D11DebugLog.error("PIPELINE", "CreateInputLayout failed for '" + createInfo.name() + "' HRESULT=0x" + Integer.toHexString(hr), null);
				return MemorySegment.NULL;
			}
			return outLayout.get(ADDRESS, 0).reinterpret(8);
		} catch (Throwable throwable) {
			DirectGraphix.LOGGER.error("[DirectGraphix] CreateInputLayout failed", throwable);
			return MemorySegment.NULL;
		}
	}

	private static MemorySegment createBlendState(D3D11Context context, CreateInfo createInfo) {
		try (Arena arena = Arena.ofConfined()) {
			MemorySegment desc = arena.allocate(264, 4);
			desc.set(JAVA_INT, 0, 0);
			desc.set(JAVA_INT, 4, 1);

			List<ColorTargetState> targets = createInfo == null ? List.of() : createInfo.colorTargetStates();
			for (int i = 0; i < 8; i++) {
				long off = 8L + (long) i * 32L;
				ColorTargetState state = i < targets.size() ? targets.get(i) : null;
				if (state == null) {
					desc.set(JAVA_INT, off + 0, 0);
					desc.set(JAVA_INT, off + 4, 2);
					desc.set(JAVA_INT, off + 8, 1);
					desc.set(JAVA_INT, off + 12, 1);
					desc.set(JAVA_INT, off + 16, 2);
					desc.set(JAVA_INT, off + 20, 1);
					desc.set(JAVA_INT, off + 24, 1);
					desc.set(JAVA_INT, off + 28, i == 0 ? 0xF : 0);
					continue;
				}

				Optional<BlendFunction> bfOpt = state.blendFunction();
				if (bfOpt.isPresent()) {
					BlendFunction bf = bfOpt.get();
					BlendEquation color = bf.color();
					BlendEquation alpha = bf.alpha();
					desc.set(JAVA_INT, off + 0, 1);
					desc.set(JAVA_INT, off + 4, toD3DBlend(color.sourceFactor()));
					desc.set(JAVA_INT, off + 8, toD3DBlend(color.destFactor()));
					desc.set(JAVA_INT, off + 12, toD3DBlendOp(color.op()));
					desc.set(JAVA_INT, off + 16, toD3DBlend(alpha.sourceFactor()));
					desc.set(JAVA_INT, off + 20, toD3DBlend(alpha.destFactor()));
					desc.set(JAVA_INT, off + 24, toD3DBlendOp(alpha.op()));
				} else {
					desc.set(JAVA_INT, off + 0, 0);
					desc.set(JAVA_INT, off + 4, 2);
					desc.set(JAVA_INT, off + 8, 1);
					desc.set(JAVA_INT, off + 12, 1);
					desc.set(JAVA_INT, off + 16, 2);
					desc.set(JAVA_INT, off + 20, 1);
					desc.set(JAVA_INT, off + 24, 1);
				}
				desc.set(JAVA_INT, off + 28, state.writeMask() & 0xF);
			}

			MemorySegment out = arena.allocate(ADDRESS);
			MethodHandle handle = D3D11Com.method(context.device, 20, FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, ADDRESS));
			int hr = (int) handle.invokeExact(context.device, desc, out);
			D3D11Com.checkHr(hr, "CreateBlendState");
			return out.get(ADDRESS, 0).reinterpret(8);
		} catch (Throwable throwable) {
			DirectGraphix.LOGGER.error("[DirectGraphix] CreateBlendState failed", throwable);
			return MemorySegment.NULL;
		}
	}

	private static MemorySegment createDepthStencilState(D3D11Context context, CreateInfo createInfo) {
		try (Arena arena = Arena.ofConfined()) {
			MemorySegment desc = arena.allocate(52, 4);
			DepthStencilState ds = createInfo == null ? null : createInfo.depthStencilState();
			if (ds != null) {
				desc.set(JAVA_INT, 0, 1);
				desc.set(JAVA_INT, 4, ds.writeDepth() ? 1 : 0);
				desc.set(JAVA_INT, 8, toD3DCompareOp(ds.depthTest()));
			} else {
				desc.set(JAVA_INT, 0, 0);
				desc.set(JAVA_INT, 4, 0);
				desc.set(JAVA_INT, 8, 8);
			}
			desc.set(JAVA_INT, 12, 0);
			MemorySegment out = arena.allocate(ADDRESS);
			MethodHandle handle = D3D11Com.method(context.device, 21, FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, ADDRESS));
			int hr = (int) handle.invokeExact(context.device, desc, out);
			D3D11Com.checkHr(hr, "CreateDepthStencilState");
			return out.get(ADDRESS, 0).reinterpret(8);
		} catch (Throwable throwable) {
			DirectGraphix.LOGGER.error("[DirectGraphix] CreateDepthStencilState failed", throwable);
			return MemorySegment.NULL;
		}
	}

	private static MemorySegment createRasterizerState(D3D11Context context, CreateInfo createInfo) {
		try (Arena arena = Arena.ofConfined()) {
			MemorySegment desc = arena.allocate(40, 4);
			PolygonMode poly = createInfo == null ? PolygonMode.FILL : createInfo.polygonMode();
			boolean cull = createInfo != null && createInfo.cull();
			DepthStencilState ds = createInfo == null ? null : createInfo.depthStencilState();

			desc.set(JAVA_INT, 0, "WIREFRAME".equals(poly.name()) ? 2 : 3);
			desc.set(JAVA_INT, 4, cull ? 3 : 1);
			desc.set(JAVA_INT, 8, 0);
			desc.set(JAVA_INT, 12, ds != null ? (int) ds.depthBiasConstant() : 0);
			desc.set(JAVA_FLOAT, 16, 0.0f);
			desc.set(JAVA_FLOAT, 20, ds != null ? ds.depthBiasScaleFactor() : 0.0f);
			desc.set(JAVA_INT, 24, 1);
			desc.set(JAVA_INT, 28, 1);
			desc.set(JAVA_INT, 32, 0);
			desc.set(JAVA_INT, 36, 0);

			MemorySegment out = arena.allocate(ADDRESS);
			MethodHandle handle = D3D11Com.method(context.device, 22, FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, ADDRESS));
			int hr = (int) handle.invokeExact(context.device, desc, out);
			D3D11Com.checkHr(hr, "CreateRasterizerState");
			return out.get(ADDRESS, 0).reinterpret(8);
		} catch (Throwable throwable) {
			DirectGraphix.LOGGER.error("[DirectGraphix] CreateRasterizerState failed", throwable);
			return MemorySegment.NULL;
		}
	}

	private static int toD3DBlend(BlendFactor factor) {
		return switch (factor.name()) {
			case "ZERO" -> 1;
			case "ONE" -> 2;
			case "SRC_COLOR" -> 3;
			case "ONE_MINUS_SRC_COLOR" -> 4;
			case "SRC_ALPHA" -> 5;
			case "ONE_MINUS_SRC_ALPHA" -> 6;
			case "DST_ALPHA", "DEST_ALPHA" -> 7;
			case "ONE_MINUS_DST_ALPHA", "ONE_MINUS_DEST_ALPHA" -> 8;
			case "DST_COLOR", "DEST_COLOR" -> 9;
			case "ONE_MINUS_DST_COLOR", "ONE_MINUS_DEST_COLOR" -> 10;
			case "SRC_ALPHA_SATURATE" -> 11;
			case "CONSTANT_COLOR", "CONSTANT_ALPHA" -> 14;
			case "ONE_MINUS_CONSTANT_COLOR", "ONE_MINUS_CONSTANT_ALPHA" -> 15;
			default -> 2;
		};
	}

	private static int toD3DBlendOp(BlendOp op) {
		return switch (op.name()) {
			case "ADD" -> 1;
			case "SUBTRACT" -> 2;
			case "REVERSE_SUBTRACT", "REV_SUBTRACT" -> 3;
			case "MIN" -> 4;
			case "MAX" -> 5;
			default -> 1;
		};
	}

	private static int toD3DCompareOp(CompareOp op) {
		return switch (op.name()) {
			case "NEVER" -> 1;
			case "LESS" -> 2;
			case "EQUAL" -> 3;
			case "LESS_THAN_OR_EQUAL", "LESS_OR_EQUAL" -> 4;
			case "GREATER" -> 5;
			case "NOT_EQUAL" -> 6;
			case "GREATER_THAN_OR_EQUAL", "GREATER_OR_EQUAL" -> 7;
			case "ALWAYS" -> 8;
			default -> 8;
		};
	}

	@Override
	public boolean isClosed() {
		return this.closed;
	}

	@Override
	public void close() {
		if (this.closed) {
			return;
		}
		this.closed = true;
		D3D11Com.release(this.vertexShader);
		D3D11Com.release(this.pixelShader);
		D3D11Com.release(this.inputLayout);
		D3D11Com.release(this.blendState);
		D3D11Com.release(this.depthStencilState);
		D3D11Com.release(this.rasterizerState);
	}
}