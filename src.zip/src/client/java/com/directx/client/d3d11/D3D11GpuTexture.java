package com.directx.client.d3d11;

import static java.lang.foreign.ValueLayout.ADDRESS;
import static java.lang.foreign.ValueLayout.JAVA_INT;

import com.mojang.renderpearl.api.GpuFormat;
import com.mojang.renderpearl.api.textures.GpuTexture;
import com.mojang.renderpearl.backend.common.BaseGpuTexture;
import java.lang.foreign.Arena;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.MemorySegment;
import java.lang.invoke.MethodHandle;
import org.jspecify.annotations.Nullable;

public class D3D11GpuTexture extends BaseGpuTexture implements GpuTexture {
	public static final int D3D11_BIND_SHADER_RESOURCE = 0x8;
	public static final int D3D11_BIND_RENDER_TARGET = 0x20;
	public static final int D3D11_BIND_DEPTH_STENCIL = 0x40;
	public static final int D3D11_RESOURCE_MISC_GENERATE_MIPS = 0x1;
	public static final int D3D11_RESOURCE_MISC_TEXTURECUBE = 0x4;

	private static final int DEVICE_CREATE_TEXTURE2D = 5;

	private final D3D11Context context;
	private final MemorySegment resource;
	private final int nativeDxgiFormat;
	private final int bindFlags;
	private final int miscFlags;
	private final boolean cubemap;
	private boolean closed;

	public D3D11GpuTexture(
		D3D11Context context,
		int usage,
		@Nullable String label,
		GpuFormat format,
		int width,
		int height,
		int depthOrLayers,
		int mipLevels,
		MemorySegment resource,
		int nativeDxgiFormat,
		int bindFlags,
		int miscFlags,
		boolean cubemap
	) {
		super(usage, label == null ? "" : label, format, width, height, depthOrLayers, mipLevels);
		this.context = context;
		this.resource = resource;
		this.nativeDxgiFormat = nativeDxgiFormat;
		this.bindFlags = bindFlags;
		this.miscFlags = miscFlags;
		this.cubemap = cubemap;
	}

	public static D3D11GpuTexture create(
		D3D11Context context,
		@Nullable String label,
		int usage,
		GpuFormat format,
		int width,
		int height,
		int depthOrLayers,
		int mipLevels
	) {
		if (width <= 0 || height <= 0) {
			throw new IllegalArgumentException("Invalid texture dimensions " + width + "x" + height);
		}
		int maxPossibleMips = 32 - Integer.numberOfLeadingZeros(Math.max(width, height));
		int levels = mipLevels <= 0 ? 1 : Math.min(mipLevels, maxPossibleMips);
		int arraySize = depthOrLayers <= 0 ? 1 : depthOrLayers;

		boolean hasDepth = format.hasDepthAspect();
		boolean needsSrv = (usage & GpuTexture.USAGE_TEXTURE_BINDING) != 0;
		boolean needsRenderTarget = (usage & GpuTexture.USAGE_RENDER_ATTACHMENT) != 0;
		boolean isCubemap = !hasDepth && ((usage & GpuTexture.USAGE_CUBEMAP_COMPATIBLE) != 0) && arraySize >= 6;

		int nativeFormat = (hasDepth && needsSrv) ? typelessDepthFormat(format) : dxgiFormat(format);

		int bindFlags = 0;
		if (hasDepth) {
			bindFlags |= D3D11_BIND_DEPTH_STENCIL;
			if (needsSrv) {
				bindFlags |= D3D11_BIND_SHADER_RESOURCE;
			}
		} else {
			if (needsSrv || !needsRenderTarget) {
				bindFlags |= D3D11_BIND_SHADER_RESOURCE;
			}
			if (needsRenderTarget) {
				bindFlags |= D3D11_BIND_RENDER_TARGET;
			}
		}

		int miscFlags = 0;
		if (isCubemap) {
			miscFlags |= D3D11_RESOURCE_MISC_TEXTURECUBE;
		}

		MemorySegment resource;
		try (Arena arena = Arena.ofConfined()) {
			// D3D11_TEXTURE2D_DESC (44 bayt)
			MemorySegment desc = arena.allocate(44, 4);
			desc.set(JAVA_INT, 0, width);
			desc.set(JAVA_INT, 4, height);
			desc.set(JAVA_INT, 8, levels);
			desc.set(JAVA_INT, 12, arraySize);
			desc.set(JAVA_INT, 16, nativeFormat);
			desc.set(JAVA_INT, 20, 1); // SampleDesc.Count
			desc.set(JAVA_INT, 24, 0); // SampleDesc.Quality
			desc.set(JAVA_INT, 28, 0); // D3D11_USAGE_DEFAULT
			desc.set(JAVA_INT, 32, bindFlags);
			desc.set(JAVA_INT, 36, 0); // CPUAccessFlags
			desc.set(JAVA_INT, 40, miscFlags);

			MemorySegment initialData = MemorySegment.NULL;
			int pixelStride = storageBytesPerPixel(format);
			int totalSubresources = levels * arraySize;
			if (!hasDepth && pixelStride > 0 && totalSubresources <= 2048) {
				long maxMipBytes = (long) width * height * pixelStride;
				if (maxMipBytes > 0 && maxMipBytes <= 64L * 1024L * 1024L) {
					// Tum mip seviyeleri icin sifirlanmis tek bir ortak tampon yeterli (subresource'lar okuyarak baslar)
					MemorySegment zeroBuffer = arena.allocate(maxMipBytes, 16);
					initialData = arena.allocate(16L * totalSubresources, 8);
					for (int slice = 0; slice < arraySize; slice++) {
						for (int mip = 0; mip < levels; mip++) {
							int mipW = Math.max(1, width >> mip);
							int rowPitch = mipW * pixelStride;
							int subIdx = mip + slice * levels;
							long entryOffset = 16L * subIdx;
							initialData.set(ADDRESS, entryOffset + 0, zeroBuffer);
							initialData.set(JAVA_INT, entryOffset + 8, rowPitch);
							initialData.set(JAVA_INT, entryOffset + 12, 0);
						}
					}
				}
			}

			MemorySegment out = arena.allocate(ADDRESS);
			MethodHandle handle = D3D11Com.method(
				context.device,
				DEVICE_CREATE_TEXTURE2D,
				FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, ADDRESS, ADDRESS)
			);
			int hr = (int) handle.invokeExact(context.device, desc, initialData, out);
			if (hr < 0) {
				throw new IllegalStateException(
					"CreateTexture2D failed for '" + label + "', HRESULT=0x" + Integer.toHexString(hr)
						+ " (fmt=" + format + " -> dxgi=" + nativeFormat + ", bind=0x" + Integer.toHexString(bindFlags)
						+ ", " + width + "x" + height + ", levels=" + levels + ", array=" + arraySize + ")"
				);
			}
			resource = out.get(ADDRESS, 0).reinterpret(44);
		} catch (Throwable throwable) {
			throw new IllegalStateException("Failed to create D3D11 texture '" + label + "'", throwable);
		}

		D3D11DebugLog.texture(label, format.name(), nativeFormat, width, height, arraySize, levels, usage, bindFlags);
		return new D3D11GpuTexture(
			context,
			usage,
			label,
			format,
			width,
			height,
			arraySize,
			levels,
			resource,
			nativeFormat,
			bindFlags,
			miscFlags,
			isCubemap
		);
	}

	public MemorySegment resource() {
		return this.resource;
	}

	public int nativeDxgiFormat() {
		return this.nativeDxgiFormat;
	}

	public int bindFlags() {
		return this.bindFlags;
	}

	public int miscFlags() {
		return this.miscFlags;
	}

	public boolean isCubemap() {
		return this.cubemap;
	}

	public int subresourceIndex(int mipLevel, int arraySlice) {
		return mipLevel + arraySlice * this.getMipLevels();
	}

	public static int storageBytesPerPixel(GpuFormat format) {
		if (isRgb8(format)) {
			return 4;
		}
		if (isRgb16(format)) {
			return 8;
		}
		return Math.max(0, format.blockSize());
	}

	public static boolean isRgb8(GpuFormat format) {
		return format == GpuFormat.RGB8_UNORM
			|| format == GpuFormat.RGB8_SNORM
			|| format == GpuFormat.RGB8_UINT
			|| format == GpuFormat.RGB8_SINT;
	}

	public static boolean isRgb16(GpuFormat format) {
		return format == GpuFormat.RGB16_UNORM
			|| format == GpuFormat.RGB16_SNORM
			|| format == GpuFormat.RGB16_UINT
			|| format == GpuFormat.RGB16_SINT
			|| format == GpuFormat.RGB16_FLOAT;
	}

	public static int typelessDepthFormat(GpuFormat format) {
		return switch (format) {
			case D32_FLOAT -> 39;          // DXGI_FORMAT_R32_TYPELESS
			case D16_UNORM -> 53;          // DXGI_FORMAT_R16_TYPELESS
			case D24_UNORM_S8_UINT -> 44;  // DXGI_FORMAT_R24G8_TYPELESS
			case D32_FLOAT_S8_UINT -> 19;  // DXGI_FORMAT_R32G8X24_TYPELESS
			default -> dxgiFormat(format);
		};
	}

	public static int depthSrvFormat(GpuFormat format) {
		return switch (format) {
			case D32_FLOAT -> 41;          // DXGI_FORMAT_R32_FLOAT
			case D16_UNORM -> 56;          // DXGI_FORMAT_R16_UNORM
			case D24_UNORM_S8_UINT -> 46;  // DXGI_FORMAT_R24_UNORM_X8_TYPELESS
			case D32_FLOAT_S8_UINT -> 21;  // DXGI_FORMAT_R32_FLOAT_X8X24_TYPELESS
			default -> dxgiFormat(format);
		};
	}

	public static int dxgiFormat(GpuFormat format) {
		return switch (format) {
			case R8_UNORM -> 61;
			case R8_SNORM -> 63;
			case R8_UINT -> 62;
			case R8_SINT -> 64;
			case RG8_UNORM -> 49;
			case RG8_SNORM -> 51;
			case RG8_UINT -> 50;
			case RG8_SINT -> 52;
			case RGBA8_UNORM -> 28;
			case RGBA8_SNORM -> 31;
			case RGBA8_UINT -> 30;
			case RGBA8_SINT -> 32;
			case RGB8_UNORM -> 28;
			case RGB8_SNORM -> 31;
			case RGB8_UINT -> 30;
			case RGB8_SINT -> 32;
			case R16_UNORM -> 56;
			case R16_SNORM -> 58;
			case R16_UINT -> 57;
			case R16_SINT -> 59;
			case R16_FLOAT -> 54;
			case RG16_UNORM -> 35;
			case RG16_SNORM -> 37;
			case RG16_UINT -> 36;
			case RG16_SINT -> 38;
			case RG16_FLOAT -> 34;
			case RGBA16_UNORM -> 11;
			case RGBA16_SNORM -> 13;
			case RGBA16_UINT -> 12;
			case RGBA16_SINT -> 14;
			case RGBA16_FLOAT -> 10;
			case RGB16_UNORM, RGB16_SNORM, RGB16_UINT, RGB16_SINT, RGB16_FLOAT -> 10;
			case R32_UINT -> 42;
			case R32_SINT -> 43;
			case R32_FLOAT -> 41;
			case RG32_UINT -> 17;
			case RG32_SINT -> 18;
			case RG32_FLOAT -> 16;
			case RGB32_FLOAT -> 6;
			case RGB32_UINT -> 7;
			case RGB32_SINT -> 8;
			case RGBA32_UINT -> 3;
			case RGBA32_SINT -> 4;
			case RGBA32_FLOAT -> 2;
			case RGB10A2_UNORM -> 24;
			case RGB10A2_UINT -> 25;
			case RG11B10_FLOAT -> 26;
			case D32_FLOAT -> 40;
			case D16_UNORM -> 55;
			case D24_UNORM_S8_UINT -> 45;
			case D32_FLOAT_S8_UINT -> 20;
			case S8_UINT -> 60;
			default -> throw new UnsupportedOperationException("Unsupported GpuFormat for D3D11: " + format);
		};
	}

	@Override
	public boolean isClosed() {
		return this.closed;
	}

	@Override
	public void close() {
		if (this.closed) {
			return;
		}
		this.closed = true;
		D3D11Com.release(this.resource);
	}
}