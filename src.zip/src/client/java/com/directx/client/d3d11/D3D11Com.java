package com.directx.client.d3d11;

import static java.lang.foreign.ValueLayout.ADDRESS;
import static java.lang.foreign.ValueLayout.JAVA_INT;

import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.Linker;
import java.lang.foreign.MemorySegment;
import java.lang.invoke.MethodHandle;

/** COM nesneleri icin kucuk yardimci metotlar (vtable cagrisi, Release, HRESULT kontrolu). */
public final class D3D11Com {
	private D3D11Com() {
	}

	/** COM nesnesinin vtable'indan index'inci metodu alip FFM downcall handle'a cevirir. */
	public static MethodHandle method(MemorySegment comObject, int index, FunctionDescriptor descriptor) {
		if (comObject == null || comObject.address() == 0L) {
			throw new IllegalStateException("COM object is NULL (vtable index " + index + ")");
		}

		MemorySegment vtable = comObject.reinterpret(8).get(ADDRESS, 0);
		if (vtable.address() == 0L) {
			throw new IllegalStateException("COM object has a NULL vtable (vtable index " + index + "), object was probably corrupted");
		}

		MemorySegment function = vtable.reinterpret((long) (index + 1) * 8).get(ADDRESS, (long) index * 8);
		return Linker.nativeLinker().downcallHandle(function, descriptor);
	}

	/** IUnknown::Release = vtable index 2 */
	public static void release(MemorySegment comObject) {
		if (comObject == null || comObject.address() == 0L) {
			return;
		}

		try {
			MethodHandle releaseMethod = method(comObject, 2, FunctionDescriptor.of(JAVA_INT, ADDRESS));
			int ignored = (int) releaseMethod.invoke(comObject);
		} catch (Throwable ignored) {
		}
	}

	public static void checkHr(int hr, String what) {
		if (hr < 0) {
			throw new IllegalStateException(what + " failed, HRESULT = 0x" + Integer.toHexString(hr));
		}
	}
}