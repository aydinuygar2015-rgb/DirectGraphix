package com.directx.client.d3d11;

import static java.lang.foreign.ValueLayout.ADDRESS;
import static java.lang.foreign.ValueLayout.JAVA_INT;

import com.directx.DirectGraphix;
import com.mojang.renderpearl.api.textures.GpuTexture;
import com.mojang.renderpearl.api.textures.GpuTextureView;
import com.mojang.renderpearl.backend.common.BaseGpuTextureView;
import java.lang.foreign.Arena;
import java.lang.foreign.FunctionDescriptor;
import java.lang.foreign.MemorySegment;
import java.lang.invoke.MethodHandle;

public class D3D11GpuTextureView extends BaseGpuTextureView implements GpuTextureView {
	private static final int DEVICE_CREATE_SHADER_RESOURCE_VIEW = 7;
	private static final int D3D11_SRV_DIMENSION_TEXTURE2D = 4;
	private static final int D3D11_SRV_DIMENSION_TEXTURE2DARRAY = 5;
	private static final int D3D11_SRV_DIMENSION_TEXTURECUBE = 6;

	private final D3D11Context context;
	private final MemorySegment resource;
	private boolean closed;

	public D3D11GpuTextureView(
		GpuTexture texture,
		int baseMipLevel,
		int mipLevels,
		D3D11Context context,
		MemorySegment resource
	) {
		super(texture, baseMipLevel, mipLevels);
		this.context = context;
		this.resource = resource;
	}

	public static D3D11GpuTextureView create(D3D11Context context, GpuTexture texture, int baseMipLevel, int mipLevels) {
		D3D11GpuTexture d3dTexture = (D3D11GpuTexture) texture;
		MemorySegment textureResource = d3dTexture.resource();

		boolean hasDepth = texture.getFormat().hasDepthAspect();
		boolean canBindSrv = (d3dTexture.bindFlags() & D3D11GpuTexture.D3D11_BIND_SHADER_RESOURCE) != 0;

		if (!canBindSrv || textureResource.address() == 0L) {
			return new D3D11GpuTextureView(texture, baseMipLevel, mipLevels, context, MemorySegment.NULL);
		}

		int totalMips = Math.max(1, texture.getMipLevels());
		int clampedBase = Math.max(0, Math.min(baseMipLevel, totalMips - 1));
		int clampedLevels = mipLevels <= 0 ? (totalMips - clampedBase) : Math.min(mipLevels, totalMips - clampedBase);
		int arrayLayers = Math.max(1, texture.getDepthOrLayers());
		boolean isCubemap = d3dTexture.isCubemap();

		int srvFormat = hasDepth
			? D3D11GpuTexture.depthSrvFormat(texture.getFormat())
			: D3D11GpuTexture.dxgiFormat(texture.getFormat());

		MemorySegment srvResource;
		try (Arena arena = Arena.ofConfined()) {
			// D3D11_SHADER_RESOURCE_VIEW_DESC (24 bayt)
			MemorySegment desc = arena.allocate(24, 4);
			desc.set(JAVA_INT, 0, srvFormat);

			if (isCubemap) {
				desc.set(JAVA_INT, 4, D3D11_SRV_DIMENSION_TEXTURECUBE);
				desc.set(JAVA_INT, 8, clampedBase);   // TextureCube.MostDetailedMip
				desc.set(JAVA_INT, 12, clampedLevels); // TextureCube.MipLevels
			} else if (arrayLayers > 1) {
				desc.set(JAVA_INT, 4, D3D11_SRV_DIMENSION_TEXTURE2DARRAY);
				desc.set(JAVA_INT, 8, clampedBase);    // Texture2DArray.MostDetailedMip
				desc.set(JAVA_INT, 12, clampedLevels); // Texture2DArray.MipLevels
				desc.set(JAVA_INT, 16, 0);             // Texture2DArray.FirstArraySlice
				desc.set(JAVA_INT, 20, arrayLayers);   // Texture2DArray.ArraySize
			} else {
				desc.set(JAVA_INT, 4, D3D11_SRV_DIMENSION_TEXTURE2D);
				desc.set(JAVA_INT, 8, clampedBase);    // Texture2D.MostDetailedMip
				desc.set(JAVA_INT, 12, clampedLevels); // Texture2D.MipLevels
			}

			MemorySegment outPtr = arena.allocate(ADDRESS);
			MethodHandle handle = D3D11Com.method(
				context.device,
				DEVICE_CREATE_SHADER_RESOURCE_VIEW,
				FunctionDescriptor.of(JAVA_INT, ADDRESS, ADDRESS, ADDRESS, ADDRESS)
			);
			int hr = (int) handle.invokeExact(context.device, textureResource, desc, outPtr);
			D3D11DebugLog.textureView(texture.getLabel(), texture.getFormat().name(), clampedBase, clampedLevels, totalMips, hr);
			if (hr >= 0) {
				srvResource = outPtr.get(ADDRESS, 0).reinterpret(8);
			} else {
				DirectGraphix.LOGGER.error(
					"[DirectGraphix] CreateShaderResourceView failed for '{}' (fmt={}, mips={}/{}, layers={}, cubemap={}) HRESULT=0x{}",
					texture.getLabel(),
					texture.getFormat(),
					clampedBase,
					totalMips,
					arrayLayers,
					isCubemap,
					Integer.toHexString(hr)
				);
				srvResource = MemorySegment.NULL;
			}
		} catch (Throwable throwable) {
			throw new IllegalStateException("Failed to create D3D11 shader resource view for '" + texture.getLabel() + "'", throwable);
		}

		return new D3D11GpuTextureView(texture, clampedBase, clampedLevels, context, srvResource);
	}

	public MemorySegment resource() {
		return this.resource;
	}

	@Override
	public boolean isClosed() {
		return this.closed;
	}

	@Override
	public void close() {
		if (this.closed) {
			return;
		}
		this.closed = true;
		D3D11Com.release(this.resource);
	}
}