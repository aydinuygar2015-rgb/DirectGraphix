
package com.directx.client.mixin;

import com.directx.DirectGraphix;
import com.directx.client.d3d11.D3D11Backend;
import com.mojang.renderpearl.api.device.GpuBackend;
import java.util.Arrays;
import net.minecraft.client.PreferredGraphicsApi;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PreferredGraphicsApi.class)
public class PreferredGraphicsApiMixin {
    private static final String D3D11_SERIALIZED_NAME = "d3d11";

    @Shadow
    @Final
    @Mutable
    private static PreferredGraphicsApi[] $VALUES;

    @Invoker("<init>")
    private static PreferredGraphicsApi directgraphix$newConstant(
            String name,
            int ordinal,
            String serializedName,
            String translationKey
    ) {
        throw new AssertionError();
    }

    @Inject(
            method = "<clinit>",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/client/PreferredGraphicsApi;$VALUES:[Lnet/minecraft/client/PreferredGraphicsApi;",
                    opcode = Opcodes.PUTSTATIC,
                    shift = At.Shift.AFTER
            )
    )
    private static void directgraphix$addD3D11(CallbackInfo ci) {
        PreferredGraphicsApi[] old = $VALUES;
        PreferredGraphicsApi[] extended = Arrays.copyOf(old, old.length + 1);

        extended[old.length] = directgraphix$newConstant(
                "D3D11",
                old.length,
                D3D11_SERIALIZED_NAME,
                "options.graphicsApi.d3d11"
        );

        $VALUES = extended;
    }

    /**
     * D3D11 seçildiğinde yalnızca Direct3D 11 backend kullanılır.
     * OpenGL ve Vulkan fallback tamamen devre dışıdır.
     */
    @Inject(method = "getBackendsToTry", at = @At("HEAD"), cancellable = true)
    private void directgraphix$getBackendsToTry(
            CallbackInfoReturnable<GpuBackend[]> cir
    ) {
        PreferredGraphicsApi self = (PreferredGraphicsApi) (Object) this;

        if (!D3D11_SERIALIZED_NAME.equals(self.getSerializedName())) {
            return;
        }

        DirectGraphix.LOGGER.info(
                "[DirectGraphix] Direct3D 11 selected: forcing D3D11 backend (no fallback)"
        );

        cir.setReturnValue(new GpuBackend[]{
                new D3D11Backend()
        });
    }
}
